<?php

namespace App\Console\Commands;

use App\Models\Rank;
use App\Models\TodayDetails;
use Illuminate\Console\Command;
use DB;
use App\Models\supermatching;

class AssignRank extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:AssignRank';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $users = DB::table('tbl_users')
                ->select('*')
                ->where('topup_status', '1')
                ->whereNull('rank')
                ->get();
        
        foreach ($users as $value) {         

            //$todayst = TodayDetails::select('*')->where('to_user_id',$value->id)->where('level', 1)->get();
            $todayst = TodayDetails::select('tbl_today_details.*')
                            ->join('tbl_topup', 'tbl_topup.id', '=', 'tbl_today_details.from_user_id')
                            ->where('tbl_today_details.to_user_id', $value->id)
                            ->where('tbl_today_details.level', 1)
                            ->get();
            


            if(count($todayst) >= 2)
            {
                $usersupdate = array();
                $usersupdate['alfa_status'] = 1;

                $rankid = Rank::select('*')->where('rank','Prime')->get();
                $usersupdate['rank'] = $rankid[0]->rank;

                DB::table('tbl_users')->where('id', $value->id)->update($usersupdate);
            }
            else if(count($todayst) == 1){
                if($value->l_ace > 0)
                {
                    if($todayst[0]->position == 1)
                    {
                        $usersupdate = array();
                        $usersupdate['alfa_status'] = 1;

                        $rankid = Rank::select('*')->where('rank','Prime')->get();
                        $usersupdate['rank'] = $rankid[0]->rank;

                        DB::table('tbl_users')->where('id', $value->id)->update($usersupdate);
                    }
                }
                else if($value->r_ace > 0)
                {
                    if($todayst[0]->position == 2)
                    {
                        $usersupdate = array();
                        $usersupdate['alfa_status'] = 1;

                        $rankid = Rank::select('*')->where('rank','Prime')->get();
                        $usersupdate['rank'] = $rankid[0]->rank;

                        DB::table('tbl_users')->where('id', $value->id)->update($usersupdate);
                    }
                }
            }
        }
    }
}