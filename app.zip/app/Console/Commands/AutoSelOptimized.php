<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\adminapi\EWalletController;
use App\Http\Controllers\userapi\SettingsController;
use App\User;
use App\Models\WithdrawPending;
use App\Models\WithdrawalConfirmed;
use App\Models\CronRunStatus;
use App\Models\CronStatus;
use App\Models\Names;
use App\Models\UserInfo;
use App\Models\ProjectSettings;
use App\Models\UserWithdrwalSetting;
use App\Models\Activitynotification;
use Mail;
use App\Models\Dashboard;
use App\Models\AllTransaction;
use App\Models\AutoSell;
use App\Models\Topup;
use Illuminate\Support\Facades\DB;



use Illuminate\Support\Carbon;
use App\Models\CoinRate;

class AutoSelOptimized extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:auto_sell_optimized';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sell 2% Tokens Automatically';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $date = \Carbon\Carbon::now();
        $this->today = $date->toDateTimeString();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle() {

        
            $users = User::join('tbl_dashboard', 'tbl_dashboard.id', '=', 'tbl_users.id')
             ->join('tbl_topup', 'tbl_topup.id', '=', 'tbl_users.id')
             ->select('tbl_users.*', 'tbl_dashboard.*', 'tbl_topup.*', 'tbl_users.id as tuid')
             ->where('tbl_users.status', 'Active')
             ->where('tbl_users.auto_withdrawal_status', '0')
             ->where('tbl_topup.entry_time', '<=', Carbon::now()->subDay()->toDateTimeString())
             ->whereDate('tbl_topup.entry_time', '>=', '2024-02-15')
             ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                      ->from('tbl_auto_sell')
                      ->whereRaw('tbl_auto_sell.transaction_hash = tbl_topup.srno')
                      ->whereDate('tbl_auto_sell.entry_time', '=', Carbon::now()->toDateString());
            })
             ->groupBy('tbl_users.id')
             ->get();
             


        $projectSettings = ProjectSettings::where('status', 1)
           ->select('withdraw_day', 'withdraw_start_time', 'withdraw_status', 'withdraw_off_msg', 'sell_limitation_against_purchase_in_percent')->first();

       

           if (!empty($users)) {
            foreach ($users as $key => $value) {

                

                $userId = $value->tuid;
                $sumOfTopupCoins = $value->buy_coin;
                    
                $selllimit75 = $sumOfTopupCoins;


                $todaystokenstatus = ($sumOfTopupCoins * 2) / 100;

                $availabletokens = $value->working_wallet - ($value->working_wallet_locked_tokens + $value->working_wallet_withdraw);

                if($todaystokenstatus > $availabletokens)
                {

                    $selltokencount = $availabletokens;

                        
                }
                
                        }

                    
                }


             }

            }
              

