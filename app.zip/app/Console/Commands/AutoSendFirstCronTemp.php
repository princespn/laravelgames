<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\adminapi\EWalletController;
use App\Http\Controllers\userapi\SettingsController;
use App\User;
use App\Models\WithdrawPending;
use App\Models\WithdrawalConfirmed;
use App\Models\CronRunStatus;
use App\Models\CronStatus;
use App\Models\Names;
use App\Models\UserInfo;
use App\Models\ProjectSettings;
use App\Models\UserWithdrwalSetting;
use App\Models\Activitynotification;
use Mail;
use App\Models\Dashboard;
use App\Models\AllTransaction;
use App\Models\AutoSell;
use App\Models\Topup;
use Illuminate\Support\Facades\DB;



use Illuminate\Support\Carbon;
use App\Models\CoinRate;

class AutoSendFirstCronTemp extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:auto_sell_temp_cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sell 5% Tokens NextTime Automatically';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $date = \Carbon\Carbon::now();
        $this->today = $date->toDateTimeString();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle() {

        $z = 1;
        for($i = 2; $i <= 3; $i++)
        {
        $day = \Carbon\Carbon::now()->format('D');
       
         
         $j = (11 * $i);
         $k = 10;

        //$datefor = Carbon::now()->subDays(22)->toDateString();
        echo $datefor = Carbon::now()->subDays($j)->toDateString();
        //$datefor = "2023-12-19";
        echo "\n\n";
        //$datefor11 = Carbon::now()->subDays(10)->toDateString();
        echo $datefor11 = Carbon::now()->subDays($k)->toDateString();
        //$datefor11 = "2023-12-30";
        echo "\n\n";
        
            $users = User::join('tbl_dashboard', 'tbl_dashboard.id', '=', 'tbl_users.id')
             ->join('tbl_topup', 'tbl_topup.id', '=', 'tbl_users.id')
             ->select('tbl_topup.entry_time as et','tbl_users.*', 'tbl_dashboard.*', 'tbl_topup.*', 'tbl_users.id as tuid', 'tbl_topup.srno as ttid')
             ->where('tbl_users.status', 'Active')
             ->where('tbl_users.auto_withdrawal_status', '0')
             ->where('tbl_users.special_power_status', '0')
             ->where('tbl_users.special_buying_id', '0')
            //  ->whereDate('tbl_topup.entry_time', '=', $datefor)
            ->whereDate('tbl_topup.entry_time', '=', $datefor)
             ->get();
             
           
             
             
             



        $projectSettings = ProjectSettings::where('status', 1)
           ->select('withdraw_day', 'withdraw_start_time', 'withdraw_status', 'withdraw_off_msg', 'sell_limitation_against_purchase_in_percent')->first();

           $myArray = [];
       
           $arid = "";
           if (!empty($users)) {
            foreach ($users as $key => $value) {

                //echo $value->et." = ".$value->ttid." = ".$value->tuid." \n\n";
                
                $userId = $value->tuid;

                if (!in_array($userId, $myArray)) {
                $myArray[] = $userId;
                $sumOfTopupCoins = User::join('tbl_topup', 'tbl_topup.id', '=', 'tbl_users.id')
                    ->where('tbl_users.id', $userId)
                    // ->whereDate('tbl_topup.entry_time', $datefor)
                    ->whereDate('tbl_topup.entry_time', '=', $datefor)
                    ->sum('tbl_topup.buy_coin');
                    
                $selllimit75 = ($sumOfTopupCoins * 75) / 100;


                $todaystokenstatus = ($sumOfTopupCoins * 5) / 100;

                $alreadywithdrawlamountinlasttendays = WithdrawPending::where('id', $userId)
                                                    ->where('withdraw_type', '=', 2)
                                                    ->where(function($query) {
                                                            $query->where('status', 0)
                                                            ->orWhere('status', 1);
                                                        })
                                                    ->whereDate('entry_time', '>', $datefor11)
                                                    ->orderBy('entry_time', 'desc')
                                                    ->sum('sell_coin');


                $alreadywithdrawlamountinlasttendays1 = AutoSell::where('id', $userId)
                                                    ->where(function($query) {
                                                        $query->where('status', 0)
                                                        ->orWhere('status', 1);
                                                    })
                                                    //->whereDate('entry_time', '>=', $datefor) 
                                                    ->where('transaction_hash', $value->ttid) 
                                                    ->whereDate('entry_time', '>', $datefor11) 
                                                    ->orderBy('entry_time', 'desc')
                                                    ->sum('sell_coin');
                
                
                $alreadywithdrawlamountinlasttendays1 = $alreadywithdrawlamountinlasttendays1 + $alreadywithdrawlamountinlasttendays;
                
                if($selllimit75 > $alreadywithdrawlamountinlasttendays1)
                {
                
                    
                     if($alreadywithdrawlamountinlasttendays1 >= $todaystokenstatus)
                     {
                        //echo "exit = ".$userId."\n\n";
                        
                     }
                     else{

                        $selltokencount = $todaystokenstatus - $alreadywithdrawlamountinlasttendays1;

                        $getCoinTotal = CoinRate::orderBy('id', 'desc')->first();
                        $sellrate = $getCoinTotal->buy_rate;
                     
                        $valueofselltoken = $selltokencount * $sellrate;
                        

                        
                
                        

                        if($valueofselltoken >= 10)
                        {
                            
                            if($projectSettings->sell_limitation_against_purchase_in_percent == "" || $projectSettings->sell_limitation_against_purchase_in_percent == NULL)
                            {
                                $sellLimitation = 0;
                            }
                            else{
                                $sellLimitation = 1;
                                $sellCoinCheck = $selltokencount;
                                $sell_limitation_against_purchase_in_percent = $projectSettings->sell_limitation_against_purchase_in_percent;
                            }
                
                            
                            
                
                            $statusw = UserInfo::where('id', $userId)->pluck("withdraw_block_by_admin")->first();
                            $withdraw_status = $statusw;
                            if($withdraw_status == 1)
                            {
                                //echo "Your withdraw requests stopped please contact with support team"."\n\n";
                            }
                
                
                            $user_id = $userId;
                            //$currency_address = UserWithdrwalSetting::select('currency', 'currency_address', 'block_user_date_time')->where([['id', $user_id], ['status', 1]])->first();
                            
                            
                            // Fetching the user details from tbl_users
                            $userDetails = DB::table('tbl_users')
                            ->select('usdt_trc20_address', 'usdt_bep20_address')
                            ->where('id', $user_id)
                            ->first();

                            // Default currency address
                            $currency_address = "";
                            $currency_address_add = "";
                            $nttype = "";
                            $currencyflag = 0;

                            // Check and set the appropriate currency address
                            if (!empty($userDetails->usdt_trc20_address)) {
                                $currency_address = $userDetails->usdt_trc20_address;
                                $currency_address_add = $currency_address;
                                $nttype = "USDT.TRC20";
                                $currencyflag = 1; 
                            } elseif (!empty($userDetails->usdt_bep20_address)) {
                                $currency_address = $userDetails->usdt_bep20_address;
                                $currency_address_add = $currency_address;
                                $nttype = "USDT.BEP20";
                                $currencyflag = 1; 
                            }

                            
                            
                
                            $id       = $userId;
                            $user_id  = $id;
                            
                
                            $dash = Dashboard::where('id', $id)->select('working_wallet', 'working_wallet_withdraw', 'working_wallet_locked_tokens')
                                    ->first();
                                
                
                            $working_wallet_balance = $dash->working_wallet - ($dash->working_wallet_withdraw + $dash->working_wallet_locked_tokens);
                
                                
                
                                
                            $totalselllimitappliedbyadmin = $value->sell_token_limit;
                                if($totalselllimitappliedbyadmin == 0)
                                {
                                    $flag = 0;
                                }
                                else{
                                    $totalwithdrawals = $selltokencount;
                                    if($totalselllimitappliedbyadmin < $totalwithdrawals)
                                    {
                                        $remainingLimitFromAdmin = $totalwithdrawals - $alreadywithdrawlamountinlasttendays1;
                                        $flag = 1;
                                    }
                                    else{
                                        $flag = 0;
                                    }
                                }
                                
                                if($flag == 0)
                                {
                                    if($sellLimitation == 1)
                                    {
                
                                        $getCoinTotalForAdmin1 = CoinRate::orderBy('id', 'desc')->first();
                                        $currentSellRate = $getCoinTotalForAdmin1->sell_rate;
                
                                        
                                        $sell_amount = $selltokencount * $currentSellRate;
                                    
                                    
                                    $sumOfAmounts = User::join('tbl_topup', 'tbl_topup.id', '=', 'tbl_users.id')
                                                    ->where('tbl_users.id', $userId)
                                                    // ->whereDate('tbl_topup.entry_time', $datefor)
                                                    ->whereDate('tbl_topup.entry_time', '=', $datefor)
                                                    ->sum('tbl_topup.amount');
                
                                        $sellCoinCheck1 = $sell_amount;
                                        $sell_limitation_against_purchase_in_percent = $value->withdrawl_limit;
                                        $withdrawllimit = ($sumOfAmounts * $sell_limitation_against_purchase_in_percent) / 100;
                                        $limitation = $withdrawllimit;
                                        $remainingLimit = $limitation - $alreadywithdrawlamountinlasttendays1;
                
                                    
                
                                        if($remainingLimit < $sellCoinCheck1)
                                        {
                                            $arrOutputData = [];
                                        //echo $strMessage = "Selling tokens more than ".$sell_limitation_against_purchase_in_percent."% of topup amount is not allowed. & Your Remaining Limit is $".$remainingLimit."\n\n";
                                        }
                                    }
                
                                    if ($selltokencount <= $working_wallet_balance) {
                                    
                                        $updateData                            = array();
                                        $updateData['working_wallet_withdraw'] = DB::raw("working_wallet_withdraw + " . $selltokencount);
                                        $updtdash                              = Dashboard::where('id', $id)->update($updateData);
                
                                    
                                        $projectSettings = ProjectSettings::where('status', 1)->select('*')->first();
                                        $getCoinTotal = CoinRate::orderBy('id', 'desc')->first();
                                        $totalCoin = ($getCoinTotal->total_coin - $selltokencount);
                
                                        //dd("tokens place = ".$request->working_wallet);
                                        $deductionamount = ($sellCoinCheck1 * $projectSettings->sell_deduction_admin_percent) / 100;
                                        $testcpamount = ($sellCoinCheck1 - (($sellCoinCheck1 * $projectSettings->sell_deduction_admin_percent) / 100));
                                        
                                        $total_amount_m1 = $getCoinTotal->total_amount - $testcpamount;
                                        $buyRate = ($total_amount_m1/$totalCoin);
                                        // $sellRate = $getCoinTotal->buy_rate;
                                        $insertCoinRateData = [];
                                        $insertCoinRateData['total_coin'] = $totalCoin;
                
                                        $insertCoinRateData['total_amount'] = $total_amount_m1;
                
                                        $insertCoinRateData['buy_rate'] = $buyRate;
                                        $insertCoinRateData['sell_rate'] = $getCoinTotal->buy_rate;
                                        CoinRate::insert($insertCoinRateData);
                
                                        
                                        //$deductionamount = 0;
                                        
                                        $sell_deduction_store_admin_id = $projectSettings->sell_deduction_store_admin_id;
                                        
                                        $current_sell_deduction_amount = Dashboard::where('id', $sell_deduction_store_admin_id)->select('sell_deduction_amount')->first();
                                        
                                        $new_admin_amount_balance = ($current_sell_deduction_amount->sell_deduction_amount + $deductionamount);
                                        
                                        $updateCoinData1['sell_deduction_amount'] = $new_admin_amount_balance;
                                        $updateCoinData1['working_wallet'] = DB::raw('working_wallet + '.$deductionamount);
                                        $updateCoinDataUp1 = Dashboard::where('id', $sell_deduction_store_admin_id)->update($updateCoinData1);
                                    
                                        $Toaddress                       = $currency_address_add;
                                        $NetworkType                     = $nttype;
                                        $withDrawdata                    = array();
                                        $withDrawdata['id']              = $id;
                                        $withDrawdata['amount']          = ($sellCoinCheck1 - $deductionamount);
                                        $withDrawdata['withdrawl_amount']          = $sellCoinCheck1;
                                        $withDrawdata['sell_coin']          = $selltokencount;
                                        $withDrawdata['sell_rate']          = $currentSellRate;
                                        $withDrawdata['transaction_fee'] = 0;
                                        $withDrawdata['deduction']       = $deductionamount;
                                        $withDrawdata['from_address']    = '';
                                        $withDrawdata['to_address']      = trim($Toaddress);
                                        $withDrawdata['network_type']    = $NetworkType;
                                        //$withDrawdata['ip_address']    = getIPAddress();
                                        $withDrawdata['ip_address']    = '';
                                        $withDrawdata['entry_time']      = $this->today;
                                        $withDrawdata['withdraw_requested']      = $this->today;
                                        
                                        
                                        
                                        

                                        if($currencyflag == 1)
                                        {
                                            $withDrawdata['withdraw_type']   = 9;
                                            $WithDrawinsert                  = WithdrawPending::create($withDrawdata);
                                            $withDrawdata['withdraw_type']   = 1;
                                            $withDrawdata['status']   = 1;
                                            $withDrawdata['topup_date']      = $datefor;
                                            $withDrawdata['transaction_hash'] = $value->ttid;
                                            $WithDrawinsert1                  = AutoSell::create($withDrawdata);
                                        }
                                        else{
                                            $withDrawdata['withdraw_type']   = 1;
                                            $withDrawdata['status']   = 0;
                                            $withDrawdata['topup_date']      = $datefor;
                                            $withDrawdata['transaction_hash'] = $value->ttid;
                                            $WithDrawinsert1                  = AutoSell::create($withDrawdata);
                                        }
                
                                        $getCoin = ProjectSettings::where([['status', 1]])->pluck('coin_name')->first();
                
                                        $balance   = AllTransaction::where('id', '=', $id)->orderBy('srno', 'desc')->pluck('balance')->first();
                                        $Trandata1 = array(
                                            'id'           => $id,
                                            'network_type' => $getCoin,
                                            'refference'   => $id,
                                            'debit'        => $selltokencount,
                                            'balance'      => $balance - $selltokencount,
                                            'type'         => "working_wallet",
                                            'status'       => 1,
                                            'remarks'      => $selltokencount . ' has withdrawn from working wallet',
                                            'entry_time'   => $this->today
                                        );
                
                                        $Trandata3 = array(
                                            'id'         => $id,
                                            'message'    => $selltokencount . ' has withdrawn from working wallet',
                                            'status'     => 1,
                                            'entry_time' => $this->today
                                        );
                
                                        $TransactionDta1 = AllTransaction::insert($Trandata1);
                                        //----into acitviy notification
                                        $actDta = Activitynotification::insert($Trandata3);
                
                                        // $subject = "Withdraw request has been submitted successfully";
                                        // $pagename = "emails.Withdrawal_fund";
                                        // $withdraw_from="Working Wallet";
                                        // $entry_time= date('d M Y',strtotime($this->today));
                                        // $data = array('pagename' => $pagename, 'username' => Auth::User()->user_id, 'name' => Auth::User()->fullname,'date'=>$entry_time,'withdraw_amount'=>$request->working_wallet,'fees'=>$Deductionamount,'wallet_address'=>trim($Toaddress),'withdraw_from'=>$withdraw_from);
                                        // $mail = sendMail($data, Auth::User()->email, $subject);
                
                                        //echo 'Amount withdraw successfully'."\n\n";
                                    } else {
                                        //echo 'Insufficient wallet balance'."\n\n";
                                    }
                                }
                                else{
                                    //echo 'You are trying to sell coin more than your limit.'."\n\n";
                                }   
                                
                                //echo "exit 11 = ".$userId."\n\n";
                
                        }

                    }

                    
                }

            }

             }

            }

        }
              
            }

  }


