<?php

namespace App\Console\Commands;
use App\Models\UserActivityLog;
use Illuminate\Console\Command;

class DeleteActivity extends Command {
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'cron:delete_activity';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Delete Activity for more than 30 days';
	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function handle()
    {
        $dayLimit = 30;
        $cutoffDate = now()->subDays($dayLimit);
        $deleted = UserActivityLog::where('entry_time', '<=', $cutoffDate)->delete();
        $this->info("Deleted {$deleted} old activity logs older than {$dayLimit} days");
    }
}
