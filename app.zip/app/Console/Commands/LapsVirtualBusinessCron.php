<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\TodayDetails;
use App\Models\PowerBV;
use App\Models\AddRemoveBusinessUpline;

//use App\Http\Controllers\userapi\AwardRewardController;


class LapsVirtualBusinessCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:laps_virtual_business';
    protected $hidden = true;


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'laps_virtual_business';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    // public function __construct(AwardRewardController $assignaward)
    public function __construct()
    {
        parent::__construct();
       // $this->assignaward = $assignaward; 
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
      
        
        $getUserDetails = User::where([
            ['manual_power_lbv', '>', 0],
            ['manual_power_rbv', '>', 0],
            ['status', '=', 'Active'],
            ['type', '!=', 'Admin']
        ])->get();

        if ($getUserDetails->isNotEmpty()) {
            foreach ($getUserDetails as $user) {

                $getVal=min($user->manual_power_lbv,$user->manual_power_rbv);
                $curr_l_bv = $user->curr_l_bv;
                $curr_r_bv = $user->curr_r_bv;
                

                if($curr_l_bv >= $getVal && $curr_r_bv >= $getVal)
                {
                    $updateData = array();
                    $updateData["curr_l_bv"] = DB::raw("curr_l_bv - ".$getVal);
                    $updateData["curr_r_bv"] = DB::raw("curr_r_bv - ".$getVal);
                    $updateData["manual_power_lbv"] = DB::raw("manual_power_lbv - ".$getVal);
                    $updateData["manual_power_rbv"] = DB::raw("manual_power_rbv - ".$getVal);
                    DB::table('tbl_users')->where('id', $user->id)->update($updateData);
                }
                else{
                    $updateData = array();
                    $updateData["manual_power_lbv"] = DB::raw("manual_power_lbv - ".$getVal);
                    $updateData["manual_power_rbv"] = DB::raw("manual_power_rbv - ".$getVal);
                    DB::table('tbl_users')->where('id', $user->id)->update($updateData);
                }

                

            }
        }

    }
}


                           
