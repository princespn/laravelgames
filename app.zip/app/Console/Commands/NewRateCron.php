<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Dashboard;
use App\User;

use App\Models\ProjectSetting;
use App\Models\ProjectSettings;
use App\Models\CoinRateWithoutIdSpecialBuyingSpecialPower;
use DB;



class NewRateCron extends Command

{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:new_rate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'New Rate Cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $userid = "AAAA11";


        $projectSettings = ProjectSetting::select('*')->first();


        $result = DB::table('tbl_topup as tt')
                        ->select('tt.*')
                        ->join('tbl_users as tu', 'tt.id', '=', 'tu.id')
                        ->where('tu.user_id', '!=', $userid)
                        ->where('tt.remark',  '!=', 'Special Buying')
                        ->where('tt.remark',  '!=', 'Buying for Special Power')
                        ->orderBy('tt.srno', 'asc')
                        ->get();

        foreach ($result as $user) {


                $result1 = DB::table('tbl_special_power_bv')
                    ->where('srno', '<', 3459)
                    ->whereColumn('from_user_id', 'current_user_id')
                    ->where('from_user_id', '=', $user->id)
                    ->where('power_bv', '=', $user->amount)
                    ->get();

                    if(count($result1) == 0)
                    {
                        $buyingamount = $user->amount;
                        $Productcost = $buyingamount;
                        $getCoinTotal = CoinRateWithoutIdSpecialBuyingSpecialPower::orderBy('id', 'desc')->first();
                        $purchasedCoin = ((($buyingamount * $projectSettings->coin_display_percent) / 100)  / $getCoinTotal->buy_rate);
                        $admin_coin = ((($buyingamount * $projectSettings->admin_deduction_to_admin_id) / 100)  / $getCoinTotal->buy_rate);
                        $income = ((($buyingamount * $projectSettings->admin_deduction_binary_income) / 100)  / $getCoinTotal->buy_rate);
                        $level_coin = ((($buyingamount * (100 - $projectSettings->coin_amount_receive_percentage)) / 100)  / $getCoinTotal->buy_rate);

                        
                        $admin_amount = (($buyingamount * $projectSettings->coin_display_percent) / 100);
                        
                        
                        //update binary data 
                        $projectSettings = ProjectSettings::where('status', 1)->select('*')->first();
                        $binay_amount_id = $projectSettings->binay_amount_id;
                        $admin_amount_id = $projectSettings->admin_amount_id;
                        
                        $todayTotalCoin = ($purchasedCoin + $income + $admin_coin);
                        $totalCoinSum = ($todayTotalCoin + $getCoinTotal->total_coin);
                        $totalAmountSum = ($buyingamount + $getCoinTotal->total_amount);
                    
                        $getbuyRate = $totalAmountSum / $totalCoinSum;
                        

                        $buyRate = $getbuyRate;
                        $sellRate = $getCoinTotal->buy_rate;
                        
                        $insertCoinRateData = [];
                        $insertCoinRateData['total_coin'] = $totalCoinSum;
                        $insertCoinRateData['total_amount'] = $totalAmountSum;
                        $insertCoinRateData['buy_rate'] = $buyRate;
                        $insertCoinRateData['sell_rate'] = $sellRate;

                        $insertCoinRateData['purchasedCoin'] = $purchasedCoin;
                        $insertCoinRateData['admin_coin'] = $admin_coin;
                        $insertCoinRateData['income'] = $income;
                        $insertCoinRateData['level_coin'] = $level_coin;

                        $insertCoinRateData['topup_id'] = $user->amount;

                        CoinRateWithoutIdSpecialBuyingSpecialPower::insert($insertCoinRateData);
                    }

        }






        $result11 = DB::table('tbl_withdrwal_pending as tt')
                        ->select('tt.*')
                        ->join('tbl_users as tu', 'tt.id', '=', 'tu.id')
                        ->where('tu.user_id', '!=', $userid)
                        ->orderBy('tt.sr_no', 'asc')
                        ->get();

        foreach ($result11 as $user) {


                        $buyingamount = $user->withdrawl_amount;
                        $Productcost = $buyingamount;
                        $getCoinTotal = CoinRateWithoutIdSpecialBuyingSpecialPower::orderBy('id', 'desc')->first();
                        $purchasedCoin = $user->sell_coin;
                        $admin_coin = (($user->sell_coin* $projectSettings->sell_deduction_admin_percent) / 100);
                        $income = 0;
                        $level_coin = 0;

                        
                        $admin_amount = 0;

                        $totalCoin = ($getCoinTotal->total_coin - $user->sell_coin);
                        $withdrawl_amount = $user->sell_coin * $getCoinTotal->sell_rate;

                        //dd("tokens place = ".$request->working_wallet);
                        $testcpamount = ($withdrawl_amount - (($withdrawl_amount* $projectSettings->sell_deduction_admin_percent) / 100));
                        
                        $total_amount_m1 = $getCoinTotal->total_amount - $withdrawl_amount;
                        $buyRate = ($total_amount_m1/$totalCoin);
                        
                        
                        //update binary data 
                        $projectSettings = ProjectSettings::where('status', 1)->select('*')->first();
                        
                        $getbuyRate = $total_amount_m1 / $totalCoin;
                        

                        $buyRate = $getbuyRate;
                        $sellRate = $getCoinTotal->buy_rate;
                        
                        $insertCoinRateData = [];
                        $insertCoinRateData['total_coin'] = $totalCoin;
                        $insertCoinRateData['total_amount'] = $total_amount_m1;
                        $insertCoinRateData['buy_rate'] = $buyRate;
                        $insertCoinRateData['sell_rate'] = $sellRate;

                        $insertCoinRateData['purchasedCoin'] = $user->sell_coin;
                        $insertCoinRateData['admin_coin'] = $admin_coin;
                        $insertCoinRateData['income'] = $income;
                        $insertCoinRateData['level_coin'] = $level_coin;

                        $insertCoinRateData['topup_id'] = $user->withdrawl_amount;

                        CoinRateWithoutIdSpecialBuyingSpecialPower::insert($insertCoinRateData);
                    

        }






    }
}
