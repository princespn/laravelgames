<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Topup;
use App\Models\Dashboard;
use App\Models\Packages;
use App\Models\Carrybv;
use App\Models\RankList;
use App\Models\PayoutHistory;
use App\Models\TodayDetails;
use Carbon\Carbon;

class OptimizedBinaryIncome extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:optimized_binary_income';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Calculate binary income';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $currentTime = Carbon::now();
        $currentDateTime = $currentTime->toDateTimeString();

        $msg = "Binary Cron started at ".$currentDateTime;
        echo $msg."\n";

        echo "Start: ".$currentTime."\n";

        $binaryCount = 0;

        $getUserDetails = User::join('tbl_dashboard', 'tbl_users.id', '=', 'tbl_dashboard.id')
                                ->where('tbl_users.curr_l_bv', '>', 0)
                                ->where('tbl_users.curr_r_bv', '>', 0)
                                ->where('tbl_users.type', '!=', 'Admin')
                                ->where('tbl_users.binary_qualified_status', 1)
                                ->select('tbl_users.*', 'tbl_dashboard.roi_wallet', 'tbl_dashboard.roi_wallet_withdraw', 'tbl_dashboard.working_wallet', 'tbl_dashboard.working_wallet_withdraw',) // fetch fields from both tables
                                ->get();
        


        if ($getUserDetails->isNotEmpty()) {
            $insertCarryBvArr = [];
            $insertPayoutArr = [];
            $updateCurrBvArr = [];
            $updateDashData = [];

            foreach ($getUserDetails as $user) {

                $userDirectTotal = User::where('ref_user_id', $user->id)
                    ->where('topup_status', '1')
                    ->count();

                if ($userDirectTotal >= 2) {

                    $rank = RankList::where('rank', $user->rank)->first();
                    if (!$rank) {
                        $rank = RankList::where('rank', 'Prime')->first();
                    }

                    $binaryPercentage = $rank->binary_income;
                    $product_id = $rank->id;                    
                    $leftBv = $user->curr_l_bv;
                    $rightBv = $user->curr_r_bv;
                    $getVal = min($leftBv, $rightBv);

                    if ($getVal > 0) {
                        $matchBv = $getVal;
                        $updatedLeftBv = $leftBv - $matchBv;
                        $updatedRightBv = $rightBv - $matchBv;

                        $carryBvArr = [
                            'user_id' => $user->id,
                            'before_l_bv' => $leftBv,
                            'before_r_bv' => $rightBv,
                            'match_bv' => $matchBv,
                            'carry_l_bv' => $updatedLeftBv,
                            'carry_r_bv' => $updatedRightBv
                        ];

                        $insertCarryBvArr[] = $carryBvArr;

                        $updateCurrBvArr[] = [
                            'id' => $user->id,
                            'curr_l_bv' => $updatedLeftBv,
                            'curr_r_bv' => $updatedRightBv
                        ];

                        $topupcounts = Topup::where('id', $user->id)->count();
                        $univarsalcapping = 50*$topupcounts*1000000000;

                        $amount = ($matchBv * $binaryPercentage) / 100;

                        $receivedmaincapping = ($user->roi_wallet + $user->roi_wallet_withdraw) + ($user->working_wallet + $user->working_wallet_withdraw);
                        

                        

                        $netAmount = $amount;
                        $taxAmount = 0;
                        $amtPin = 0;
                        $lapsBv = 0;
                        $lapsStatus = 1;
                        $lapsAmount = 0;
                        $status = 'Paid';
                        $remark = 'Binary Income';
                        $bonus_status = 0;
                        

                        $paidUser = User::where('id', $user->id)->where('type', '')->select('topup_status')->first();

                        $check_if_exist = Topup::where('id', $user->id)->where('roi_status', 'Active')->count();    
                                        

                        // $topup= Topup::where('id',$user->id)->selectRaw("COUNT(srno) as tp_count,SUM(total_income) as capping_amount")->first();

                        // $dash = Dashboard::selectRaw('(roi_income + direct_income + binary_income + royalty_bonus) as total_income')
                        //     ->where('id', $user->id)
                        //     ->first();

                        // $total_income = $dash->total_income;

                        // $capping = $topup->capping_amount;

                        if ($paidUser->topup_status == "0") {
                            $lapsAmount = $matchBv;
                            $amount = 0;
                            $netAmount = $amount;
                            $taxAmount = 0;
                            $amtPin = 0;
                            $lapsBv = 0;
                            $lapsStatus = 0;
                            $status = 'Unpaid';
                            $remark = 'Not having active install station';
                            $bonus_status = 1;
                            $hourly_per = 0;

                        }else if($check_if_exist == 0){
                            $lapsAmount = $matchBv;
                            $amount = 0;
                            $netAmount = $amount;
                            $taxAmount = 0;
                            $amtPin = 0;
                            $lapsBv = 0;
                            $lapsStatus = 0;
                            $status = 'Unpaid';
                            $remark = 'Not having active install station';
                            $bonus_status = 1;
                            $hourly_per = 0;

                        }else if ($amount > $rank->capping) {
                               
                          $amount     =  $rank->capping;
                          $totalchck = $receivedmaincapping + $amount;
                          if($totalchck > $univarsalcapping)
                          {
                            $amount = $univarsalcapping - $receivedmaincapping;
                            $remark = "Income lapsed due to 20X Capping Achieved";
                          }
                          else{
                            $remark = "Binary Capping Achieved";
                          }
                          //$lapsAmount =   $amount - $rank->capping;
                          $lapsAmount = max(0, $amount - $rank->capping);
                          $netAmount = $rank->capping;
                          $taxAmount = 0;
                          $amtPin = 0;
                          $lapsBv = 0;
                          $lapsStatus = 1;
                          $status = 'Paid';
                          $bonus_status = 0;
                          
                         } 
                         else{
                            $totalchck = $receivedmaincapping + $amount;
                            if($totalchck > $univarsalcapping)
                            {
                                //$lapsAmount =   $amount - ($univarsalcapping - $receivedmaincapping);
                                $lapsAmount = max(0, $amount - ($univarsalcapping - $receivedmaincapping));
                                $amount = $univarsalcapping - $receivedmaincapping;
                                $remark = "Income lapsed due to 20X Capping Achieved";
                                $netAmount = $amount;
                                $taxAmount = 0;
                                $amtPin = 0;
                                $lapsBv = 0;
                                $lapsStatus = 1;
                                $status = 'Paid';
                            }
                         }
                        //  else if ($total_income  >= $capping) {   
                        //   $lapsAmount =   $matchBv;
                        //   $amount      =  0;
                        //   $netAmount = $amount;
                        //   $taxAmount = 0;
                        //   $amtPin = 0;
                        //   $lapsBv = 0;
                        //   $lapsStatus = 0;
                        //   $bonus_status = 1;
                        //   $hourly_per = 0;
                        //   $status = 'Unpaid';
                        //   $remark = "Income lapsed due to 4X Capping Achieved";
                        //  }      
                        
                        
                        
                        

                        $payoutArr = [
                            'user_id' => $user->id,
                            'amount' => $amount,
                            'net_amount' => $netAmount,
                            'tax_amount' => $taxAmount,
                            'amt_pin' => $amtPin,
                            'product_id' => $product_id,
                            'pin' => substr(number_format(time() * rand(), 0, '', ''), 0, '9'),
                            'laps_bv' => $lapsBv,
                            'status' => $status,
                            'laps_status' => $lapsStatus,
                            'laps_amount' => $lapsAmount,
                            'left_bv' => $leftBv,
                            'right_bv' => $rightBv,
                            'match_bv' => $matchBv,
                            'left_bv_carry' => $updatedLeftBv,
                            'right_bv_carry' => $updatedRightBv,
                            'remark' => $remark,
                            'rank' => $rank->rank,
                            'percentage' => $binaryPercentage,
                            'entry_time' => $currentDateTime,
                        ];

                        $updateData = array();
                        $updateData['id'] = $user->id;
                        $updateData['total_profit'] = $amount;
                        $updateData['binary_income'] = $amount;
                        $updateData['binary_income_withdraw'] = $amount;
                        $updateData['working_wallet'] = $amount; 

                        array_push($updateDashData,$updateData);
                        $insertPayoutArr[] = $payoutArr;

                        $binaryCount++;
                    }
                }
            }

            if (!empty($insertCarryBvArr)) {
                Carrybv::insert($insertCarryBvArr);
            }

            if (!empty($insertPayoutArr)) {
                PayoutHistory::insert($insertPayoutArr);
            }

            if (!empty($updateCurrBvArr)) {
                User::upsert($updateCurrBvArr, ['id'], ['curr_l_bv', 'curr_r_bv']);
            }

            /*Update Dashboard*/
            $count = 1;
            $array = array_chunk($updateDashData,1000);
            while($count <= count($array))
            {
                $key = $count-1;
                $arrProcess = $array[$key];
                $mainArr = array();
                foreach ($arrProcess as $k => $v) {
                    $mainArr[$v['id']]['id'] = $v['id'];
            
                    if (!isset($mainArr[$v['id']]['total_profit']) && !isset($mainArr[$v['id']]['binary_income']) && !isset($mainArr[$v['id']]['working_wallet']) && !isset($mainArr[$v['id']]['binary_income_withdraw']) && !isset($mainArr[$v['id']]['working_wallet'])) 
                    {

                        $mainArr[$v['id']]['binary_income']=$mainArr[$v['id']]['total_profit']=0;
                        $mainArr[$v['id']]['binary_income_withdraw']=$mainArr[$v['id']]['working_wallet']=0;
                        
                    }
                    $mainArr[$v['id']]['total_profit'] += $v['total_profit']; 
                    $mainArr[$v['id']]['binary_income'] += $v['binary_income']; 
                     $mainArr[$v['id']]['binary_income_withdraw'] += $v['binary_income_withdraw']; 
                    $mainArr[$v['id']]['working_wallet'] += $v['working_wallet']; 
                    
                }

                $ids = implode(',', array_column($mainArr, 'id'));
                $total_profit_qry = 'total_profit = (CASE id';
                $working_wallet_qry = 'working_wallet = (CASE id';
                $binary_income_qry = 'binary_income = (CASE id';
                $binary_income_withdraw_qry = 'binary_income_withdraw = (CASE id';

                foreach ($mainArr as $key => $val) {
                    $total_profit_qry = $total_profit_qry . " WHEN ".$val['id']." THEN total_profit + ".$val['total_profit'];             
                    $working_wallet_qry = $working_wallet_qry . " WHEN ".$val['id']." THEN working_wallet + ".$val['working_wallet'];
                
                    $binary_income_qry = $binary_income_qry . " WHEN ".$val['id']." THEN binary_income + ".$val['binary_income'];
                    
                    $binary_income_withdraw_qry = $binary_income_withdraw_qry . " WHEN ".$val['id']." THEN binary_income_withdraw + ".$val['binary_income_withdraw'];
                }

                $total_profit_qry = $total_profit_qry . " END)";         
                $working_wallet_qry = $working_wallet_qry . " END)";
                $binary_income_qry = $binary_income_qry . " END)";
                $binary_income_withdraw_qry = $binary_income_withdraw_qry . " END)";

                $updt_qry = "UPDATE tbl_dashboard SET ".$total_profit_qry." , ".$binary_income_qry.", ".$binary_income_withdraw_qry.",".$working_wallet_qry." WHERE id IN (".$ids.")";
                $updt_user = DB::statement($updt_qry);

                $this->info($count." update from user dash array ".count($mainArr));
                $count ++;
            }

            $msg = "Binary Income Cron executed successfully. Total users processed: " . $binaryCount;
            echo $msg . "\n";
            echo "End: " . Carbon::now() . "\n";
        }
    }
}
