<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\Topup;
use App\Models\Dashboard;
use App\Models\Product;
use App\Models\DailyBonus;
use App\User;

class OptimizedDailyRioIncome extends Command
{
     /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:optimized_daily_roi_income';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Daily Roi Cron';
    /**
     * Create a new command instance.
     *
     * @return void
     */
    
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    
    public function handle()
    {
        $start = microtime(true);

        $this->info('ROI Cron started at ' . Carbon::now()->toDateTimeString());

        $topups = Topup::selectRaw('tbl_topup.*,tp.roi')
            ->join('tbl_users as tu', 'tu.id', '=', 'tbl_topup.id')
            ->join('tbl_product as tp', 'tp.id', '=', 'tbl_topup.type')
            // ->join('tbl_dashboard as td', 'td.id', '=', 'tbl_topup.id')
            ->where('tu.status', 'Active')
            ->where('tu.type', '')
            ->where('tbl_topup.roi_status', 'Active')
            ->where('tbl_topup.roi_stop_status', '1')
            ->where('tbl_topup.total_roi_count', '<', DB::raw('tp.duration'))
            ->whereRaw("DATEDIFF(NOW(), tbl_topup.last_roi_entry_time) >= 1")
            ->get();

        $insertDailyBonuses = [];
        $updateDashData = [];
        $updateTopupData = [];
        $updatePinArray = [];  
        $capping_total = [];
        foreach ($topups as $topup) {
            $lastRoiEntryTime = Carbon::parse($topup->last_roi_entry_time);
            $now = Carbon::now();
            $diffInDays = $lastRoiEntryTime->diffInDays($now);
            $nextEntryDate = $lastRoiEntryTime->addDay();
            $getDay = Carbon::parse($nextEntryDate)->format('D');

            // if ($getDay === 'Sat') {
            //     $nextEntryDate = $nextEntryDate->addDays(2);
            // }

            // if ($getDay === 'Sun') {
            //     $nextEntryDate = $nextEntryDate->addDays(1);
            // }

            if ($diffInDays >= 1 && $nextEntryDate <= $now) {

                $duration = $topup->duration;
                $total_roi_count = $topup->total_roi_count;
                $roiAmount = $topup->amount_roi;
                $userId = $topup->id;
                $roi_per = $topup->roi;
                $laps_amount = 0;
                $remark = "ROI Income";
                $status = "Paid";

                // if ($topup->type == "6" || $topup->type == 6) {
                //     $product_roi = Product::select("roi")->where('min_hash','<=',$topup->amount)->where("max_hash",">=",$topup->amount)->whereNotIn("package_type",["Zero PIN","Zero PIN ROI","Influencer"])->first();
                //     $roi_per =  $product_roi->roi;
                // }

            // 4x capping start
            
             /*   if (!isset($capping_total[$userId])) 
                {
                    $capping_total[$userId] = $topup->dash_total_income;
                }
              
                if ($capping_total[$userId] < $topup->capping_amount) 
                {

                    if (($capping_total[$userId] + $roiAmount) >= $topup->capping_amount) 
                    {
                        $laps_amount = ($capping_total[$userId] + $roiAmount) - $topup->capping_amount;
                        $roiAmount = $topup->capping_amount - $capping_total[$userId];
                        $remark = "4X Capping";
                    }
                }else{

                    $laps_amount = $roiAmount;
                    $roiAmount = 0;
                    $status = "Unpaid";
                    $remark = "Income lapsed due to 4X Capping Achieved";
                }

                $capping_total[$userId] += $roiAmount;

                */

                // 4x capping start End
                 
                $insertDailyBonuses[] = [
                    'id' => $userId,
                    'pin' => $topup->pin,
                    'amount' => $roiAmount,
                    'status' => $status,
                    'remark' => $remark,
                    'laps_amount' => $laps_amount,
                    'daily_percentage' => $roi_per,
                    'on_amount' => $topup->amount,
                    'daily_amount' => $roiAmount,
                    'entry_time' => $nextEntryDate,
                    'type' => $topup->type,
                ];

                $updateData = array();
                $updateData['id'] = $userId;
                $updateData['total_profit'] = $roiAmount;
                $updateData['roi_income'] = $roiAmount;
                $updateData['roi_income_withdraw'] = $roiAmount;
                $updateData['working_wallet'] = $roiAmount; 

                array_push($updateDashData,$updateData);

                $updateTopupData[] = [
                    'total_roi_count' => $total_roi_count + 1,
                    'last_roi_entry_time' => $nextEntryDate,
                    'pin' => $topup->pin,
                ];


                if ($total_roi_count + 1 >= $duration) {
                    $updatePinArray[] = $topup->pin;
                }
            }           
        }
        $i = 1;
        $insertDailyBonusesChunks = array_chunk($insertDailyBonuses, 1000);
        foreach ($insertDailyBonusesChunks as $chunk) {
            DailyBonus::insert($chunk);
            $this->info($i." insert count array ".count($chunk));
            $i++;
        }

            Topup::whereIn('pin', $updatePinArray)
                ->update(['roi_status' => 'Inactive']);

        foreach ($updateTopupData as $data) {
            Topup::where('pin', $data['pin'])
                ->update([
                    'total_roi_count' => $data['total_roi_count'],
                    'last_roi_entry_time' => $data['last_roi_entry_time'],
                ]);
        }

         /*Update Dashboard*/
        $count = 1;
        $array = array_chunk($updateDashData,1000);
        while($count <= count($array))
        {
            $key = $count-1;
            $arrProcess = $array[$key];
            $mainArr = array();
            foreach ($arrProcess as $k => $v) {
                $mainArr[$v['id']]['id'] = $v['id'];        
                if (!isset($mainArr[$v['id']]['total_profit']) && !isset($mainArr[$v['id']]['roi_income'])
                 && !isset($mainArr[$v['id']]['working_wallet']) && !isset($mainArr[$v['id']]['roi_income_withdraw']) && !isset($mainArr[$v['id']]['working_wallet']) 
                ) 
                {

                    $mainArr[$v['id']]['roi_income']=$mainArr[$v['id']]['total_profit']=0;
                    $mainArr[$v['id']]['roi_income_withdraw']=$mainArr[$v['id']]['working_wallet']=0;
                    
                }
                $mainArr[$v['id']]['total_profit'] += $v['total_profit']; 
                $mainArr[$v['id']]['roi_income'] += $v['roi_income']; 
                 $mainArr[$v['id']]['roi_income_withdraw'] += $v['roi_income_withdraw']; 
                $mainArr[$v['id']]['working_wallet'] += $v['working_wallet']; 
                
            }

            $ids = implode(',', array_column($mainArr, 'id'));
            $total_profit_qry = 'total_profit = (CASE id';
            $roi_income_qry = 'roi_income = (CASE id';
            $working_wallet_qry = 'working_wallet = (CASE id';
            $roi_income_withdraw_qry = 'roi_income_withdraw = (CASE id';

            foreach ($mainArr as $key => $val) {
                $total_profit_qry = $total_profit_qry . " WHEN ".$val['id']." THEN total_profit + ".$val['total_profit'];             
            
                $roi_income_qry = $roi_income_qry . " WHEN ".$val['id']." THEN roi_income + ".$val['roi_income'];
                
                $working_wallet_qry = $working_wallet_qry . " WHEN ".$val['id']." THEN working_wallet + ".$val['working_wallet'];
                $roi_income_withdraw_qry = $roi_income_withdraw_qry . " WHEN ".$val['id']." THEN roi_income_withdraw + ".$val['roi_income_withdraw'];
            }

            $total_profit_qry = $total_profit_qry . " END)";         
            $roi_income_qry = $roi_income_qry . " END)";
            $working_wallet_qry = $working_wallet_qry . " END)";
            $roi_income_withdraw_qry = $roi_income_withdraw_qry . " END)";

            $updt_qry = "UPDATE tbl_dashboard SET ".$total_profit_qry." , ".$roi_income_qry.", ".$working_wallet_qry.", ".$roi_income_withdraw_qry." WHERE id IN (".$ids.")";
            $updt_user = DB::statement($updt_qry);

            $this->info($count." update from user dash array ".count($mainArr));
            $count ++;
        }

        $elapsedTime = round(microtime(true) - $start, 2);
        $this->info('ROI Cron completed in ' . $elapsedTime . ' seconds');
    }
}
