<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Config;
use App\Models\AwardWinner;
use App\Models\WeeklyRoyaltyBonus;
use App\Models\Product;
use App\Dashboard;
use DB;


class OptimizedWeeklyRoyaltyBonusCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:optimized_weekly_royalty_bonus';    
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Weekly Royalty Bonus Cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    
    public function handle()
    {
        list($usec, $sec) = explode(" ", microtime());

        $time_start1 = ((float)$usec + (float)$sec);
        DB::raw('LOCK TABLES `tbl_dashboard` WRITE');
        // DB::raw('LOCK TABLES `tbl_award_winner` WRITE');
        DB::raw('LOCK TABLES `tbl_award_winner` WRITE');
        //cron here     

        $current_time = \Carbon\Carbon::now()->toDateTimeString();
        $msg = "Magnet Cron started at ".$current_time;
        echo $msg."\n";

        $allTopusDistinctEntryTime = AwardWinner::select(DB::raw("Date(last_royalty_bonus_time) as last_royalty_bonus_time"))
        ->join('tbl_users as tu', 'tu.id', '=', 'tbl_award_winner.user_id')
        ->where('tu.status', 'Active')->where('tu.type', '')
        ->where('tbl_award_winner.weekly_income_count','<=', 52)
        ->where('tbl_award_winner.status','0')
        ->groupby(DB::raw("Date(last_royalty_bonus_time)"))
        //->limit(1)
        ->get();
        
        foreach ($allTopusDistinctEntryTime as $tpdet) 
        {       

        echo "Last Royalty Bonus Date -> ".$last_royalty_bonus_time=$tpdet->last_royalty_bonus_time;
        echo "\n";
       

        $allTopus = AwardWinner::select('tbl_award_winner.user_id as id','tbl_award_winner.pin','tbl_award_winner.weekly_amount','tbl_award_winner.amount','tbl_award_winner.winner_id','tbl_award_winner.entry_time','tbl_award_winner.weekly_income_count','tbl_award_winner.last_royalty_bonus_time','tu.entry_time as register_date')
        ->join('tbl_users as tu', 'tu.id', '=', 'tbl_award_winner.user_id')
        ->where('tu.status', 'Active')->where('tu.type', '')
        ->where('tbl_award_winner.weekly_income_count','<=',52)
        ->where('tbl_award_winner.status','0')
        ->where([[DB::raw("Date(tbl_award_winner.last_royalty_bonus_time)"),$last_royalty_bonus_time]])
       // ->limit(100000)
        ->get();


        $i=1;
        $insert_dailybonus_arr = array();
        $update_dash_arr = array();
        $user_id_arr = array();
        $pin_arr = array();       
        $weekly_income = 0;

         echo "last royalty bonus date -> ".$last_royalty_bonus_time;
           
            
           $getDate = \Carbon\Carbon::now()->toDateString();

           $nextEntrydate = date('Y-m-d', strtotime($last_royalty_bonus_time. ' + 7 days'));         

           if(strtotime($nextEntrydate)<= strtotime($getDate)){
                foreach ($allTopus as $tp){
                    list($usec, $sec) = explode(" ", microtime());
                    $time_start = ((float)$usec + (float)$sec);
                    $weekly_income = $tp->weekly_amount;
                    $Dailydata = array();
                    $Dailydata['award_winer_id'] = $tp->winner_id;
                    $Dailydata['user_id'] = $tp->id;
                    $Dailydata['amount'] = $tp->amount;
                    $Dailydata['pin'] = $tp->pin;
                    $Dailydata['status'] = 'Paid';
                    $Dailydata['weekly_amount'] = $weekly_income;
                    $Dailydata['entry_time'] = $nextEntrydate;
                     array_push($insert_dailybonus_arr,$Dailydata);

                    array_push($user_id_arr,$tp->id);
                    
                    array_push($pin_arr,$tp->pin);

                    echo " -> srno -> ".$i++." -> id -> ".$tp->id." ->  cron date -> ".$nextEntrydate." -> ";
              

                    list($usec, $sec) = explode(" ", microtime());
                    $time_end = ((float)$usec + (float)$sec);
                    $time = $time_end - $time_start;
                    echo "time ".$time."\n";
                                                
                }
            }

        echo "\n Royalty Bonus Date ".$nextEntrydate."\n";
     
        $count1 = 1;
        $array = array_chunk($insert_dailybonus_arr,1000);
        while($count1 <= count($array))
        {
          $key = $count1-1;
          WeeklyRoyaltyBonus::insert($array[$key]);
          echo $count1." insert count array ".count($array[$key])."\n";
          $count1 ++;
        }

        $updateCoinData = array();
        $updateCoinData['usd'] = DB::raw('usd +'.$weekly_income);
        $updateCoinData['total_profit'] = DB::raw('total_profit +'. $weekly_income); 
        $updateCoinData['royalty_bonus'] = DB::raw('royalty_bonus + '. $weekly_income);
        $updateCoinData['royalty_bonus_withdraw'] = DB::raw('royalty_bonus_withdraw + '. $weekly_income);
        $updateCoinData['working_wallet'] = DB::raw('working_wallet + '. $weekly_income);

        
        $count2 = 1;     
        $array2 = array_chunk($user_id_arr,1000);
        while($count2 <= count($array2))
        {
          $key2 = $count2-1;
          Dashboard::whereIn('id',$array2[$key2])->update($updateCoinData);
          echo $count2." update dashboard wallet array ".count($array2[$key2])."\n";
          $count2 ++;
        }        

        $updateTopupData = array();
        $updateTopupData['weekly_income_count'] = DB::raw('weekly_income_count + 1');
        $updateTopupData['last_royalty_bonus_time'] = $nextEntrydate; 

        if(($updateTopupData['weekly_income_count']) >= 52){
            $updateTopupData['status'] = 1;
        }
        $count3 = 1;     
        $array3 = array_chunk($pin_arr,1000);
        while($count3 <= count($array3))
        {
          $key3 = $count3-1;
          AwardWinner::whereIn('pin',$array3[$key3])->update($updateTopupData);
          echo $count3." update pin array ".count($array3[$key3])."\n";
          $count3 ++;
        }
    }
        $current_time = \Carbon\Carbon::now()->toDateTimeString();
        $msg = "Cron end at ".$current_time."\nTotal records : ".count($insert_dailybonus_arr)."\n";
        
        echo $msg;

        echo "\n";
        list($usec, $sec) = explode(" ", microtime());
        $time_end1 = ((float)$usec + (float)$sec);
        $time = $time_end1 - $time_start1;
        echo "after wealth Royalty Bonus cron ".$time."\n";         

        DB::raw('UNLOCK TABLES');
    }
}
