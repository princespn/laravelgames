<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Policies\BinaryIncomeClass;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Config;
use DB;
use App\User;
use App\Models\ProjectSettings;
use App\Models\PayoutHistory;
use App\Models\Product;
use App\Models\Topup;
use App\Models\QualifiedUserList as QualifiedUsers;
use App\Traits\Users;

class PasswordEncryptionCrom extends Command
{

    use Users;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:password_encryption_cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'password_encryption_cron';
    protected $objBinaryIncome;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(BinaryIncomeClass $objBinaryIncome){
        parent::__construct();
        $this->objBinaryIncome = $objBinaryIncome;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    /**
     * Execute the console command.
     *
     * @return mixed
     */
  public function handle()
    {
        $getUserDetails = User::select("temp_pass","password","tr_passwd","bcrypt_password", "id", "user_id")->where([['type','!=',"Admin"]])->get();

        foreach ($getUserDetails as $key => $value) 
        {
            echo $value->user_id." == ".$value->temp_pass."\n";
           $str = $value->temp_pass;
           $arrData['password'] = encrypt($str);
           $arrData['tr_passwd'] = bcrypt($str);
           $arrData['bcrypt_password'] = bcrypt($str);
           $user = User::find($value->id);
            if ($user) {
                $user->password = $arrData['password']; // Assuming 'password' is the column name in your table
                $user->tr_passwd = $arrData['tr_passwd']; // Replace 'tr_passwd' with the actual column name
                $user->bcrypt_password = $arrData['bcrypt_password']; // Replace 'bcrypt_password' with the actual column name
                $user->save();
            }

           
           
        }


    }
}