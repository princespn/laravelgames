<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use App\Models\User;
use App\Models\SupperMatchingIncome;
use App\Models\Rank;
use App\Models\Dashboard;
use App\Models\supermatching;
use DB;

class RankIncomeNew extends Command {

   protected $signature = 'cron:matching_income_new';
    protected $description = 'Rank income generation for users based on achieved ranks';

    public function handle() {
        $today = Carbon::now();
        $today_datetime = $today->toDateTimeString();
        $today_datetime2 = $today->toDateString();

        $users = User::join('tbl_super_matching', 'tbl_super_matching.user_id', '=', 'tbl_users.id')
            ->select('tbl_users.id', 'tbl_users.email', 'tbl_users.country', 'tbl_super_matching.rank', 'tbl_super_matching.entry_time')
            ->where([['tbl_users.status', '=', 'Active'], ['tbl_super_matching.rank', '!=', 'Ace']])
            ->get();

        foreach ($users as $user) {
            $id = $user->id;
            $rank = $user->rank;
            $entry_time = Carbon::parse($user->entry_time);
            $this->info("Processing user $id with rank $rank");

            // Dynamic date range calculation based on $entry_time
            // Get the Sunday of the week that contains the entry_time
            $startDate = $entry_time->copy()->startOfWeek(); // Start of the week (Sunday)
            // Get the Saturday of that same week
            $endDate = $startDate->copy()->endOfWeek(); // End of the week (Saturday)

            $this->info("Date Range for user $id: $startDate to $endDate");

            // Retrieve the ranks the user achieved within the dynamic week range
            $achievedRanks = supermatching::select('rank', 'entry_time')
                ->whereBetween('entry_time', [$startDate, $endDate])
                ->where('user_id', $id)
                ->orderBy('entry_time')
                ->get();

            // Handle Condition 1: Assign rank income based on the first rank achieved within the dynamic range
            if ($achievedRanks->isNotEmpty()) {
                $firstAchievedRank = $achievedRanks->first()->rank;
                $rankIncomeDate = Carbon::parse($achievedRanks->first()->entry_time)->addDays(7); // The next Sunday after the first rank achieved

                $this->generateRankIncome($id, $firstAchievedRank, $rankIncomeDate);
            }

            // Handle Condition 2 & 3: Multiple rank achievements in the same week
            if ($achievedRanks->count() > 1) {
                $lastEntryRank = $achievedRanks->last()->rank; // Latest rank achieved
                $rankIncomeDate = Carbon::parse($achievedRanks->last()->entry_time)->addDays(7); // Next Sunday after the last rank achievement
                $this->generateRankIncome($id, $lastEntryRank, $rankIncomeDate);
            }

            // Handle Condition 4: Rank achievements in the next week
            $nextWeekRanks = $achievedRanks->where('entry_time', '>', $endDate);

            if ($nextWeekRanks->isNotEmpty()) {
                $subsequentRank = $nextWeekRanks->last()->rank;
                $rankIncomeDate = Carbon::parse($nextWeekRanks->last()->entry_time)->addDays(7); // Next Sunday after subsequent rank achievement
                $this->generateRankIncome($id, $subsequentRank, $rankIncomeDate);
            } else {
                $this->info("No rank found for user $id after the end of week $endDate");
            }
        }

        $this->info('Supper Matching Bonus generated successfully');
    }

    // Generate rank income for the user
    public function generateRankIncome($id, $rank, $rankIncomeDate) {
        $rankInfo = Rank::where('rank', $rank)->first();
        if (!$rankInfo) {
            $this->info("No rank info found for $rank, skipping.");
            return;
        }

        $bonus_percentage = $rankInfo->bonus_percentage;
        $totalIncome = Dashboard::select('binary_income', 'direct_income', 'roi_income', 'hscc_bonus_income')
            ->where('id', $id)
            ->first();

        $totalIncome = $totalIncome->binary_income + $totalIncome->direct_income + $totalIncome->roi_income + $totalIncome->hscc_bonus_income;

        // Ensure income does not exceed capping
        $topup = DB::table('tbl_topup')->where('id', $id)->sum('amount');
        $cappingTotal = $topup * 3;
        
        $finalIncome = $totalIncome + $bonus_percentage;
        if ($finalIncome > $cappingTotal) {
            $finalIncome = $cappingTotal; // Cap the income if it exceeds the limit
        }

        // Record the rank income
        SupperMatchingIncome::create([
            'user_id' => $id,
            'rank' => $rank,
            'amount' => $finalIncome,
            'entry_time' => $rankIncomeDate,
            'status' => 'Paid',
            'remark' => 'Rank income generated',
        ]);

        // Update user's wallet
        Dashboard::where('id', $id)->update([
            'usd' => DB::raw('usd + ' . $finalIncome),
            'supper_maching_income' => DB::raw('supper_maching_income + ' . $finalIncome),
        ]);

        $this->info("Rank income generated for user $id with rank $rank on $rankIncomeDate");
    }
} 