<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Config;
use App\Models\AssignRank;
use App\Models\User;
use App\Models\RankRewardHistory;
use App\Models\Topup;
use App\Models\Dashboard;
use DB;

class RankIncomeWeekly extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:rank_income_weekly';    
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Rank Income Weekly';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    
     public function handle()
    {
        $start = microtime(true);

        $this->info('Bonus Cron started at ' . Carbon::now()->toDateTimeString());
       
        $duration = 100;
        $insertDailyBonuses = [];
        $updateDashData = [];
        $updateTopupData = [];
        $updatePinArray = [];  
        $capping_total = [];  

        $getUserDetails = User::select('id', 'user_id', 'l_bv', 'r_bv')
            ->where('binary_qualified_status', 1)
            ->where('topup_status', '1')
            ->where('amount', '>', 0)
            ->where('status', 'Active')
            ->get();    

        foreach ($getUserDetails as $user) {      

           $allBonus = AssignRank::select('tbl_assign_rank.user_id', 'tbl_assign_rank.pin', 'tbl_assign_rank.amount', 'tbl_assign_rank.id', 'tbl_assign_rank.entry_time','tbl_assign_rank.last_rank_income_date', 'tbl_assign_rank.total_rank_income_count')
                ->join('tbl_users as tu', 'tu.id', '=', 'tbl_assign_rank.user_id')
                ->where('tu.status', 'Active')
                ->where('tu.type', '')
                ->where('tbl_assign_rank.total_rank_income_count', '<', $duration)
                ->where('tbl_assign_rank.rank_income_status', '0')
                ->where('tbl_assign_rank.user_id', $user->id)
                // ->whereRaw("TIMESTAMPDIFF(DAY, tbl_assign_rank.last_rank_income_date, NOW()) >= 7")
                ->orderBy('tbl_assign_rank.id', 'desc')
                ->limit(2)
                ->get();

            $this->info(" -> count user -> " . count($allBonus) . " -> id -> " . $user->id);

            if(count($allBonus) >= 2){

                if ($allBonus[1]['total_rank_income_count'] >= 1) {

                    $allBonusNew = AssignRank::select('tbl_assign_rank.user_id', 'tbl_assign_rank.pin', 'tbl_assign_rank.amount', 'tbl_assign_rank.id', 'tbl_assign_rank.entry_time','tbl_assign_rank.last_rank_income_date', 'tbl_assign_rank.total_rank_income_count')
                        ->join('tbl_users as tu', 'tu.id', '=', 'tbl_assign_rank.user_id')
                        ->where('tu.status', 'Active')
                        ->where('tu.type', '')
                        ->where('tbl_assign_rank.total_rank_income_count', '<', $duration)
                        ->where('tbl_assign_rank.rank_income_status', '0')
                        ->where('tbl_assign_rank.pin', $allBonus[1]['pin'])
                        ->whereRaw("TIMESTAMPDIFF(DAY, tbl_assign_rank.last_rank_income_date, NOW()) >= 7")
                        ->orderBy('tbl_assign_rank.id', 'asc')
                        ->get();

                         $this->info(" -> count pin1 -> " . $allBonus[1]['pin'] . " -> id -> " . $user->id);

                        AssignRank::where('pin', $allBonus[1]['pin'])
                             ->update(['rank_income_status' => '1']);

                        $nextDate = \Carbon\Carbon::parse($allBonus[0]['last_rank_income_date'])->addDays(7)->toDateString();

                        AssignRank::where('pin', $allBonus[0]['pin'])
                             ->update(['last_rank_income_date' => $nextDate]);
                }else{

                    $allBonusNew = AssignRank::select('tbl_assign_rank.user_id', 'tbl_assign_rank.pin', 'tbl_assign_rank.amount', 'tbl_assign_rank.id', 'tbl_assign_rank.entry_time','tbl_assign_rank.last_rank_income_date', 'tbl_assign_rank.total_rank_income_count')
                        ->join('tbl_users as tu', 'tu.id', '=', 'tbl_assign_rank.user_id')
                        ->where('tu.status', 'Active')
                        ->where('tu.type', '')
                        ->where('tbl_assign_rank.total_rank_income_count', '<', $duration)
                        ->where('tbl_assign_rank.rank_income_status', '0')
                        ->where('tbl_assign_rank.pin', $allBonus[0]['pin'])
                        ->whereRaw("TIMESTAMPDIFF(DAY, tbl_assign_rank.last_rank_income_date, NOW()) >= 7")
                        ->orderBy('tbl_assign_rank.id', 'desc')
                        ->get();

                    AssignRank::where('pin', $allBonus[1]['pin'])
                        ->update(['rank_income_status' => '1']);

                    $this->info(" -> count pin2 -> " . $allBonus[0]['pin'] . " -> id -> " . $user->id);
                }

            }else{

                $allBonusNew = AssignRank::select('tbl_assign_rank.user_id', 'tbl_assign_rank.pin', 'tbl_assign_rank.amount', 'tbl_assign_rank.id', 'tbl_assign_rank.entry_time','tbl_assign_rank.last_rank_income_date', 'tbl_assign_rank.total_rank_income_count')
                ->join('tbl_users as tu', 'tu.id', '=', 'tbl_assign_rank.user_id')
                ->where('tu.status', 'Active')
                ->where('tu.type', '')
                ->where('tbl_assign_rank.total_rank_income_count', '<', $duration)
                ->where('tbl_assign_rank.rank_income_status', '0')
                ->where('tbl_assign_rank.user_id', $user->id)
                ->whereRaw("TIMESTAMPDIFF(DAY, tbl_assign_rank.last_rank_income_date, NOW()) >= 7")
                ->get();
                
                $this->info(" -> user id -> " . $user->id);
            }


                foreach ($allBonusNew as $topup) {
                    $last_rank_income_date = $topup->last_rank_income_date;
                    $getDate = \Carbon\Carbon::now()->toDateString();
                    $nextEntryDate = \Carbon\Carbon::parse($last_rank_income_date)->addDays(7)->toDateString();
                    $amount = $topup->amount;
                    // $laps_amount = 0;
                    $remark = "Rank Bonus";
                    $status = "Paid";

                    if (\Carbon\Carbon::parse($nextEntryDate) <= \Carbon\Carbon::parse($getDate)) {

                        // $getTop= Topup::where('id',$topup->id)->selectRaw("COUNT(srno) as tp_count,SUM(total_income) as capping_amount")->first();

                        // $dash = Dashboard::selectRaw('(roi_income + direct_income + binary_income + rank_reward_wallet) as total_income')->where('id',$topup->id)->first();

                        // if (!isset($capping_total[$topup->id])) 
                        // {
                        //     $capping_total[$topup->id] = $dash->total_income;
                        // }

                        // $capping_amount = $getTop->capping_amount;

                        // if ($capping_total[$topup->id] < $capping_amount) 
                        // {

                        //     if (($capping_total[$topup->id] + $amount) >= $capping_amount) 
                        //     {
                        //         $laps_amount = ($capping_total[$topup->id] + $amount) - $capping_amount;
                        //         $amount = $capping_amount - $capping_total[$topup->id];
                        //         $remark = "4X Capping";
                        //     }

                        // }else{
                        
                        //     $laps_amount = $amount;
                        //     $amount = 0;
                        //     $status = "Unpaid";
                        //     $remark = "Income lapsed due to 4X Capping Achieved";
                        // }

                        // $capping_total[$topup->id] += $amount;
                        
                        $insertDailyBonuses[] = [
                            'achived_rank_id' => $topup->id,
                            'user_id' => $topup->user_id,
                            'pin' => $topup->pin,
                            'amount' => $topup->amount,
                            'remark' => $remark,
                            'status' =>  $status,
                            // 'laps_amount' => $laps_amount,
                            'amount' => $amount,
                            'entry_time' => $nextEntryDate,
                        ];

                        $updateData = array();
                        $updateData['id'] = $topup->user_id;
                        $updateData['total_profit'] = $amount;
                        $updateData['rank_reward_wallet'] = $amount;
                        $updateData['rank_reward_wallet_withdrawl'] = $amount;
                        $updateData['working_wallet'] = $amount; 

                        array_push($updateDashData,$updateData);

                        $updateTopupData[] = [
                            'total_rank_income_count' => $topup->total_rank_income_count + 1,
                            'last_rank_income_date' => $nextEntryDate,
                            'pin' => $topup->pin,
                        ];


                        if ($topup->total_rank_income_count + 1 >= $duration) {
                            $updatePinArray[] = $topup->pin;
                        }

                        $this->info(" -> srno -> " . count($insertDailyBonuses) . " -> id -> " . $topup->user_id . " ->  cron date -> " . $nextEntryDate);
                    }           
                }
            }

        $i = 1;
        $insertDailyBonusesChunks = array_chunk($insertDailyBonuses, 1000);
        foreach ($insertDailyBonusesChunks as $chunk) {
            RankRewardHistory::insert($chunk);
            $this->info($i." insert count array ".count($chunk));
            $i++;
        }

            AssignRank::whereIn('pin', $updatePinArray)
                ->update(['rank_income_status' => '1']);

        foreach ($updateTopupData as $data) {
            AssignRank::where('pin', $data['pin'])
                ->update([
                    'total_rank_income_count' => $data['total_rank_income_count'],
                    'last_rank_income_date' => $data['last_rank_income_date'],
                ]);
        }

         /*Update Dashboard*/
        $count = 1;
        $array = array_chunk($updateDashData,1000);
        while($count <= count($array))
        {
            $key = $count-1;
            $arrProcess = $array[$key];
            $mainArr = array();
            foreach ($arrProcess as $k => $v) {
                $mainArr[$v['id']]['id'] = $v['id'];
        
                if (!isset($mainArr[$v['id']]['total_profit']) && !isset($mainArr[$v['id']]['rank_reward_wallet']) && !isset($mainArr[$v['id']]['working_wallet']) && !isset($mainArr[$v['id']]['rank_reward_wallet_withdrawl']) && !isset($mainArr[$v['id']]['working_wallet'])) 
                {

                    $mainArr[$v['id']]['rank_reward_wallet']=$mainArr[$v['id']]['total_profit']=0;
                    $mainArr[$v['id']]['rank_reward_wallet_withdrawl']=$mainArr[$v['id']]['working_wallet']=0;
                    
                }
                $mainArr[$v['id']]['total_profit'] += $v['total_profit']; 
                $mainArr[$v['id']]['rank_reward_wallet'] += $v['rank_reward_wallet']; 
                 $mainArr[$v['id']]['rank_reward_wallet_withdrawl'] += $v['rank_reward_wallet_withdrawl']; 
                $mainArr[$v['id']]['working_wallet'] += $v['working_wallet']; 
                
            }

            $ids = implode(',', array_column($mainArr, 'id'));
            $total_profit_qry = 'total_profit = (CASE id';
            $working_wallet_qry = 'working_wallet = (CASE id';
            $rank_reward_wallet_qry = 'rank_reward_wallet = (CASE id';
            $rank_reward_wallet_withdrawl_qry = 'rank_reward_wallet_withdrawl = (CASE id';

            foreach ($mainArr as $key => $val) {
                $total_profit_qry = $total_profit_qry . " WHEN ".$val['id']." THEN total_profit + ".$val['total_profit'];             
                $working_wallet_qry = $working_wallet_qry . " WHEN ".$val['id']." THEN working_wallet + ".$val['working_wallet'];
            
                $rank_reward_wallet_qry = $rank_reward_wallet_qry . " WHEN ".$val['id']." THEN rank_reward_wallet + ".$val['rank_reward_wallet'];
                
                $rank_reward_wallet_withdrawl_qry = $rank_reward_wallet_withdrawl_qry . " WHEN ".$val['id']." THEN rank_reward_wallet_withdrawl + ".$val['rank_reward_wallet_withdrawl'];
            }

            $total_profit_qry = $total_profit_qry . " END)";         
            $working_wallet_qry = $working_wallet_qry . " END)";
            $rank_reward_wallet_qry = $rank_reward_wallet_qry . " END)";
            $rank_reward_wallet_withdrawl_qry = $rank_reward_wallet_withdrawl_qry . " END)";

            $updt_qry = "UPDATE tbl_dashboard SET ".$total_profit_qry." , ".$rank_reward_wallet_qry.", ".$rank_reward_wallet_withdrawl_qry.",".$working_wallet_qry." WHERE id IN (".$ids.")";
            $updt_user = DB::statement($updt_qry);

            $this->info($count." update from user dash array ".count($mainArr));
            $count ++;
        }

        $elapsedTime = round(microtime(true) - $start, 2);
        $this->info('Bonus Cron completed in ' . $elapsedTime . ' seconds');
    }

}
