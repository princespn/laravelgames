<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\Topup;
use App\Models\HoWallet;
use App\Models\Dashboard;


class SelfBuyingWithCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:self_buying_with_cron';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'self_buying_with_cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $users = User::select('tbl_users.*', 'tbl_dashboard.*', 'tbl_users.id')
                        ->join('tbl_dashboard', 'tbl_users.id', '=', 'tbl_dashboard.id')
                        ->whereDate('tbl_users.entry_time', '>=', '2024-02-01')->get();
                                     
    }
}


                           