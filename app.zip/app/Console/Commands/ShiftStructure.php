<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\TodayDetails;

//use App\Http\Controllers\userapi\AwardRewardController;


class ShiftStructure extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:shift_structure';
    protected $hidden = true;


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'shift structure';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    // public function __construct(AwardRewardController $assignaward)
    public function __construct()
    {
        parent::__construct();
       // $this->assignaward = $assignaward; 
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $topshfiftid = "Shiv007";
        $belowid = "Shiv07";
        $position = "1";

            
            $getSponsorDetails = User::select('*')->where('user_id', $topshfiftid)->first();
            $getSponsorDetails1 = User::select('*')->where('user_id', $belowid)->first();
        
            DB::table('tbl_users')
             ->where('id', $getSponsorDetails['id'])
             ->update(['virtual_parent_id' => $getSponsorDetails1['id'], 'position' => $position]);
            
            $arrAllAboveIds = TodayDetails::select('*')->where('from_user_id', $getSponsorDetails['id'])->delete();
           
            $i = 0;
            $loopOn1 = true;
            $todaydetails_data = array();
            $left_users = array();
            $right_users = array();

            $last = $getSponsorDetails['id'];
            $virtual_parent_id1 = $last;


            if ($virtual_parent_id1 > 0) {
            do {
            $posDetails = User::select('id', 'position', 'virtual_parent_id')->where([['id', '=', $virtual_parent_id1]])->get();
                                    if (count($posDetails) <= 0) {

                                        $loopOn1 = false;
                                    } else {

                                        foreach ($posDetails as $k => $v) {

                                            $virtual_parent_id1 = $posDetails[$k]->virtual_parent_id;
                                            if ($virtual_parent_id1 > 0) {
                                                $position = $posDetails[$k]->position;
                                                if ($last != $virtual_parent_id1) {
                                                    if ($position == 1) {

                                                        array_push($left_users, $virtual_parent_id1);

                                                        // 
                                                    }
                                                    if ($position == 2) {
                                                        array_push($right_users, $virtual_parent_id1);

                                                        // $updateOtpSta1 = User::where('id', $virtual_parent_id1)->update(array('r_c_count' => DB::raw('r_c_count + 1')));
                                                    }

                                                    $Todaydata = array(); // new TodayDetails;
                                                    $Todaydata['to_user_id'] = $virtual_parent_id1;
                                                    $Todaydata['from_user_id'] = $getSponsorDetails['id'];
                                                    $Todaydata['entry_time'] = date("Y-m-d H:i:s");
                                                    $Todaydata['position'] = $position;
                                                    $Todaydata['level'] = $i + 1;
                                                    array_push($todaydetails_data, $Todaydata);
                                                    $i++;
                                                }
                                            } else {
                                                $loopOn1 = false;
                                            }
                                        }
                                    }
                
                            $count = 1;
            
                            $array = array_chunk($todaydetails_data, 1000);
            }while ($loopOn1 == true);               
                while ($count <= count($array)) {
                                $key = $count - 1;
                                TodayDetails::insert($array[$key]);
                                $count++;
                }
           
            }

            $arrAllBelowIds = TodayDetails::select('*')->where('to_user_id', $getSponsorDetails['id'])->get();
            
            foreach ($arrAllBelowIds as $k1 => $v1) {

                $last1 = $arrAllBelowIds[$k1]->from_user_id;
                $virtual_parent_id11 = $last1;
                
                

                $arrAllAboveIds1 = TodayDetails::select('*')->where('from_user_id', $virtual_parent_id11)->delete();

                $i1 = 0;
            $loopOn11 = true;
            $todaydetails_data1 = array();
            $left_users1 = array();
            $right_users1 = array();

            do {
            $posDetails1 = User::select('id', 'position', 'virtual_parent_id')->where([['id', '=', $virtual_parent_id11]])->get();
            
           
               
                                    if (count($posDetails1) <= 0) {

                                        $loopOn11 = false;
                                    } else {

                                        foreach ($posDetails1 as $k => $v) {

                                            $virtual_parent_id11 = $posDetails1[$k]->virtual_parent_id;
                                            if ($virtual_parent_id11 > 0) {
                                                $position = $posDetails1[$k]->position;
                                                if ($last1 != $virtual_parent_id11) {
                                                    if ($position == 1) {

                                                        array_push($left_users1, $virtual_parent_id11);
                                                        if($getSponsorDetails['id'] >  $virtual_parent_id11)
                                                        {
                                                            $updateOtpSta11 = User::where('id', $virtual_parent_id11)->update(array('l_c_count' => DB::raw('l_c_count + 1')));    
                                                        }
                                                        
                                                    }
                                                    if ($position == 2) {
                                                        array_push($right_users1, $virtual_parent_id11);
                                                        if($getSponsorDetails['id'] >  $virtual_parent_id11)
                                                        {
                                                            $updateOtpSta11 = User::where('id', $virtual_parent_id11)->update(array('r_c_count' => DB::raw('r_c_count + 1')));
                                                        }
                                                        
                                                    }

                                                    $Todaydata = array(); // new TodayDetails;
                                                    $Todaydata['to_user_id'] = $virtual_parent_id11;
                                                    $Todaydata['from_user_id'] = $arrAllBelowIds[$k1]->from_user_id;
                                                    $Todaydata['entry_time'] = date("Y-m-d H:i:s");
                                                    $Todaydata['position'] = $position;
                                                    $Todaydata['level'] = $i1 + 1;
                                                    array_push($todaydetails_data1, $Todaydata);
                                                    $i1++;

                                                    

                                                }
                                            } else {
                                                $loopOn11 = false;
                                            }
                                        }
                                    }
                
                            $count1 = 1;
                            $array1 = array_chunk($todaydetails_data1, 1000);
                        }while ($loopOn11 == true);    
                            while ($count1 <= count($array1)) {
                                $key = $count1 - 1;
                                TodayDetails::insert($array1[$key]);
                                $count1++;
                            }


            }


    }
}


                           