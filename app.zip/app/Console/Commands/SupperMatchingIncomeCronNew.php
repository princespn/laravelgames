<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

/**
 * Cron command to process Supper Matching rank income.
 *
 * This version implements the one-rank-per-week logic with batch updates and ensures
 * that payouts are only scheduled for the next available Sunday and never for a
 * future Sunday. A paid rank continues to be paid every Sunday until the user
 * qualifies for a higher rank. When a new rank is achieved, payments switch
 * to the new rank according to the week‑based rules.
 */
class SupperMatchingIncomeCronNew extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:supper_matching_income_new';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Process Supper Matching Rank Income efficiently';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        echo "Rank Income Cron Started: " . Carbon::now('Europe/London')->toDateTimeString() . "\n";

        // Date check for today in Europe/London timezone
        $today = Carbon::now('Europe/London')->toDateString();

        /**
         * Step 1: Pre-pass to process any queued ranks (next_rank_entry) that are due today or earlier.
         *
         * We process exactly one queued rank per user (the earliest next_rank_entry). After processing,
         * last_rank_entry is updated and next_rank_entry is rescheduled to the following Sunday. This
         * ensures ranks scheduled from a previous run continue to pay every week until a new rank is
         * achieved. Ranks scheduled for future Sundays are skipped.
         */
        $pendingByUser = DB::table('tbl_super_matching as s')
            ->join('tbl_users as u', 'u.id', '=', 's.user_id')
            ->where('u.status', 'Active')
            ->where('u.type', '!=', 'Admin')
            ->whereNotNull('s.next_rank_entry')
            ->whereDate('s.next_rank_entry', '<=', $today)
            // Allow processing if last_rank_entry is null OR if last_rank_entry is before next_rank_entry.
            // This ensures queued ranks from multi-rank weeks (where last_rank_entry is the first Sunday)
            // are still processed on the second Sunday.
            ->where(function ($query) {
                $query->whereNull('s.last_rank_entry')
                      ->orWhereRaw('s.last_rank_entry < s.next_rank_entry');
            })
            ->select('s.*', 'u.id as user_id')
            ->orderBy('s.user_id')
            ->orderBy('s.next_rank_entry')
            ->orderBy('s.id')
            ->get()
            ->groupBy('user_id');

        // Step 2: Fetch all eligible ranks for all users, grouped by user_id
        // Order by descending ID so that the latest rank appears first for each user.
        // This ordering is important when determining which rank to schedule in multi-rank weeks.
        $allRanks = DB::table('tbl_super_matching as s')
            ->join('tbl_users as u', 'u.id', '=', 's.user_id')
            ->where('u.status', 'Active')
            ->where('u.type', '!=', 'Admin')
            ->where('s.rank', '!=', 'Ace')
            ->select('s.*', 'u.id as user_id')
            ->orderBy('s.user_id')
            // Always sort by descending id to get the most recent rank first
            ->orderByDesc('s.id')
            ->get()
            ->groupBy('user_id');

        if ($allRanks->isEmpty()) {
            echo "No eligible ranks found.\n";
            return;
        }

        // Step 3: Fetch last_rank_entry for all users in one query, grouped by user_id
        $lastRanks = DB::table('tbl_super_matching')
            ->whereNotNull('last_rank_entry')
            ->orderBy('user_id')
            ->orderBy('last_rank_entry', 'desc')
            ->get()
            ->groupBy('user_id');

        // Prepare arrays for batch inserts and updates
        $batchIncomeInsert    = [];
        $batchSetLastRank     = [];
        $batchSetNextRank     = [];
        $batchClearNextRanks  = [];
        $batchDashboardUpdate = [];

        /**
         * Helper closure to accumulate dashboard increments per user.
         * Ensures that if multiple increments occur, they are summed correctly.
         */
        $bumpDashboard = function(int $userId, float $amount) use (&$batchDashboardUpdate) {
            $inc = ' + ' . $amount;
            if (!isset($batchDashboardUpdate[$userId])) {
                $batchDashboardUpdate[$userId] = [
                    'usd'                   => DB::raw('usd' . $inc),
                    'supper_maching_income' => DB::raw('supper_maching_income' . $inc),
                    'working_wallet'        => DB::raw('working_wallet' . $inc),
                    'hscc_bonus_income'     => DB::raw('hscc_bonus_income' . $inc),
                ];
            } else {
                $batchDashboardUpdate[$userId]['usd']                   = DB::raw('usd' . $inc);
                $batchDashboardUpdate[$userId]['supper_maching_income'] = DB::raw('supper_maching_income' . $inc);
                $batchDashboardUpdate[$userId]['working_wallet']        = DB::raw('working_wallet' . $inc);
                $batchDashboardUpdate[$userId]['hscc_bonus_income']     = DB::raw('hscc_bonus_income' . $inc);
            }
        };

        // Step 4: Iterate over each user
        foreach ($allRanks as $userId => $userRanks) {
            // 4a. If there is a pending queued rank ready to pay (next_rank_entry <= today), process it and skip weekly logic
            if (isset($pendingByUser[$userId]) && $pendingByUser[$userId]->isNotEmpty()) {
                $pendingRank = $pendingByUser[$userId]->first();
                $payoutDate  = Carbon::parse($pendingRank->next_rank_entry, 'Europe/London');

                if ($payoutDate->isFuture()) {
                    // Should not happen due to query filter, but skip just in case
                    echo "User {$userId}: Queued payout Sunday {$payoutDate->toDateString()} is in the future. Skipping.\n";
                } else {
                    echo "User {$userId}: Processing queued rank {$pendingRank->rank} on {$payoutDate->toDateString()}.\n";

                    // Compute income as per ranking
                    $dashboard = DB::table('tbl_dashboard')->where('id', $userId)->first();
                    $totalIncome = ($dashboard->binary_income ?? 0)
                        + ($dashboard->direct_income ?? 0)
                        + ($dashboard->roi_income ?? 0)
                        + ($dashboard->hscc_bonus_income ?? 0);

                    $topup = DB::table('tbl_topup')->where('id', $userId)->sum('amount');
                    $capping_total = $topup * 100000000;

                    if ($totalIncome >= $capping_total) {
                        $stdata = 0;
                        $remark = "Laps Due to 20X Capping Achieved";
                        $laps = 1;
                    } else {
                        $stdata = 1;
                        $remark = "Rank Income Received";
                        $laps = 0;
                    }

                    $rankPackage = DB::table('tbl_rank')->where('rank', $pendingRank->rank)->first();
                    $supermatching = $rankPackage->bonus_percentage ?? 0;
                    $supermatchinglaps = 0;

                    if ($stdata == 1) {
                        $balancetest = $totalIncome + $supermatching;
                        if ($balancetest >= $capping_total) {
                            $supermatchinglaps = $balancetest - $capping_total;
                            $supermatching    -= $supermatchinglaps;
                            $remark = "Laps Due to 20X Capping Achieved";
                            $laps = 1;
                        }
                    } else {
                        $supermatchinglaps = $supermatching;
                        $supermatching     = 0;
                        $remark = "Laps Due to 20X Capping Achieved";
                        $laps = 1;
                    }

                    // Insert income entry for the queued Sunday
                    $batchIncomeInsert[] = [
                        'amount'       => $supermatching,
                        'id'           => $userId,
                        'pin'          => $pendingRank->pin,
                        'daily_amount' => $supermatching,
                        'entry_time'   => $payoutDate->toDateString(),
                        'rank'         => $pendingRank->rank,
                        'remark'       => $remark,
                        'laps_amount'  => $supermatchinglaps,
                        'status'       => $stdata ? 'Paid' : 'Unpaid'
                    ];

                    // Mark this rank as paid on the payout date and schedule it for the
                    // following Sunday. Using the payout date for last_rank_entry ensures
                    // future calculations reference the correct Sunday. We reschedule the
                    // same rank to be paid again one week later until a higher rank is
                    // achieved.
                    $batchSetLastRank[$pendingRank->id] = $payoutDate->toDateString();
                    $nextPayoutDate = $payoutDate->copy()->addWeek()->toDateString();
                    $batchSetNextRank[$pendingRank->id] = $nextPayoutDate;

                    // Accumulate dashboard increments for successful payouts
                    if ($stdata == 1) {
                        $bumpDashboard($userId, (float)$supermatching);
                    }

                    // Clear any queued payout flags on all other ranks for this user. Only this
                    // rank will remain queued. We must compute the list of rank ids from the
                    // full set of ranks for this user.
                    if (isset($allRanks[$userId])) {
                        $allUserRankIds = $allRanks[$userId]->pluck('id')->all();
                        $others = array_diff($allUserRankIds, [$pendingRank->id]);
                        if (!empty($others)) {
                            $batchClearNextRanks[$userId] = ($batchClearNextRanks[$userId] ?? []);
                            $batchClearNextRanks[$userId] = array_values(array_unique(array_merge($batchClearNextRanks[$userId], $others)));
                        }
                    }
                }
                // Skip to next user after handling queued payment
                continue;
            }

            // 4b. No pending queued rank -> determine this week's eligibility
            // Collect all rank IDs for this user. These are used when clearing queued
            // payouts from other ranks once a rank has been scheduled or paid.
            $userRankIds = $userRanks->pluck('id')->all();

            $lastRank = $lastRanks[$userId][0] ?? null;

            // Determine reference date using last paid rank or first unprocessed rank
            // The reference date is either the last paid Sunday or, if none exists,
            // the earliest unprocessed rank's entry_time. Because ranks are
            // ordered by descending ID, we must search for the minimum entry_time.
            $weekReference = $lastRank
                ? Carbon::parse($lastRank->last_rank_entry, 'Europe/London')
                : Carbon::parse($userRanks->sortBy('entry_time')->first()->entry_time, 'Europe/London');

            // Compute week boundaries (Sunday to Saturday) for the reference
            $weekStart = $weekReference->copy()->startOfWeek(Carbon::SUNDAY);
            $weekEnd   = $weekReference->copy()->endOfWeek(Carbon::SATURDAY);

            // Collect unprocessed ranks within this week
            $eligibleRanksThisWeek = $userRanks->filter(function ($rank) use ($lastRank, $weekStart, $weekEnd) {
                $entryTime = Carbon::parse($rank->entry_time, 'Europe/London');
                if ($lastRank && $entryTime->lte(Carbon::parse($lastRank->last_rank_entry, 'Europe/London'))) {
                    return false;
                }
                return $entryTime->between($weekStart, $weekEnd);
            });

            if ($eligibleRanksThisWeek->isEmpty()) {
                // Nothing to process in this week
                continue;
            }

            // Compute the payout Sundays for this reference week. The first Sunday immediately
            // follows the current week (weekStart .. weekEnd). The second Sunday is one week
            // after the first Sunday. These are used to schedule multi-rank weeks.
            $firstSunday  = $weekStart->copy()->addWeek();
            $secondSunday = $firstSunday->copy()->addWeek();

            // If there are multiple ranks in this week, we skip payment on the first Sunday.
            // We instead record the first Sunday in last_rank_entry and schedule the payment
            // for the second Sunday. This ensures the income is paid on the correct Sunday
            // when multiple ranks are achieved.
            if ($eligibleRanksThisWeek->count() > 1) {
                // Determine the latest rank record by ID (since $allRanks is sorted by desc id)
                $latestRank = $eligibleRanksThisWeek->sortByDesc('id')->first();

                // Stamp the last_rank_entry with the first Sunday to mark this week as processed
                $batchSetLastRank[$latestRank->id] = $firstSunday->toDateString();

                // Queue this rank for the second Sunday
                $batchSetNextRank[$latestRank->id] = $secondSunday->toDateString();

                // Clear any queued payout flags on all other ranks for this user. Only
                // the latest rank will remain queued for its second Sunday.
                $others = array_diff($userRankIds, [$latestRank->id]);
                if (!empty($others)) {
                    $batchClearNextRanks[$userId] = ($batchClearNextRanks[$userId] ?? []);
                    $batchClearNextRanks[$userId] = array_values(array_unique(array_merge($batchClearNextRanks[$userId], $others)));
                }

                echo "User {$userId}: Multiple ranks this week, skipping. Stamped last_rank_entry={$firstSunday->toDateString()}, queued {$latestRank->rank} for {$secondSunday->toDateString()}.\n";
                continue;
            }

            // Exactly one rank in the week
            $rankToProcess = $eligibleRanksThisWeek->first();

            // If the first Sunday is in the future, we simply schedule this rank for that
            // Sunday and do not pay yet. Only schedule if payout is not past.
            if ($firstSunday->isFuture()) {
                $batchSetNextRank[$rankToProcess->id] = $firstSunday->toDateString();
                // Clear any queued payout flags on all other ranks for this user. Only this
                // rank will remain queued for its future Sunday.
                $others = array_diff($userRankIds, [$rankToProcess->id]);
                if (!empty($others)) {
                    $batchClearNextRanks[$userId] = ($batchClearNextRanks[$userId] ?? []);
                    $batchClearNextRanks[$userId] = array_values(array_unique(array_merge($batchClearNextRanks[$userId], $others)));
                }
                echo "User {$userId}: Single rank {$rankToProcess->rank}; queued for {$firstSunday->toDateString()}.\n";
                continue;
            }

            // Otherwise (first Sunday <= today) process the rank on that Sunday
            $payoutDate = $firstSunday;
            echo "User {$userId}: Processing rank {$rankToProcess->rank} on {$payoutDate->toDateString()}.\n";

            // Calculate income
            $dashboard = DB::table('tbl_dashboard')->where('id', $userId)->first();
            $totalIncome = ($dashboard->binary_income ?? 0)
                + ($dashboard->direct_income ?? 0)
                + ($dashboard->roi_income ?? 0)
                + ($dashboard->hscc_bonus_income ?? 0);

            $topup = DB::table('tbl_topup')->where('id', $userId)->sum('amount');
            $capping_total = $topup * 100000000;

            if ($totalIncome >= $capping_total) {
                $stdata = 0;
                $remark = "Laps Due to 20X Capping Achieved";
                $laps = 1;
            } else {
                $stdata = 1;
                $remark = "Rank Income Received";
                $laps = 0;
            }

            $rankPackage = DB::table('tbl_rank')->where('rank', $rankToProcess->rank)->first();
            $supermatching = $rankPackage->bonus_percentage ?? 0;
            $supermatchinglaps = 0;

            if ($stdata == 1) {
                $balancetest = $totalIncome + $supermatching;
                if ($balancetest >= $capping_total) {
                    $supermatchinglaps = $balancetest - $capping_total;
                    $supermatching    -= $supermatchinglaps;
                    $remark = "Laps Due to 20X Capping Achieved";
                    $laps = 1;
                }
            } else {
                $supermatchinglaps = $supermatching;
                $supermatching     = 0;
                $remark = "Laps Due to 20X Capping Achieved";
                $laps = 1;
            }

            // Prepare income insert (entry_time = payoutDate)
            $batchIncomeInsert[] = [
                'amount'       => $supermatching,
                'id'           => $userId,
                'pin'          => $rankToProcess->pin,
                'daily_amount' => $supermatching,
                'entry_time'   => $payoutDate->toDateString(),
                'rank'         => $rankToProcess->rank,
                'remark'       => $remark,
                'laps_amount'  => $supermatchinglaps,
                'status'       => $stdata ? 'Paid' : 'Unpaid'
            ];

            // Mark this rank as paid on the payout date. Using the payout date as last_rank_entry
            // ensures subsequent week calculations are based on when the income was actually paid,
            // not when the rank was achieved.
            $batchSetLastRank[$rankToProcess->id] = $payoutDate->toDateString();

            // Reschedule this rank for the next Sunday since payments continue weekly
            $nextSundayDate = $payoutDate->copy()->addWeek()->toDateString();
            $batchSetNextRank[$rankToProcess->id] = $nextSundayDate;

            // Clear any queued payout flags on all other ranks for this user
            $others = array_diff($userRankIds, [$rankToProcess->id]);
            if (!empty($others)) {
                $batchClearNextRanks[$userId] = ($batchClearNextRanks[$userId] ?? []);
                $batchClearNextRanks[$userId] = array_values(array_unique(array_merge($batchClearNextRanks[$userId], $others)));
            }

            // Accumulate dashboard increments for successful payouts
            if ($stdata == 1) {
                $bumpDashboard($userId, (float)$supermatching);
            }
        }

        // Step 5: Apply batched database changes
        // Insert income records
        if (!empty($batchIncomeInsert)) {
            DB::table('tbl_supper_matching_bonus_income')->insert($batchIncomeInsert);
        }

        // Update last_rank_entry for processed ranks
        foreach ($batchSetLastRank as $rankId => $date) {
            DB::table('tbl_super_matching')->where('id', $rankId)->update(['last_rank_entry' => $date]);
        }

        // Clear next_rank_entry for other queued ranks (per user)
        foreach ($batchClearNextRanks as $userId => $rankIds) {
            if (!empty($rankIds)) {
                DB::table('tbl_super_matching')->whereIn('id', $rankIds)->update(['next_rank_entry' => null]);
            }
        }

        // Set next_rank_entry for scheduled and rescheduled ranks (future weeks)
        // Promotion rule:
        //  - If the same user has a future (entry_time strictly greater) NON-ACE rank,
        //    schedule that latest future non-ACE rank for the given date, and only clear
        //    next_rank_entry on the current rank (keep last_rank_entry). This ensures
        //    we promote payments to the newest rank while preserving the anchor Sunday.
        //  - Otherwise, schedule on the current rank (unless current is Ace, then skip).
        if (!empty($batchSetNextRank)) {
            $affectedRankIds = array_keys($batchSetNextRank);
            // 1) Metadata for affected ranks, including rank name
            $rankMeta = DB::table('tbl_super_matching')
                ->whereIn('id', $affectedRankIds)
                ->select('id', 'user_id', 'entry_time', 'rank')
                ->get()
                ->keyBy('id');
            if ($rankMeta->isNotEmpty()) {
                $userIds = $rankMeta->pluck('user_id')->unique()->values()->all();
                // 2) Load ALL non-Ace ranks for those users (so we never pick Ace)
                $allNonAceByUser = DB::table('tbl_super_matching')
                    ->whereIn('user_id', $userIds)
                    ->where('rank', '!=', 'Ace')
                    ->select('id', 'user_id', 'entry_time', 'rank')
                    ->orderBy('user_id')
                    ->orderBy('entry_time')
                    ->orderBy('id')
                    ->get()
                    ->groupBy('user_id');

                $promoteToNext    = [];
                $clearNextOnly    = [];
                $scheduleHere     = [];
                $clearQueuedOthers = []; // userId => rankIds to clear queued dates

                foreach ($batchSetNextRank as $rankId => $date) {
                    $meta = $rankMeta[$rankId] ?? null;
                    if (!$meta) {
                        // Fallback: metadata missing, schedule on current
                        $scheduleHere[$rankId] = $date;
                        continue;
                    }
                    $userRanks = $allNonAceByUser[$meta->user_id] ?? collect();
                    // Find all future non-Ace ranks strictly after current
                    $future = $userRanks->filter(function ($r) use ($meta) {
                        return Carbon::parse($r->entry_time)->gt(Carbon::parse($meta->entry_time));
                    });
                    if ($future->isNotEmpty()) {
                        // Pick the latest future non-Ace rank (by entry_time)
                        $next = $future->sortBy('entry_time')->last();
                        // Promote schedule to this rank
                        $promoteToNext[$next->id] = $date;
                        // Clear next_rank_entry on the current rank (keep last_rank_entry)
                        $clearNextOnly[$rankId] = true;
                        // Ensure only one queued rank per user by clearing others
                        $otherIds = $userRanks->pluck('id')->diff([$next->id])->all();
                        if (!empty($otherIds)) {
                            $clearQueuedOthers[$meta->user_id] = array_values(array_unique(array_merge(
                                $clearQueuedOthers[$meta->user_id] ?? [],
                                $otherIds
                            )));
                        }
                    } else {
                        // No future non-Ace rank
                        if (strcasecmp((string)$meta->rank, 'Ace') === 0) {
                            // Do not schedule Ace: clear next_rank_entry on current
                            $clearNextOnly[$rankId] = true;
                        } else {
                            // Schedule on current rank
                            $scheduleHere[$rankId] = $date;
                        }
                    }
                }
                // 3) Apply updates
                if (!empty($clearNextOnly)) {
                    DB::table('tbl_super_matching')
                        ->whereIn('id', array_keys($clearNextOnly))
                        ->update(['next_rank_entry' => null]);
                }
                foreach ($promoteToNext as $nextId => $date) {
                    DB::table('tbl_super_matching')
                        ->where('id', $nextId)
                        ->update(['next_rank_entry' => $date]);
                }
                foreach ($scheduleHere as $rankId => $date) {
                    DB::table('tbl_super_matching')
                        ->where('id', $rankId)
                        ->update(['next_rank_entry' => $date]);
                }
                // Clear queued dates for all other ranks in each affected user
                foreach ($clearQueuedOthers as $uid => $ids) {
                    if (!empty($ids)) {
                        DB::table('tbl_super_matching')
                            ->whereIn('id', $ids)
                            ->update(['next_rank_entry' => null]);
                    }
                }
            } else {
                // Fallback if metadata can't be loaded
                foreach ($batchSetNextRank as $rankId => $date) {
                    DB::table('tbl_super_matching')
                        ->where('id', $rankId)
                        ->update(['next_rank_entry' => $date]);
                }
            }
        }

        // Update dashboards with increments
        foreach ($batchDashboardUpdate as $userId => $data) {
            DB::table('tbl_dashboard')->where('id', $userId)->update($data);
        }

        echo "Rank Income Cron End: " . Carbon::now('Europe/London')->toDateTimeString() . "\n";
    }
}