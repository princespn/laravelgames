<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\Topup;
use App\Models\HoWallet;
use App\Models\Dashboard;


class WalletAmountNewDataCalculationCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:wallet_amount_new_data_calculation_cron';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'wallet_amount_new_data_calculation_cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $users = User::select('tbl_users.*', 'tbl_dashboard.*', 'tbl_users.id')
                        ->join('tbl_dashboard', 'tbl_users.id', '=', 'tbl_dashboard.id')
                        ->whereDate('tbl_users.entry_time', '>=', '2024-02-01')->get();
        $entrydatetime = date('Y-m-d H:i:s', time());

    	foreach ($users as $user)
        {

                $dashboard = Dashboard::where('id', $user->id)->update([
                    'working_wallet' => '0',
                    'working_wallet_locked_tokens' => '0',
                    'working_wallet_withdraw' => '0',
                    'old_working_wallet' => $user->working_wallet,
                    'old_working_wallet_locked_tokens' => $user->working_wallet_locked_tokens,
                    'old_working_wallet_withdraw' => $user->working_wallet_withdraw,
                    'old_binary_available_tokens' => $user->binary_income_tokens,
                    'old_binary_withdrawal_tokens' => $user->binary_income_withdraw,
                    'old_working_wallet_binary_locked_tokens' => $user->working_wallet_binary_locked_tokens,
                    'binary_income_withdraw' => 0,
                    'binary_income_tokens' => 0,
                    'binary_income' => 0,
                    'working_wallet_binary_locked_tokens' => 0
                ]);
        }                              
    }
}


                           