<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\Topup;
use App\Models\HoBinaryWallet;
use App\Models\Dashboard;


class WalletBinaryAmountCalculationCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
    */
    protected $signature = 'cron:wallet_binary_amount_calculation_cron';
    /**
     * The console command description.
     *
     * @var string
    */
    protected $description = 'wallet_binary_amount_calculation_cron';
    /**
     * Create a new command instance.
     *
     * @return void
    */
    /**
     * Execute the console command.
     *
     * @return mixed
    */
    public function handle()
    {   
        $users = User::select('tbl_users.*', 'tbl_dashboard.*', 'tbl_users.id')
                        ->join('tbl_dashboard', 'tbl_users.id', '=', 'tbl_dashboard.id')
                        ->whereDate('tbl_users.entry_time', '<=', '2024-01-31')->get();
        $entrydatetime = $date = date('Y-m-d H:i:s', time());

    	foreach ($users as $user)
        {

                if($user->id == 68 || $user->id == 145)
                {
                 
                                // Creating a new wallet record
                                $hoWallet = new HoBinaryWallet();
                                $hoWallet->user_id = $user->id; // Example user_id
                                $hoWallet->wallet_amount = 0; // Example wallet amount
                                $hoWallet->wallet_withdrawal_amount = 0; // Example withdrawal amount
                                $hoWallet->wallet_remaining_amount = 0; // Example withdrawal amount
                                $hoWallet->entry_time = $entrydatetime; // Assuming you want to set this manually
                                $hoWallet->updated_date = $entrydatetime;
                                $hoWallet->status = 1; // Active status
                                $hoWallet->save();


                                $dashboard = Dashboard::where('id', $user->id)->update([
                                    'old_binary_available_tokens' => $user->binary_income_tokens,
                                    'old_binary_withdrawal_tokens' => $user->binary_income_withdraw,
                                    'old_working_wallet_binary_locked_tokens' => $user->working_wallet_binary_locked_tokens,
                                    'binary_income_withdraw' => 0,
                                    'binary_income_tokens' => 0,
                                    'binary_income' => 0,
                                    'working_wallet_binary_locked_tokens' => 0
                                ]);
                    
                }
                else{

                $totalBinaryReceived = DB::table('tbl_payout_history')
                    ->where('user_id', $user->id)
                    ->sum('amount');
                
                $totalWithdrawalPending = DB::table('tbl_withdrwal_pending')
                    ->where('id', $user->id)
                    ->where('status', 1)
                    ->where('verify', 1)
                    ->where('withdraw_type', 1)
                    ->sum('withdrawl_amount');

                $t1 = $totalBinaryReceived - $totalWithdrawalPending;

                if($t1 < 0)
                {
                    $t1 = $totalWithdrawalPending;
                }

                $wallet_remaining_amount = 0;

                if($totalWithdrawalPending > $t1)
                {
                    $totalWithdrawalPending = $t1;
                }

                // Creating a new wallet record
                $hoWallet = new HoBinaryWallet();
                $hoWallet->user_id = $user->id; // Example user_id
                $hoWallet->wallet_amount = $t1; // Example wallet amount
                $hoWallet->wallet_withdrawal_amount = $totalWithdrawalPending; // Example withdrawal amount
                $hoWallet->wallet_remaining_amount = $wallet_remaining_amount; // Example withdrawal amount
                $hoWallet->entry_time = $entrydatetime; // Assuming you want to set this manually
                $hoWallet->updated_date = $entrydatetime;
                $hoWallet->status = 1; // Active status
                $hoWallet->save();


                $dashboard = Dashboard::where('id', $user->id)->update([
                    'old_binary_available_tokens' => $user->binary_income_tokens,
                    'old_binary_withdrawal_tokens' => $user->binary_income_withdraw,
                    'old_working_wallet_binary_locked_tokens' => $user->working_wallet_binary_locked_tokens,
                    'binary_income_withdraw' => 0,
                    'binary_income_tokens' => 0,
                    'binary_income' => 0,
                    'working_wallet_binary_locked_tokens' => 0
                ]);

            }
                

    	}
                              
    }
}


                           