<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

use DB;

class Kernel extends ConsoleKernel {

	/**
	 * The Artisan commands provided by your application.
	 *
	 * @var array
	 */
	protected $commands = [

		// Commands\ThreeHoursGenerateROI::class,
		//   Commands\SendHourlyMail::class,
		Commands\WithdrawConfirmMailSend::class,
		Commands\WithdrawRequestMail::class,
		Commands\TopupMail::class,
		Commands\DepositOnAddress::class,
		Commands\AssignAwardCron::class,
		Commands\AutoWithdrawIncome::class,
		Commands\OptimizedBinaryQualify::class,
		// Commands\DailyBinaryIncome::class,
		Commands\AutoRoiWithdrawIncome::class,
		Commands\AutoSendCron::class,
		Commands\SaveTransactionHash::class,
		Commands\ConfirmTransactionCron::class,
		Commands\StatisticsCron::class,
		Commands\BlockUserOnTimeOver::class,
		Commands\AutoBalanceTransferCron::class,
		Commands\AutoPurchaseBalanceTransferCron::class,
		Commands\SignUpMail::class,
		Commands\ReminderCron::class,
		Commands\ReminderInvestCron::class,
		Commands\DirectIncomeMail::class,
		Commands\BinaryIncomeMail::class,
		Commands\RoiIncomeMail::class,
		Commands\WithdrawConfirmMailCron::class,
		Commands\WithdrawVerifiedCron::class,
		Commands\CapitalReturnsIncomeCron::class,
		Commands\OptimizedBinaryIncomeNew::class,

	];

	/**
	 * Define the application's command schedule.
	 *
	 * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
	 * @return void
	 */
	protected function schedule(Schedule $schedule) {
		

		
		//this cron is to add the strucutres with topup
		$schedule->command('cron:BulkEntries')->timezone('Europe/London')->withoutOverlapping()->everyFiveMinutes();
		
				
		//this cron is to qualify ids for binary 
		$schedule->command('cron:optimized_binary_qualify')->timezone('Europe/London')->withoutOverlapping()->everyFiveMinutes();
		$schedule->command('cron:optimized_binary_qualify')->timezone('Europe/London')->withoutOverlapping()->dailyAt('23:53');
		$schedule->command('cron:laps_virtual_business')->timezone('Europe/London')->withoutOverlapping()->dailyAt('23:53');
		
		//this cron is to assign binary income to user
		$schedule->command('cron:optimized_binary_income')->timezone('Europe/London')->withoutOverlapping()->dailyAt('23:55');

		
		//this cron is to pass power to upline
		$schedule->command('cron:add_business_upline')->timezone('Europe/London')->withoutOverlapping()->everyFiveMinutes();


		//this cron is to assign ranks
		$schedule->command('cron:AssignRank')->timezone('Europe/London')->withoutOverlapping()->dailyAt('23:25');
		$schedule->command('cron:DemoAssignRankCron')->timezone('Europe/London')->withoutOverlapping()->dailyAt('23:30');
		
		
		//this cron is to assign rank income on every sunday
		$schedule->command('cron:supper_matching_income_new')->timezone('Europe/London')->withoutOverlapping()->weeklyOn(0, '23:45'); 
		$schedule->command('cron:matching_income_new')->timezone('Europe/London')->withoutOverlapping()->weeklyOn(0, '23:45'); 
		
		//this cron is to confirm users payment in coinpayment
		$schedule->command('cron:confirm_transaction')->withoutOverlapping()->everyMinute();


		//this cron to verify the ids to withdrawal
		$schedule->command('cron:withdrawal_verified_mail')->withoutOverlapping()->everyMinute();

		//this cron is for optimized roi income
		$schedule->command('cron:optimized_roi_static')->timezone('Europe/London')->withoutOverlapping()->dailyAt('00:10');

		//this cron is for auto withdrawal
		$schedule->command('cron:auto_withdraw_send')->withoutOverlapping()->everyMinute();

		// Delete 30 days old activity
		$schedule->command('cron:delete_activity')
		    ->timezone('Europe/London')
		    ->withoutOverlapping()
		    ->saturdays()
		    ->at('17:00');
	}

	/**
	 * Register the commands for the application.
	 *
	 * @return void
	 */

	protected function commands() {
		$this->load(__DIR__ . '/Commands');

		require base_path('routes/console.php');
	}
}
