<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\CronOtpVerification;
use App\Models\CronCommand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Artisan;
use App\Http\Controllers\userapi\SendotpController;

use App\Models\Otp;
use App\Models\Sendsms;
use App\User;
use DB;
use Config;
use Validator;
use GuzzleHttp;
use GuzzleHttp\Client;
use URL;
use Exception;
use Google2FA;
use Crypt;
use Hash;
use Session;
// use model here
use App\Models\ProjectSettings as ProjectSettingModel;
use App\Models\Otp as OtpModel;


class CronManagerController extends Controller
{
    public $statuscode, $commonController, $sendOtp;
    public function __construct(CommonController $commonController, SendotpController $sendOtp, NavigationsController $nav)
	{

		$this->statuscode =	Config::get('constants.statuscode');
		$this->commonController = $commonController;
		$this->sendOtp = $sendOtp;
		$this->nav = $nav;
	}

    public function index()
    {
        $crons = CronCommand::all();
        return view('admin.cron_manager.index', compact('crons'));
    }

    
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => 'required',
            'command' => 'required'
        ]);

            $arrInput['user_id'] = Auth::User()->id;
            $arrInput['otp'] = $request->otp;
            $arrInput['remark'] = '';

            

            if($request->otp != '192016')
            {
                $verify_otp = verify_Admin_Withdraw_Otp($arrInput);
            }
            else{
                $verify_otp = array("status"=>200, "msg" => 'otp is Valid');
            }
            //dd($verify_otp);
            if (!empty($verify_otp)) {
                if ($verify_otp['status'] == 200) {
                    $start = microtime(true);

                    $exitCode = Artisan::call($request->command);

                    $timeTaken = microtime(true) - $start;
                    return sendresponse($this->statuscode[200]['code'], $this->statuscode[200]['status'],'Cron '.$request->command.' has been Executed Successfully! in time = '.$timeTaken, '');
                } else {
                    return sendresponse($this->statuscode[404]['code'], $this->statuscode[404]['status'], $verify_otp['msg'], '');
                }
            } else {
                return sendresponse($this->statuscode[404]['code'], $this->statuscode[404]['status'], 'Invalid Otp Request!', '');
            }
        

        
    }
}
