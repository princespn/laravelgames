<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Activitynotification as ActivitynotificationModel;

use App\Models\Dashboard;
use App\Models\Currency;
use App\Models\Resetpassword as ResetpasswordModel;
use App\Models\User as UserModel;
use Config;
use DB;
use Exception;
use Illuminate\Http\Request;
// use model here
use Illuminate\Http\Response as Response;
use PDOException;
use Validator;

use App\Traits\Users;
use Auth;
use URL;
use DataTables;

use Carbon\Carbon;


use App\Http\Controllers\user\Google2FAController;


class DownlinePayoutController extends Controller
{
    public function index()
    {     
        $auth_id = Auth::user()->id;
        $getBalance = Dashboard::select('working_wallet', 'working_wallet_withdraw')->where('id', $auth_id)->first();
        $arrCurrency = Currency::where('withdrwal_status', '=', '1')->where('status', '=', '1')->get();
        $data = ["getBalance" => $getBalance, "currency" => $arrCurrency, "getAllCurrency" => $arrCurrency];
        
        return view('user.downline_payout')->with($data);
    }  

    public function payoutReprot()
    {     
        $auth_id = Auth::user()->id;
        $getBalance = Dashboard::select('working_wallet', 'working_wallet_withdraw')->where('id', $auth_id)->first();
        $arrCurrency = Currency::where('withdrwal_status', '=', '1')->where('status', '=', '1')->get();
        $data = ["getBalance" => $getBalance, "currency" => $arrCurrency, "getAllCurrency" => $arrCurrency];
        
        return view('user.downline_payout_report')->with($data);
    }  



    public function collectWorking(Request $request)
    {
        return $this->collect($request, 'working');
    }

    public function collectRoi(Request $request)
    {
        return $this->collect($request, 'roi');
    }

    /**
     * Core collector:
     * - Downline users are those with tbl_users.structure_id == current user id
     * - Join their dashboards, compute available = wallet - wallet_withdraw (min 0)
     * - Set wallet = wallet_withdraw for each downline user (zero out availability)
     * - Add total available to current user's wallet
     */
    // protected function collect(Request $request, string $type)
    // {
    //     $userId = $request->user()->id;

    //     // Map columns per type
    //     $walletCol        = $type === 'roi' ? 'roi_wallet' : 'working_wallet';
    //     $withdrawCol      = $type === 'roi' ? 'roi_wallet_withdraw' : 'working_wallet_withdraw';

    //     $result = DB::transaction(function () use ($userId, $walletCol, $withdrawCol) {
    //         // Lock all relevant dashboard rows so concurrent requests don’t double-collect
    //         $rows = DB::table('tbl_dashboard as d')
    //             ->join('tbl_users as u', 'u.id', '=', 'd.id')
    //             ->where('u.structure_created_user_id', $userId)                 // downline = users whose structure_id == my id
    //             ->select('d.id',
    //                 DB::raw("GREATEST(d.$walletCol - d.$withdrawCol, 0) as available")
    //             )
    //             ->lockForUpdate()
    //             ->get();

    //         $totalAvailable = (int) $rows->sum('available');
    //         $affectedUsers  = $rows->count();
    //         $downlineIds    = $rows->pluck('id')->all();
    //         //dd($downlineIds);

    //         if ($affectedUsers > 0) {
    //             // Zero out available by setting wallet = wallet_withdraw on those users
    //             DB::table('tbl_dashboard')
    //                 ->whereIn('id', $downlineIds)
    //                 ->update([$withdrawCol => DB::raw($walletCol)]);
    //         }

    //         // Credit the total into current user's wallet (lock my row first)
    //         DB::table('tbl_dashboard')
    //             ->where('id', $userId)
    //             ->lockForUpdate()
    //             ->increment($walletCol, $totalAvailable);

    //         return [
    //             'total_added'   => $totalAvailable,
    //             'users_count'   => $affectedUsers,
    //         ];
    //     });

    //     return response()->json([
    //         'ok'           => true,
    //         'type'         => $type,
    //         'total_added'  => $result['total_added'],
    //         'users_count'  => $result['users_count'],
    //         'message'      => "Added {$result['total_added']} to your {$walletCol} from {$result['users_count']} downline users.",
    //     ]);
    // }

    protected function collect(Request $request, string $type)
{
    $userId = $request->user()->id;

    // Column mapping (kept exactly as your logic expects)
    $walletCol   = $type === 'roi' ? 'roi_wallet' : 'working_wallet';
    $withdrawCol = $type === 'roi' ? 'roi_wallet_withdraw' : 'working_wallet_withdraw';

    $result = DB::transaction(function () use ($userId, $walletCol, $withdrawCol, $type) {
        // 1) Lock relevant rows
        $rows = DB::table('tbl_dashboard as d')
            ->join('tbl_users as u', 'u.id', '=', 'd.id') // kept as you have it
            ->where('u.structure_created_user_id', $userId) // kept your filter
            ->select(
                'd.id', // this is used as "moved_from_userid" below
                DB::raw("GREATEST(d.$walletCol - d.$withdrawCol, 0) as available")
            )
            ->lockForUpdate()
            ->get();

        // 2) Totals and lists
        $totalAvailable = (float) $rows->sum('available');
        $affectedUsers  = $rows->count();
        $downlineIds    = $rows->pluck('id')->all(); // ids from d.id (your schema)

        if ($affectedUsers > 0) {
            // 3) Insert pull history BEFORE clearing balances
            $now = now();
            $historyPayload = $rows->map(function ($r) use ($userId, $type, $now) {
                $available = (float) $r->available;
                if ($available <= 0) {
                    return null; // skip zero rows
                }
                return [
                    'moved_to_userid'              => $userId,
                    'moved_from_userid'            => $r->id, // from d.id per your select
                    'working_wallet_balance_moved' => $type === 'working' ? $available : 0.00,
                    'roi_wallet_balance_moved'     => $type === 'roi'     ? $available : 0.00,
                    'created_at'                   => $now,
                    'updated_at'                   => $now,
                ];
            })->filter()->values()->all();

            if (!empty($historyPayload)) {
                DB::table('tbl_pull_history')->insert($historyPayload);
            }

            // 4) Zero out available (kept your direction: set withdraw = wallet)
            DB::table('tbl_dashboard')
                ->whereIn('id', $downlineIds)
                ->update([$withdrawCol => DB::raw($walletCol)]);
        }

        // 5) Credit the total to current user's wallet (lock my row first)
        DB::table('tbl_dashboard')
            ->where('id', $userId)
            ->lockForUpdate()
            ->increment($walletCol, $totalAvailable);

        return [
            'total_added'  => $totalAvailable,
            'users_count'  => $affectedUsers,
        ];
    });

    return response()->json([
        'ok'          => true,
        'type'        => $type,
        'total_added' => $result['total_added'],
        'users_count' => $result['users_count'],
        'message'     => "Added {$result['total_added']} to your {$walletCol} from {$result['users_count']} downline users.",
    ]);
}




public function structureIncome(Request $request)
{
    try {
        $UserExistid = Auth::id();
        if (empty($UserExistid)) {
            return sendResponse(
                \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND,
                'Not Found',
                'Invalid user',
                ''
            );
        }

        // defaults for DataTables
        $start  = (int) ($request->input('start', 0));
        $length = (int) ($request->input('length', 10));
        if ($length <= 0) $length = 10;

        // base query
        $base = DB::table('tbl_users as tu')
            ->join('tbl_dashboard as td', 'tu.id', '=', 'td.id')
            ->select(
                'tu.user_id',
                'tu.id',
                DB::raw('(td.working_wallet - td.working_wallet_withdraw) as available_balance_working'),
                DB::raw('(td.roi_wallet - td.roi_wallet_withdraw) as available_balance_roi'),
                'td.id as dashboard_id',
                'td.srno'
            )
            ->where('tu.structure_created_user_id', $UserExistid);
            //dd($base->toSql());
            //dd( $base->getBindings());

        // total count (use alias!)
        $totalRecord = (clone $base)->count('tu.id');
        

        // page data
        $records = (clone $base)
            ->orderBy('available_balance_working', 'desc')
            ->skip($start)
            ->take($length)
            ->get();

        $arrData = [
            'recordsTotal'    => $totalRecord,
            'recordsFiltered' => $totalRecord,
            'records'         => $records,
        ];

        if ($records->isNotEmpty()) {
            return sendResponse(
                \Symfony\Component\HttpFoundation\Response::HTTP_OK,
                'OK',
                'Structure data found successfully',
                $arrData
            );
        }

        return sendResponse(
            \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND,
            'Not Found',
            'Structure data not found',
            $arrData
        );

    } catch (\Throwable $e) {
        // Log::error($e); // optional
        return sendResponse(
            \Symfony\Component\HttpFoundation\Response::HTTP_INTERNAL_SERVER_ERROR,
            'Internal Server Error',
            'Something went wrong, please try again',
            ''
        );
    }
}




public function structureIncomeReport(Request $request)
{
    try {
        $UserExistid = Auth::id();
        if (empty($UserExistid)) {
            return sendResponse(
                \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND,
                'Not Found',
                'Invalid user',
                ''
            );
        }

        // defaults for DataTables
        $start  = (int) ($request->input('start', 0));
        $length = (int) ($request->input('length', 10));
        if ($length <= 0) $length = 10;

        // base query
        // Base: pull history + resolve to/from user_id (codes) from tbl_users.id
        $base = DB::table('tbl_pull_history as ph')
                    ->join('tbl_users as tu_to',   'tu_to.id',   '=', 'ph.moved_to_userid')
                    ->join('tbl_users as tu_from', 'tu_from.id', '=', 'ph.moved_from_userid')
                    ->select(
                        'ph.srno',
                        'ph.moved_to_userid',
                        DB::raw('tu_to.user_id as to_user_id'),
                        'ph.moved_from_userid',
                        DB::raw('tu_from.user_id as from_user_id'),
                        'ph.working_wallet_balance_moved',
                        'ph.roi_wallet_balance_moved',
                        'ph.created_at',
                        'ph.updated_at'
                    );

            //dd($base->toSql());
            //dd( $base->getBindings());

            // Inputs for date filter
          $arrInput = $request->all(); 
        // 
        if (isset($arrInput['frm_date']) && isset($arrInput['to_date'])) {
            $arrInput['frm_date'] = date('Y-m-d', strtotime($arrInput['frm_date']));
            $arrInput['to_date']  = date('Y-m-d', strtotime($arrInput['to_date']));
            $base = $base->whereBetween(DB::raw("DATE_FORMAT(ph.created_at,'%Y-%m-%d')"), [$arrInput['frm_date'], $arrInput['to_date']]);
        }

        // total count (use alias!)
        $totalRecord = (clone $base)->count('ph.srno');
        

        // page data
        $records = (clone $base)
            ->orderBy('ph.srno', 'desc')
            ->skip($start)
            ->take($length)
            ->get();

        $arrData = [
            'recordsTotal'    => $totalRecord,
            'recordsFiltered' => $totalRecord,
            'records'         => $records,
        ];

        if ($records->isNotEmpty()) {
            return sendResponse(
                \Symfony\Component\HttpFoundation\Response::HTTP_OK,
                'OK',
                'Structure data found successfully',
                $arrData
            );
        }

        return sendResponse(
            \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND,
            'Not Found',
            'Structure data not found',
            ''
        );

    } catch (\Throwable $e) {
        // Log::error($e); // optional
        return sendResponse(
            \Symfony\Component\HttpFoundation\Response::HTTP_INTERNAL_SERVER_ERROR,
            'Internal Server Error',
            'Something went wrong, please try again',
            ''
        );
    }
}


}
