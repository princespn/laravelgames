<?php

namespace App\Http\Controllers\user;


class ForgotPasswordController extends Controller
{

	public $arrOutputData = [];

	public function index()
	{
		return view('website.index');
	}
	
}
