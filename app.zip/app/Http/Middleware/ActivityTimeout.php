<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class ActivityTimeout
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if (Auth::check()) {
            $timeout = config('session.lifetime') * 60; // Session lifetime in seconds
            $lastActivity = Session::get('lastActivityTime');
            $currentTime = time();

            if ($lastActivity && ($currentTime - $lastActivity) > $timeout) {
                Auth::logout();
                Session::flush(); // Optionally clear the session
                if ($request->is('1Rto5efWp86Z/*')) {
                    return '/1Rto5efWp86Z/login';
                }
                return redirect('/login')->with('message', 'You have been logged out due to inactivity.');
            }

            Session::put('lastActivityTime', $currentTime);
        }

        return $next($request);
    }
}
