<?php
namespace App\Services\Payments;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;

class DogeService
{
    protected Client $client;
    protected string $apiKey;

    public function __construct()
    {
        $this->client = new Client([
            'base_uri' => config('services.doge.provider_url'),
            'timeout' => 30,
        ]);
        $this->apiKey = config('services.doge.key');
    }

    public function createTransaction($amount, $currencyCode, $email, array $extra = [])
    {
        try {
            $payload = array_merge([
                'amount' => (float)$amount,
                'currency' => $currencyCode,
                'email' => $email,
            ], $extra);

            $resp = $this->client->post('/create-transaction', [
                'headers' => [
                    'Accept' => 'application/json',
                    'x-api-key' => $this->apiKey,
                ],
                'form_params' => $payload,
            ]);

            $result = json_decode((string) $resp->getBody(), true);

            if (!empty($result['msg']) && $result['msg'] === 'success') {
                return $result;
            }

            if (!empty($result['address'])) {
                return [
                    'msg' => 'success',
                    'address' => $result['address'],
                    'data' => $result['data'] ?? [],
                ];
            }

            return ['msg' => 'failed', 'error' => $result];

        } catch (RequestException $e) {
            Log::error('DogeService error: '.$e->getMessage(), [
                'payload' => $payload,
                'response' => $e->hasResponse() ? (string)$e->getResponse()->getBody() : null,
            ]);
            return ['msg' => 'failed', 'error' => $e->getMessage()];
        }
    }
}
