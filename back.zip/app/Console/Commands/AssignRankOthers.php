<?php

namespace App\Console\Commands;

use App\Models\Rank;
use App\Models\TodayDetails;
use Illuminate\Console\Command;
use DB;
use App\Models\supermatching;

class AssignRankOthers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:AssignRankOthers';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description 1';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $users = DB::table('tbl_users')
                ->select('*')
                ->where('topup_status', '1')
                ->where('alfa_status', 1)
                ->get();

        
        foreach ($users as $value) {

            $ranklist = Rank::select('*')->where('status',1)->where('alchk',1)->get();

            $todaycount_left = DB::table('tbl_today_details')
            ->join('tbl_users', 'tbl_today_details.from_user_id', '=', 'tbl_users.id')
            ->where('tbl_today_details.position', 1)
            ->where('tbl_today_details.to_user_id', $value->id)
            ->where('tbl_users.alfa_status', 1)
            ->select('tbl_today_details.*') 
            ->get();


            $todaycount_right = DB::table('tbl_today_details')
            ->join('tbl_users', 'tbl_today_details.from_user_id', '=', 'tbl_users.id')
            ->where('tbl_today_details.position', 2)
            ->where('tbl_today_details.to_user_id', $value->id)
            ->where('tbl_users.alfa_status', 1)
            ->select('tbl_today_details.*') 
            ->get();
            
            $updatedrank = 0;
            for($i = 0; $i < count($ranklist); $i++)
            {
                if (count($todaycount_left) >= $ranklist[$i]->left_ace_req && count($todaycount_right) >= $ranklist[$i]->right_ace_req) {
                    $updatedrank = $ranklist[$i]->id;
                }
            }


            if($updatedrank != 0)
            {
                $usersupdate = array();
                $usersupdate['rank'] = $updatedrank;
                DB::table('tbl_users')->where('id', $value->id)->update($usersupdate);
            }



        }
    }
}