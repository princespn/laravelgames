<?php

namespace App\Console\Commands;

use App\Dashboard;
use Illuminate\Console\Command;
use DB;
use App\Models\supermatching;
use App\Models\RankRewardHistory;
use App\Models\User;

class AssignRankReward extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:AssignRankReward';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $date = \Carbon\Carbon::now();
        $this->today = $date->toDateTimeString();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $users = DB::table('tbl_users as tu')
                ->select('td.binary_income', 'td.hscc_bonus_income', 'td.hscc_bonus_wallet', 'tu.user_id', 'tu.rank_reward', 'tu.rank_reward_id', 'tu.id')
                ->join('tbl_dashboard as td','td.id', '=','tu.id')
                ->get();
        
        foreach ($users as $value) {

            $rankrewards = DB::table('rank_rewards_list')
                ->select('*')
                ->where('binary_income_required', '<', $value->binary_income)
                ->orderBy('sr_no', 'desc')
                ->limit(1)
                ->first();

            if($rankrewards != null)
            {
                if($value->rank_reward_id != $rankrewards->sr_no)
                {
                    $newrankuserupdate['rank_reward'] = $rankrewards->rank_name;
                    $newrankuserupdate['rank_reward_id'] = $rankrewards->sr_no;
                    $update_status = User::where([['id',$value->id]])->limit(1)->update($newrankuserupdate);

                    $newrankhistory['achived_rank_id'] = $rankrewards->sr_no;
                    $newrankhistory['user_id'] = $value->id;
                    $newrankhistory['created_at'] = $this->today;
                    $insertAdd = RankRewardHistory::create($newrankhistory);

                    $dashboardupdate['hscc_bonus_income'] = $value->hscc_bonus_income + $rankrewards->reward_points;
                    $dashboardupdate['hscc_bonus_wallet'] = $value->hscc_bonus_wallet + $rankrewards->reward_points;
                    DB::table('tbl_dashboard')
                        ->where('id', '=', $value->id)
                        ->update($dashboardupdate);

                    echo "rank updated ... \n";
                }
                else{

                }

            }
            else{

            }

           
        }
    }
}
