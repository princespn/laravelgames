<?php

namespace App\Console\Commands;

use App\Models\Dashboard;
use Illuminate\Console\Command;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\adminapi\EWalletController;
use App\Http\Controllers\userapi\SettingsController;
use App\User;
use App\Models\WithdrawPending;
use App\Models\WithdrawalConfirmed;
use App\Models\CronRunStatus;
use App\Models\ProjectSetting;
use App\Models\CronStatus;
use App\Models\Names;
use Mail;

class AutoSendCron extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:auto_withdraw_send';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Withdraw';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(EWalletController $ewallet,SettingsController $settings) {
        parent::__construct();
        $this->ewallet = $ewallet;
        $this->settings = $settings;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle() {

      $croncheck= CronStatus::select('*')->where('name',$this->signature)->first();

      if($croncheck->status ==1)
      {
      echo "this cron is active\n";

        //  $day = date('D');
        //  if ($day != "Mon") {
        //     dd("This cron only allowed on monday ...");
        //  }
        
        $cronStatus = ProjectSetting::select('auto_withdrawal_cron')->where('id', '=', 1)->first();
          
        if ($cronStatus->auto_withdrawal_cron == 1) {
          dd("Auto Withdrawal Cron is currently stopped...");
        }

        $with_req = WithdrawPending::select('tbl_withdrwal_pending.*','tu.user_id','tu.id as tuid')->join('tbl_users as tu','tu.id','=','tbl_withdrwal_pending.id')
           ->where([['tbl_withdrwal_pending.status',0],['tbl_withdrwal_pending.verify',1]])->orderBy('sr_no','desc')
           /*->limit(1)*/
           //->where('tbl_withdrwal_pending.sr_no',21)
           ->get();
           
         $now = \Carbon\Carbon::now()->toDateTimeString();
              
              $arrInput = [];
              foreach($with_req as $wr){

                  $dashboarddata = Dashboard::select('*')->where([['id', $wr->tuid]])->first();
                  if($wr->withdraw_type == 2)
                  {
                    if(($dashboarddata->working_wallet - ($dashboarddata->working_wallet_locked_tokens + $dashboarddata->working_wallet_withdraw)) >= 0)
                    {
                        if($now >= $wr->entry_time){

                          $arrInput['srno'] = $wr->sr_no;
                          if($wr->remark == "")
                          {
                            $arrInput['remark'] = "Withdrawal processed";
                          }
                          else{
                            $arrInput['remark'] = $wr->remark;
                          }
    
    
                          $checkExist = WithdrawalConfirmed::where('wp_ref_id',$wr->sr_no)->first();
                          if(empty($checkExist)){
    
                              $req = new Request;
                              $req['address'] = $wr->to_address;
                              $req['id'] = $wr->id;
                              $req['network_type'] = $wr->network_type;
                              $checkvalidAddress =  $this->settings->checkAddresses($req);
                              //dd($wr->to_address,$checkvalidAddress->original['code']);
                              /*if($checkvalidAddress->original['code'] == 200){*/
                              // dd($this->settings);
                              // dd('hiii');
                              $callcron = 1;
    
                              $arrInput['cron_payment'] = 'cron';
    
                            $res = $this->ewallet->PaymentsSendApiNew($wr,$arrInput,'coinpayment',$callcron);
    
                            echo $res;
    
                          /*}*/
                          }
                        }else{
                        //dd('hiiii');
                        }
                    }
                    else{
                      echo "withdrawal not allowed for user = ".$wr->user_id." = ".$wr->sr_no."\n\n";
                    }
                  }
                  else if($wr->withdraw_type == 1) 
                  {
                    echo $dashboarddata->binary_income_tokens." = ".($dashboarddata->binary_income_withdraw + $dashboarddata->working_wallet_binary_locked_tokens);
                    if(($dashboarddata->binary_income_tokens - ($dashboarddata->binary_income_withdraw + $dashboarddata->working_wallet_binary_locked_tokens)) >= 0)
                    {
                        if($now >= $wr->entry_time){

                          $arrInput['srno'] = $wr->sr_no;
                          if($wr->remark == "")
                          {
                            $arrInput['remark'] = "Withdrawal processed";
                          }
                          else{
                            $arrInput['remark'] = $wr->remark;
                          }
    
    
                          $checkExist = WithdrawalConfirmed::where('wp_ref_id',$wr->sr_no)->first();
                          if(empty($checkExist)){
    
                              $req = new Request;
                              $req['address'] = $wr->to_address;
                              $req['id'] = $wr->id;
                              $req['network_type'] = $wr->network_type;
                              $checkvalidAddress =  $this->settings->checkAddresses($req);
                              //dd($wr->to_address,$checkvalidAddress->original['code']);
                              /*if($checkvalidAddress->original['code'] == 200){*/
                              // dd($this->settings);
                              // dd('hiii');
                              $callcron = 1;
    
                              $arrInput['cron_payment'] = 'cron';
    
                            $res = $this->ewallet->PaymentsSendApiNew($wr,$arrInput,'coinpayment');
    
                            echo $res;
    
                          /*}*/
                          }
                        }else{
                        //dd('hiiii');
                        }
                    }
                    else{
                      echo "withdrawal not allowed  for user = ".$wr->user_id." = ".$wr->sr_no."\n\n";
                    }

                  }
                  else{

                    if($now >= $wr->entry_time){

                      $arrInput['srno'] = $wr->sr_no;
                      if($wr->remark == "")
                      {
                        $arrInput['remark'] = "Withdrawal processed";
                      }
                      else{
                        $arrInput['remark'] = $wr->remark;
                      }


                      $checkExist = WithdrawalConfirmed::where('wp_ref_id',$wr->sr_no)->first();
                      if(empty($checkExist)){

                          $req = new Request;
                          $req['address'] = $wr->to_address;
                          $req['id'] = $wr->id;
                          $req['network_type'] = $wr->network_type;
                          $checkvalidAddress =  $this->settings->checkAddresses($req);
                          //dd($wr->to_address,$checkvalidAddress->original['code']);
                          /*if($checkvalidAddress->original['code'] == 200){*/
                          // dd($this->settings);
                          // dd('hiii');
                          $callcron = 1;

                          $arrInput['cron_payment'] = 'cron';

                        $res = $this->ewallet->PaymentsSendApiNew($wr,$arrInput,'coinpayment',$callcron);

                        echo $res;

                      /*}*/
                      }
                    }else{
                    //dd('hiiii');
                    }

                  }

                  
              }        
            $cronRunEntry=new CronRunStatus();
          $cronRunEntry['cron_id'] =$croncheck->id;
          $cronRunEntry['run_status'] =1;
          $cronRunEntry['run_time'] =$now;
          $cronRunEntry->save();



    }
    else{
        echo "this cron is inactive \n";
      }
  }

}
