<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Config;
use App\Models\Topup;
use App\Models\DifferentiateSetting;
use App\Models\DifferentiateIncome;
use App\Models\DifferentiateLevelIncome;
use App\Models\LevelView;
use App\User;
use App\Dashboard;
use Carbon\Carbon;
use DB;

class DifferentiateIncomeCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:differentiate_income';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Differentiate Income Cron';
    /**
     * Create a new command instance.
     *
     * @return void
     */

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    
    public function handle(){

        $start = microtime(true);
        $this->info('Differentiate Cron started at ' . Carbon::now()->toDateTimeString());

        $users = User::select("id", "user_id")
            ->where('topup_status', '1')
            ->where('amount', '>', 0)
            ->where('status','=','Active')
            ->get();

        if ($users->isNotEmpty()) {

            foreach($users as $user){

                $max_topup = LevelView::join('tbl_topup as ttp', 'ttp.id', 'tbl_level_view.down_id')
                    ->selectRaw('SUM(ttp.amount) as total, ttp.id')
                    ->where('tbl_level_view.id', $user->id)
                    ->groupBy('ttp.id')
                    ->orderByDesc('total')
                    ->first();

                if ($max_topup !== null || !empty($max_topup)) 
                {
                 
                    $all_amount = LevelView::where('tbl_level_view.id', $user->id)
                        ->join('tbl_topup as ttp', 'ttp.id', 'tbl_level_view.down_id')
                        ->where('ttp.id', '!=', $max_topup->id)
                        ->selectRaw('sum(ttp.amount) as total_investment')
                        ->first();

                    $singleLegTotal = min($max_topup->total ?? 0, $all_amount->total_investment ?? 0);

                    $legTotal = ($max_topup->total ?? 0) + ($all_amount->total_investment ?? 0);

                    $matchingSum = DifferentiateIncome::where([['user_id', $user->id], ['rank', '!=', '']])->sum('matching');
                    $minMatchingSum = DifferentiateIncome::where([['user_id', $user->id], ['rank', '!=', '']])->sum('min_matching');

                    if (empty($matchingSum)) {
                        $matchingSum = 0;
                        $minMatchingSum = 0;
                    }

                    $assignRank = DifferentiateSetting::select('id', 'bv', 'min_bv', 'rank', 'percentage')
                        ->whereRaw('bv + ? <= ?', [$matchingSum, $legTotal])
                        ->whereRaw('min_bv + ? <= ?', [$minMatchingSum, $singleLegTotal])
                        ->orderBy('id', 'desc')
                        ->get();

                    if ($assignRank->isNotEmpty()) {

                        foreach ($assignRank as $data) {

                            $count = DifferentiateIncome::where('user_id', $user->id)
                                ->where('level_id','>=', $data->id)
                                ->count();

                            if($count <= 0){  

                                $amount = (($data->bv*$data->percentage)/100);
                              
                                $insertdata = new DifferentiateIncome;
                                $insertdata->user_id = $user->id;
                                $insertdata->level_id = $data->id;
                                $insertdata->matching = $data->bv;
                                $insertdata->percentage = $data->percentage;
                                $insertdata->min_matching = $data->min_bv;
                                $insertdata->rank = $data->rank;
                                $insertdata->amount = $amount;
                                $insertdata->remark = 'Team Business';
                                $insertdata->entry_time = Carbon::now()->toDateTimeString();
                                $insertdata->save();
                                
                                $dashData = Dashboard::select('fund_wallet','usd','total_profit')->where('id',$user->id)->first(); 
                                $updatedata=array();
                                $updatedata['fund_wallet']=($dashData->fund_wallet)+($data->amount); 
                                $updatedata['usd']=($dashData->usd)+($data->amount); 
                                $updatedata['total_profit']=($dashData->total_profit)+($data->amount); 
                                Dashboard::where('id',$user->id)->update($updatedata);

                                $this->info("username --> " . $user->id . " got Rank --> ". $data->rank . " successfully");
                            }
                        }
                    }
                }
            }     
        }
        
        // Differentiate Income Distribution to other level
        $getLevel = DifferentiateIncome::where('level_status', 0)->get();

        if ($getLevel->isNotEmpty()) {
            foreach ($getLevel as $gl) {

                $level_ids = LevelView::join('tbl_differentiate_income as ttp', 'tbl_level_view.id', '=', 'ttp.user_id')
                    ->where('tbl_level_view.down_id', $gl->user_id)
                    ->where('ttp.level_id', '>', $gl->level_id)
                    ->select('tbl_level_view.id as user_id', 'tbl_level_view.level', 'ttp.level_id', 'ttp.amount', 'ttp.percentage')
                    ->get();

                if ($level_ids->isNotEmpty()) {
                    foreach ($level_ids as $lid) {
                        if ($gl->percentage < $lid->percentage) {
                            $percentage = $lid->percentage - $gl->percentage;
                            $amount = ($lid->amount * $percentage) / 100;

                            // Insert into DifferentiateLevelIncome
                            $insert = new DifferentiateLevelIncome;
                            $insert->from_user_id = $gl->user_id;
                            $insert->to_user_id = $lid->user_id;
                            $insert->amount = $amount;
                            $insert->on_percentage = $percentage;
                            $insert->level = $lid->level;
                            $insert->entry_time = now();
                            $insert->save();

                            // Update level_status for $gl
                            DifferentiateIncome::where('user_id', $gl->user_id)
                                ->where('level_status', 0)
                                ->where('level_id', $gl->level_id)
                                ->update(['level_status' => 1]);

                            // Update Dashboard data for $lid
                            $updateDashData = Dashboard::select('fund_wallet', 'usd', 'total_profit')
                                ->where('id', $lid->user_id)
                                ->first();

                            $updatedata = [
                                'fund_wallet' => $updateDashData->fund_wallet + $amount,
                                'usd' => $updateDashData->usd + $amount,
                                'total_profit' => $updateDashData->total_profit + $amount,
                            ];

                            Dashboard::where('id', $lid->user_id)->update($updatedata);
                        }
                    }
                }
            }
        }

        $elapsedTime = round(microtime(true) - $start, 2);
        $this->info('Differentiate Cron completed in ' . $elapsedTime . ' seconds');
    }
}