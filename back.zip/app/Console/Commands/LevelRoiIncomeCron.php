<?php

namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Config;
use App\Models\Topup;
use App\Models\DailyBonus;
use App\Models\Product;
use App\Models\LevelIncomeRoi;
use App\Models\LevelRoi;
use App\User;
use App\Dashboard;
use DB;

class LevelRoiIncomeCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:Level_roi_income';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Level Roi Cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function getlevelroi($counter){
        return \Cache::remember("levelroiincome_".$counter, 720, function() use ($counter){
            return LevelRoi::where([['level_id', '=', $counter]])->select('percentage')->first();
            });
    }

    
    public function handle()
    {
        list($usec, $sec) = explode(" ", microtime());
        $time_start1 = ((float)$usec + (float)$sec);
        DB::raw('LOCK TABLES `tbl_dashboard` WRITE');
        DB::raw('LOCK TABLES `tbl_level_income_roi` WRITE');

       // DB::enableQueryLog();
        $allTopus = DailyBonus::selectRaw('tbl_dailybonus.sr_no,tbl_dailybonus.pin,tbl_dailybonus.entry_time,tbl_dailybonus.type,tbl_dailybonus.on_amount,tbl_dailybonus.id')
        ->join('tbl_dashboard as td', 'td.id', '=', 'tbl_dailybonus.id')
        ->where('tbl_dailybonus.level_roi_status', 0)->where('tbl_dailybonus.amount','>',0)->get();

        //dd(DB::getQueryLog()); 
        $insert_alldailyroilevelbonus_arr = array();
        $insert_alldashborad_while = array();
        $insert_alldailyreport_while = array();
        $pin_arr = array();
            
            foreach ($allTopus as $tp => $v) {
                $intrid = $v->id;
                $pacakgeId = $v->type;
                $counter = 1; 
                $insert_dailyroilevelbonus_arr = array();
                $insert_dashborad_while = array();
                $insert_dailyreport_while = array();
             do {
                  $ref_user_id = User::where('id', '=', $intrid)->pluck('ref_user_id')->first();
                  
                    if (isset($ref_user_id)) {

                        $payamt = $this->getlevelroi($counter);
                       //dd($payamt->percentage);
                        if(isset($payamt)){
                            $level_roi = (($v->amount * $payamt->percentage)/100);
                            list($usec, $sec) = explode(" ", microtime());
                            $time_start = ((float)$usec + (float)$sec);
                            
                            $leveldata = array();    
                            $leveldata['amount'] = $level_roi;
                            $leveldata['amt_pin'] = $v->amount;
                            $leveldata['level'] = $counter;
                            $leveldata['toUserId'] = $ref_user_id;
                            $leveldata['fromUserId'] = $v->id;
                            $leveldata['status'] = 1;
                            $leveldata['entry_time'] = $v->entry_time;
                            $leveldata['pin'] = $v->pin;
                            $leveldata['type'] = $pacakgeId;
                            //$insertLevelDta = LevelIncomeRoi::create($leveldata);
                            
                             //Level ROI Dashboard Update
                            $updateCoinData = array();
                            $updateCoinData['id'] = $ref_user_id;
                            $updateCoinData['working_wallet'] = $level_roi;
                            $updateCoinData['level_income_roi'] = $level_roi;
                            
                            array_push($insert_dailyroilevelbonus_arr, $leveldata);
                            array_push($insert_dashborad_while, $updateCoinData);  
                        }
                    }
                    $intrid = $ref_user_id;
                    $counter++;
                }  while ($counter <= 15);
             
                array_push($pin_arr, $v->sr_no);

                foreach ($insert_dailyroilevelbonus_arr as  $val) {
                    array_push($insert_alldailyroilevelbonus_arr, $val);
                }

                foreach ($insert_dashborad_while as  $val1) {
                    array_push($insert_alldashborad_while, $val1);
                }
                
                echo "\n level roi srno " . $v->sr_no . "\n"; 
            }

            //LevelIncomeRoi
            $count = 1;
            $array = array_chunk($insert_alldailyroilevelbonus_arr, 5000);
            while ($count <= count($array)) {
                $key = $count - 1;
                LevelIncomeRoi::insert($array[$key]);
                echo $count . " Insert LevelROIIncome " . count($array[$key]) . "\n";
                $count++;
            }
            //DailyBonus
            $count3 = 1;     
            $array3 = array_chunk($pin_arr,5000);
            while($count3 <= count($array3))
            {
              $key3 = $count3-1;
              DailyBonus::whereIn('sr_no',$array3[$key3])->update(['level_roi_status'=>1]);
              echo $count3." Update DailyBouns Table ".count($array3[$key3])."\n";
              $count3 ++;
            }
             
            //Dashboard
            $dashCount = 1; 
            $dasharray = array_chunk($insert_alldashborad_while,5000);
            while($dashCount <= count($dasharray))
            {   
                $dashk = $dashCount-1;
                $arrProcess = $dasharray[$dashk];
                $mainArr = array();
                foreach ($arrProcess as $k => $v) {
                    $mainArr[$v['id']]['id'] = $v['id'];                   
                    if (!isset($mainArr[$v['id']]['working_wallet']) && !isset($mainArr[$v['id']]['level_income_roi'])) {
                        $mainArr[$v['id']]['level_income_roi']=$mainArr[$v['id']]['working_wallet']=0;                      
                    }
                    $mainArr[$v['id']]['working_wallet'] += $v['working_wallet']; 
                    $mainArr[$v['id']]['level_income_roi'] += $v['level_income_roi']; 
                }
               
                $ids = implode(',', array_column($mainArr, 'id'));

                $working_wallet_qry = 'working_wallet = (CASE id';
                $level_income_roi_qry = 'level_income_roi = (CASE id';

                foreach ($mainArr as $key => $val) {
                    $working_wallet_qry = $working_wallet_qry . " WHEN ".$val['id']." THEN working_wallet + ".$val['working_wallet'];            
                    $level_income_roi_qry = $level_income_roi_qry . " WHEN ".$val['id']." THEN level_income_roi + ".$val['level_income_roi'];                
                }

              $working_wallet_qry = $working_wallet_qry . " END)";              
              $level_income_roi_qry = $level_income_roi_qry . " END)";      
              
              $updt_qry = "UPDATE tbl_dashboard SET  ".$working_wallet_qry." , ".$level_income_roi_qry." WHERE id IN (".$ids.")";
              $updt_user = DB::statement(DB::raw($updt_qry));                     
             
              echo $dashCount." Update Dashboard Table ".count($mainArr)."\n";
              $dashCount ++;
          }
          DB::raw('UNLOCK TABLES');
    }
}