<?php

namespace App\Console\Commands;

use App\Models\Rank;
use Illuminate\Console\Command;
use App\Policies\BinaryIncomeClass;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Config;
use DB;
use App\User;
use App\Models\ProjectSettings;
use App\Models\PayoutHistory;
use App\Models\Product;
use App\Models\DailyBonus;
use App\Models\Packages;
use App\Models\Topup;
use App\Models\QualifiedUserList as QualifiedUsers;
use App\Traits\Users;
use App\Models\Dashboard;
use App\Models\Carrybv;
use App\Models\CoinRate;
use App\Models\CurrentAmountDetails;
use App\Models\SpecialPowerBv;


class OptimizedBinaryIncomeNew extends Command
{

    use Users;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:optimized_binary_income_new';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Binary income on amount';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(BinaryIncomeClass $objBinaryIncome){
        parent::__construct();
        $this->objBinaryIncome = $objBinaryIncome;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /*dd('Please run queries first');*/
        list($usec, $sec) = explode(" ", microtime());

        $time_start1 = ((float)$usec + (float)$sec);
        $now = \Carbon\Carbon::now();
        $day=date('D', strtotime($now));
        $current_time = \Carbon\Carbon::now()->toDateTimeString();

        $msg = "Binary Cron started at ".$current_time;
        //sendSMS($mobile,$msg);
        echo $msg."\n";

        echo "start ".now()."\n";

        
   
        

        $updatetopupArr= array();

        $getUserDetails = User::select("id","curr_l_bv","curr_r_bv","binary_qualified_status","topup_status", "manual_binary_capping", "manual_binary_capping_daily", "binary_sell_deduction", "binary_deduction_percent", "binary_deduction_upto_amount", "user_wise_binary_capping_limit",
        /*,"l_ace_check_status","r_ace_check_status"*/)
        ->where([['curr_l_bv','>',0],['rank', '!=', NULL],['curr_r_bv','>',0],['status','=',"Active"],['type','!=',"Admin"],['binary_qualified_status',1]])
        //->limit(1)
        ->get();

       // ['binary_qualified_status','=',1],['topup_status','=',"1"];
       //dd($getUserDetails);
        
        $binary_count = 0;
        if(!empty($getUserDetails))
        {

          $totalmatchbv = 0;
          foreach ($getUserDetails as $key => $value) 
            {
              $left_bv=$getUserDetails[$key]['curr_l_bv']; 
              $right_bv=$getUserDetails[$key]['curr_r_bv'];
              $getVal=min($left_bv,$right_bv);
              $totalmatchbv = $totalmatchbv + $getVal;

              
            }


            // Get the current date
            $today = Carbon::today();

            // Get today's sum of amounts for all IDs
            $todaysTotalTopup = Topup::whereDate('entry_time', $today)
                                ->sum('amount');


            echo "Topup Total  = ".$todaysTotalTopup." \n\n";
            echo "Total Match BV  = ".$totalmatchbv." \n\n";



            $calculate20 = $todaysTotalTopup * 0.20;
            $totalmatchbv = $totalmatchbv * 0.05;

            $distributionamount = $calculate20 / $totalmatchbv;

            echo "Per User Distribution Amount = ".$distributionamount." \n\n";



            


            $insert_carrybv_arr = array();
            $insert_payout_arr = array();
            $update_currbv_arr = array();
            $update_dash_arr = array();
            foreach ($getUserDetails as $key => $value) 
            {

              $rankdetails = Rank::select('*')->where('id',$value->rank)->first();

              $binary_per = $rankdetails->income_percentage;

              


              
              $check2directactive = User::select("*")
              ->where([['status','=',"Active"],['type','!=',"Admin"],['ref_user_id', "=", $value->id],["topup_status", "=", '1']])
              ->count();
              

              $topup_type = Topup::select('type')
                    ->where('id',$value->id)
                    ->orderBy('entry_time','desc')->first(); 

              $usertopupamount = Topup::where('id', $value->id)
                    ->orderBy('entry_time', 'desc')
                    ->sum('amount');

              $highestusertopupamount =  Topup::where('id', $value->id)
              ->orderBy('entry_time', 'desc')
              ->sum('amount');    


              $projectSettings = ProjectSettings::where('status', 1)->select('*')->first();
              
              if($value->manual_binary_capping == 0)
              {
                $completeBinaryCapping = $rankdetails->capping;
              }
              else{
                  $completeBinaryCapping = $rankdetails->capping;
              }
              
              $binaryReceivedTillNow = PayoutHistory::where('user_id', $value->id)
                    ->orderBy('entry_time', 'desc')
                    ->sum('amount');

                    
              $completeBinaryCappingPending = $completeBinaryCapping - $binaryReceivedTillNow;
                

              $chkremark = 0;
              $remark = "";

               if(!empty($topup_type))
               {
                $packageExist = Packages::select('duration','binary','capping', 'capping_limit_for_topup')->where('id',$topup_type->type)->orderby('entry_time', 'DESC')->first();
                $duration = $packageExist->duration;
                $binary_per = $packageExist->binary;
                $cappingx = $completeBinaryCapping;
                $cappingtopuppercent = ($highestusertopupamount * $packageExist->capping_limit_for_topup) / 100;

                
              }else{
                 $packageExist = Packages::select('duration','binary')->where('id',0)->first();

                $duration = $packageExist->duration;
                $binary_per = $packageExist->binary;
                $cappingx = $completeBinaryCapping;
                $cappingtopuppercent = ($highestusertopupamount * $packageExist->capping_limit_for_topup) / 100;

              }

              
                
              
              

                list($usec, $sec) = explode(" ", microtime());

                $time_start = ((float)$usec + (float)$sec);

                $deduction=array();
                $deduction['netAmount']=$deduction['tdsAmt']=$deduction['amt_pin']=0;

                $id=$getUserDetails[$key]['id'];
                
                $left_bv=$getUserDetails[$key]['curr_l_bv']; 
                $right_bv=$getUserDetails[$key]['curr_r_bv'];
                
                 

                $bindaydeductiontransaction = 0;
                if($getUserDetails[$key]['binary_sell_deduction'] == 2)
                {

                  $totalPowerBv = $getUserDetails[$key]['binary_deduction_upto_amount'];
                  $totalAmount = PayoutHistory::where('user_id', $getUserDetails[$key]['id'])
                                ->where('payout_for_special_power', 1)
                                ->sum('amount');

                  if($getUserDetails[$key]['binary_deduction_percent'] == 100)
                  {
                    $totalAmountchk = $totalAmount;
                  }
                  else{
                    $totalAmountchk = ((($totalAmount * 100) / (100 - $getUserDetails[$key]['binary_deduction_percent'])) * $getUserDetails[$key]['binary_deduction_percent']) / 100;
                  }
                  if($totalAmountchk >= $totalPowerBv)
                  {
                    $getVal=min($left_bv,$right_bv);
                    $bindaydeductiontransaction = 0;
                  }
                  else{
                    
                    $getVal=((min($left_bv,$right_bv)) * ((100 - $getUserDetails[$key]['binary_deduction_percent']) / 100));
                    $bindaydeductiontransaction = 1;
                  }
                }
                else{
                  $getVal=min($left_bv,$right_bv);
                  $bindaydeductiontransaction = 0;
                }
                
                $getTotalPair=$getVal;

                

              $check_if_ref_exist = Topup::select('tbl_product.direct_income','tbl_topup.pin','tbl_product.duration')->join('tbl_product','tbl_topup.type','tbl_product.id')
             ->where('tbl_topup.id',$id)->orderBy('tbl_topup.amount','desc')->first();
             
              
              
                if($getTotalPair!=0  && !empty($check_if_ref_exist))
                {    
                    //  $this->objBinaryIncome->PerPairBinaryIncomeNew($arrdata,$deduction);
                     
                    $perPair=1;
                    
                      $match_bv=$getVal;
                    
                    $laps_position=1;
                    $before_l_bv=$left_bv;
                    $before_r_bv=$right_bv;
                    $bd = 0;
                    if($bindaydeductiontransaction == 1)
                    {
                      if($getUserDetails[$key]['binary_deduction_percent'] == 0)
                      {
                        $match_bv1 = $match_bv;
                      }
                      else{
                        $match_bv1 = (($match_bv * 100) / (100 - $getUserDetails[$key]['binary_deduction_percent']));
                      }
                    }
                    else{
                      $match_bv1 = $match_bv;
                      
                    }

                    $up_left_bv   = round($left_bv-$match_bv1, 10);
                    $up_right_bv  = round($right_bv-$match_bv1, 10);
            
                    $carry_l_bv=$up_left_bv;
                    $carry_r_bv=$up_right_bv;

                    //******add carry *************
                    $carrybvArr1= array();
                    $carrybvArr1['user_id']=$id;
                    $carrybvArr1['before_l_bv']=$left_bv;
                    $carrybvArr1['before_r_bv']=$right_bv;
                    $carrybvArr1['match_bv']=$match_bv;  
                    $carrybvArr1['carry_l_bv']=$carry_l_bv;
                    $carrybvArr1['carry_r_bv']=$carry_r_bv;

                    array_push($insert_carrybv_arr,$carrybvArr1);

                    $dateTime= \Carbon\Carbon::now()->toDateTimeString(); 

                    //*******Update CurrentAmountDetails **********

                    $updateCuurentData = array();
                    $updateCuurentData['curr_l_bv'] = $up_left_bv;
                    $updateCuurentData['curr_r_bv'] = $up_right_bv;
                    $updateCuurentData['id'] = $id;

                    array_push($update_currbv_arr,$updateCuurentData);

                    $netAmount=$deduction['netAmount'];
                    $tdsAmt= $deduction['tdsAmt'];
                    $amt_pin=$deduction['amt_pin'];

                    $laps_amount  = 0;
 

              
                    if($rankdetails->capping == 0)
                    {
                      $my_capping = $rankdetails->capping;
                        if($my_capping < 2000)
                        {
                          $my_capping = $my_capping;
                          if($bindaydeductiontransaction == 1)
                          {
                            $my_capping = ($my_capping * (100 - $getUserDetails[$key]['binary_deduction_percent'])) / 100;
                          }
                        }
                        else{
                          $my_capping =  2000;
                          if($bindaydeductiontransaction == 1)
                          {
                            $my_capping = ($my_capping * (100 - $getUserDetails[$key]['binary_deduction_percent'])) / 100;
                          }
                          echo "2000 capping applied \n\n";
                        }
                    }
                    else{

                      $my_capping = $rankdetails->capping;
                      if($rankdetails->capping == 0)
                      {
                        if($my_capping < 2000)
                        {
                          $my_capping = $my_capping;
                          if($bindaydeductiontransaction == 1)
                          {
                            $my_capping = ($my_capping * (100 - $getUserDetails[$key]['binary_deduction_percent'])) / 100;
                          }
                        }
                        else{
                          $my_capping =  2000;
                          if($bindaydeductiontransaction == 1)
                          {
                            $my_capping = ($my_capping * (100 - $getUserDetails[$key]['binary_deduction_percent'])) / 100;
                          }
                        }
                      }
                      else{
                        if($completeBinaryCappingPending < $rankdetails->capping)
                        {
                          $my_capping = $my_capping;
                          if($bindaydeductiontransaction == 1)
                          {
                            $my_capping = ($my_capping * (100 - $getUserDetails[$key]['binary_deduction_percent'])) / 100;
                          }
                        }
                        else{
                          $my_capping = $rankdetails->capping;
                          if($bindaydeductiontransaction == 1)
                          {
                            $my_capping = ($my_capping * (100 - $getUserDetails[$key]['binary_deduction_percent'])) / 100;
                          }
                        }
                      }
                    
                    }
                    $amount = ($match_bv * $binary_per)/100;//(100*18)/100
                    $capping_amount  = 0;
                    $trimb = 0;

                    $lastCoinRate = CoinRate::orderBy('id', 'desc')->first();
                    

                    if($amount > $my_capping )//100>0 && 0 > 0
                    {   
                        $capping_amount  = $my_capping;
                        $laps_amount    =   ($amount - $my_capping);
                        $amount      =  $my_capping;
                        $token      =  $my_capping / $lastCoinRate->buy_rate;
                        if($chkremark == 0 && $laps_amount > 0)
                        {
                          if($completeBinaryCappingPending < $amount)
                          {
                            $my_capping = $completeBinaryCappingPending;
                            $capping_amount  = $completeBinaryCappingPending;
                            $laps_amount    =   ($amount - $my_capping);
                            $amount      =  $my_capping;
                            $token      =  $my_capping / $lastCoinRate->buy_rate;
                            $remark = "Laps due to 3x Achieved";
                          }
                          else{
                            $remark = "Daily Capping Achieved";
                          }
                        }   
                    }
                    else{
                     
                      if($completeBinaryCappingPending < $amount)
                          {
                            $my_capping = $completeBinaryCappingPending;
                            $capping_amount  = $completeBinaryCappingPending;
                            $laps_amount    =   ($amount - $my_capping);
                            $amount      =  $my_capping;
                            $token      =  $my_capping / $lastCoinRate->buy_rate;
                            $remark = "Laps due to 3x Achieved";
                          }
                          else{
                            $laps_amount = 0;
                            //$remark = "Trimmed Binary";
                            $remark = "Binary Income Generated";
                          }
                      
                    }

                    $netAmount  =  $amount - $amt_pin;	
                    $token      =  $amount / $lastCoinRate->buy_rate;

                    // $check_if_topup_exist = Topup::select('tbl_topup.id')->where('tbl_topup.roi_status','Active')->where('tbl_topup.id',$id)->count('tbl_topup.srno');

                  $binary_qualified_status = $value->binary_qualified_status;
                  $topup_status = $value->topup_status;


                   $laps_bv =0;
                  if ($binary_qualified_status==0 || $topup_status == 0) {


                      $laps_amount = $amount; 
                      $amount = 0;
                      if($binary_qualified_status==0 ){
                        $remark = "Binary not qualified";
                      }else if($topup_status == 0){
                        $remark = "No topup";
                      }else{
                        $remark = "Not having active topup";
                      }
                      
                      $laps_bv = $left_bv;
                      $netAmount = 0;
                      $left_bv = 0;
                      $right_bv = 0;
                      $laps_status =1;
                  }else{
                    $laps_status =0;
                  }

                  if($bindaydeductiontransaction == 1)
                    {
                      if($getUserDetails[$key]['binary_deduction_percent'] == 0)
                      {
                        $company_recover_amount = 0;
                      }
                      else{
                        $amountfull = (($amount * 100) / (100 - $getUserDetails[$key]['binary_deduction_percent']));
                        $company_recover_amount = (($amountfull * $getUserDetails[$key]['binary_deduction_percent']) / 100);
                      }
                    }
                    else{
                      $company_recover_amount = 0;
                    }
                  
                  if ($binary_qualified_status==1 && $topup_status == 1 && $check2directactive >= 2) {
                    $payoutArr= array();
                    $payoutArr['user_id']= $id;
                    $payoutArr['amount']= $amount;//3200
                    if($trimb == 1)
                    {
                        $amount_by_five_per = $amount / $distributionamount;
                    }
                    else{
                        $amount_by_five_per = $amount;
                    }
                    $payoutArr['amount_by_five_per']  = $amount_by_five_per;
                    $payoutArr['token'] = $token;
                    // $payoutArr['roi']= round(($amount/$duration),4);//4.4444
                    // $payoutArr['duration']= $duration;
                    $payoutArr['net_amount']= $netAmount;
                    $payoutArr['tax_amount']= 0;
                    $payoutArr['amt_pin']= $amt_pin;
                    $payoutArr['left_bv']= $left_bv;
                    $payoutArr['right_bv']= $right_bv;
                    $payoutArr['match_bv']= $match_bv;
                    $payoutArr['laps_bv']= $laps_bv;
                    $payoutArr['laps_status']= 1;
                    // $payoutArr['invoice_id']= substr(number_format(time() * rand(), 0, '', ''), 0, '9');
                    $payoutArr['laps_amount']= $laps_amount;
                      //$payoutArr['product_id'] = $product_id;
                    $payoutArr['left_bv_before']= $before_l_bv;
                    $payoutArr['right_bv_before']= $before_r_bv;
                    $payoutArr['left_bv_carry']= $carry_l_bv;
                    $payoutArr['right_bv_carry']= $carry_r_bv;        	       
                    $payoutArr['capping_amount']=$capping_amount;
                    $payoutArr['company_recover_amount'] = $company_recover_amount;
                    
                    if($bindaydeductiontransaction == 0)
                    {
                      $payoutArr['remark']=$remark;
                    }
                    else{
                      if($getUserDetails[$key]['binary_deduction_percent'] == 0)
                      {
                        $payoutArr['remark']= $remark;
                      }
                      else{
                        $payoutArr['remark']="You are eligible for ".(100 - $getUserDetails[$key]['binary_deduction_percent'])."% Binary";
                      }
                    }
                    $payoutArr['percentage']=$binary_per;
                    $payoutArr['payout_for_special_power']=$bindaydeductiontransaction;
                    
                    
                    $payoutArr['pin'] = mt_rand(1000000000, 9999999999);
                    $payoutArr['entry_time'] = \Carbon\Carbon::now()->toDateTimeString();
                    // $payoutArr['last_roi_entry_time'] = \Carbon\Carbon::now()->toDateTimeString();
  
                    array_push($insert_payout_arr,$payoutArr);
  
                    $binary_count++;
  
                      echo " Srno --> ".$binary_count." --> username --> ".$id." --> Binary Income --> ".$amount." --> Match --> ".$match_bv." --> Lapse --> ".$laps_amount;
  
                      $updateDashArr = array();
                      $updateDashArr['binary_income'] = 'binary_income + ' . $amount . '';
                      $updateDashArr['working_wallet'] = 'working_wallet + ' . $token . '';
                      $updateDashArr['binary_income_tokens'] = 'binary_income_tokens + ' . $token . '';
                      $updateDashArr['id'] = $id;
  
                    array_push($update_dash_arr,$updateDashArr);
                    

              
                  }
                  else{

                    $perPair=1;
                    $match_bv=$getVal;
                    $laps_position=1;
                    $before_l_bv=$left_bv;
                    $before_r_bv=$right_bv;
    
                    $laps_amount  = ($match_bv * $binary_per) / 100;
    
                    if($bindaydeductiontransaction == 1)
                    {
                      if($getUserDetails[$key]['binary_deduction_percent'] == 0)
                      {
                        $match_bv1 = $match_bv;
                      }
                      else{
                        $match_bv1 = (($match_bv * 100) / (100 - $getUserDetails[$key]['binary_deduction_percent']));
                      }
                    }
                    else{
                      $match_bv1 = $match_bv;
                    }

                    $up_left_bv   = round($left_bv-$match_bv1, 10);
                    $up_right_bv  = round($right_bv-$match_bv1, 10);

                    
                    $carry_l_bv=$up_left_bv;
                    $carry_r_bv=$up_right_bv;
    
                    $updateCuurentData = array();
                    $updateCuurentData['curr_l_bv'] = $up_left_bv;
                    $updateCuurentData['curr_r_bv'] = $up_right_bv;
                    $updateCuurentData['id'] = $id;
    
                    array_push($update_currbv_arr,$updateCuurentData);
    
    
                    $carrybvArr1= array();
                    $carrybvArr1['user_id']=$id;
                    $carrybvArr1['before_l_bv']=$left_bv;
                    $carrybvArr1['before_r_bv']=$right_bv;
                    $carrybvArr1['match_bv']=$match_bv;  
                    $carrybvArr1['carry_l_bv']=$carry_l_bv;
                    $carrybvArr1['carry_r_bv']=$carry_r_bv;
    
                    array_push($insert_carrybv_arr,$carrybvArr1);
    
    
    
    
                    $netAmount=$deduction['netAmount'];
                    $tdsAmt= $deduction['tdsAmt'];
                    $amt_pin=$deduction['amt_pin'];
    
                    
    
                    $laps_bv = $match_bv;
                    echo $id." = ".$carry_l_bv." = ".$carry_r_bv." = ".$laps_bv."\n\n";
    
                    $capping_amount = 0;
                    
                    $dateTime= \Carbon\Carbon::now()->toDateTimeString(); 
    
                    $payoutArr= array();
                    $payoutArr['user_id']= $id;
                    $payoutArr['amount']= 0;//3200
                    $amount_by_five_per = 0;
                    $payoutArr['amount_by_five_per']  = $amount_by_five_per;
                    $payoutArr['token'] = 0;
                    // $payoutArr['roi']= round(($amount/$duration),4);//4.4444
                    // $payoutArr['duration']= $duration;
                    $payoutArr['net_amount']= 0;
                    $payoutArr['tax_amount']= 0;
                    $payoutArr['amt_pin']= $amt_pin;
                    $payoutArr['left_bv']= $left_bv;
                    $payoutArr['right_bv']= $right_bv;
                    $payoutArr['match_bv']= $match_bv;
                    $payoutArr['laps_bv']= $laps_bv;
                    $payoutArr['laps_status']= 0;
                    // $payoutArr['invoice_id']= substr(number_format(time() * rand(), 0, '', ''), 0, '9');
                    $payoutArr['laps_amount']= $laps_amount;
                      //$payoutArr['product_id'] = $product_id;
                    $payoutArr['entry_time']= $dateTime;
                    $payoutArr['left_bv_before']= $before_l_bv;
                    $payoutArr['right_bv_before']= $before_r_bv;
                    $payoutArr['left_bv_carry']= $carry_l_bv;
                    $payoutArr['right_bv_carry']= $carry_r_bv;        	       
                    $payoutArr['capping_amount']=$capping_amount;
                    $payoutArr['remark']="Lapse due to no 2 direct active";
                    $payoutArr['percentage']=$binary_per;
                    $payoutArr['pin'] = mt_rand(1000000000, 9999999999);
                    $payoutArr['entry_time'] = \Carbon\Carbon::now()->toDateTimeString();
                    // $payoutArr['last_roi_entry_time'] = \Carbon\Carbon::now()->toDateTimeString();
    
                    $payoutArr['payout_for_special_power']=$bindaydeductiontransaction;
                    $payoutArr['company_recover_amount'] = 0;

                    array_push($insert_payout_arr,$payoutArr);
    
    
    
    
                  }

               

                      list($usec, $sec) = explode(" ", microtime());
                      $time_end = ((float)$usec + (float)$sec);
                         $time = $time_end - $time_start;
                         echo " --> time ".$time."\n";

                        // }//if
                }
                else{

                    $perPair=1;
                    $match_bv=$getVal;
                    $laps_position=1;
                    $before_l_bv=$left_bv;
                    $before_r_bv=$right_bv;

                    $laps_amount  = ($match_bv * $binary_per) / 100;

                    if($bindaydeductiontransaction == 1)
                    {
                      if($getUserDetails[$key]['binary_deduction_percent'] == 0)
                      {
                        $match_bv1 = $match_bv;
                        $company_recover_amount = 0;
                      }
                      else{
                        $match_bv1 = $match_bv * (100 / $getUserDetails[$key]['binary_deduction_percent']);
                        $company_recover_amount = 0;
                      }
                    }
                    else{
                      $match_bv1 = $match_bv;
                      $company_recover_amount = 0;
                    }

                    $up_left_bv   = round($left_bv-$match_bv1, 10);
                    $up_right_bv  = round($right_bv-$match_bv1, 10);
            
                    $carry_l_bv=$up_left_bv;
                    $carry_r_bv=$up_right_bv;

                    $updateCuurentData = array();
                    $updateCuurentData['curr_l_bv'] = $up_left_bv;
                    $updateCuurentData['curr_r_bv'] = $up_right_bv;
                    $updateCuurentData['id'] = $id;

                    array_push($update_currbv_arr,$updateCuurentData);


                    $carrybvArr1= array();
                    $carrybvArr1['user_id']=$id;
                    $carrybvArr1['before_l_bv']=$left_bv;
                    $carrybvArr1['before_r_bv']=$right_bv;
                    $carrybvArr1['match_bv']=$match_bv;  
                    $carrybvArr1['carry_l_bv']=$carry_l_bv;
                    $carrybvArr1['carry_r_bv']=$carry_r_bv;

                    array_push($insert_carrybv_arr,$carrybvArr1);




                    $netAmount=$deduction['netAmount'];
                    $tdsAmt= $deduction['tdsAmt'];
                    $amt_pin=$deduction['amt_pin'];

                    
 
                    $laps_bv = $match_bv;
                    echo $id." = ".$carry_l_bv." = ".$carry_r_bv." = ".$laps_bv."\n\n";

                    $capping_amount = 0;
                    
                    $dateTime= \Carbon\Carbon::now()->toDateTimeString(); 

                  $payoutArr= array();
                  $payoutArr['user_id']= $id;
                  $payoutArr['amount']= 0;//3200
                  $amount_by_five_per = 0;
                  $payoutArr['amount_by_five_per']  = $amount_by_five_per;
                  $payoutArr['token'] = 0;
                  // $payoutArr['roi']= round(($amount/$duration),4);//4.4444
                  // $payoutArr['duration']= $duration;
                  $payoutArr['net_amount']= 0;
                  $payoutArr['tax_amount']= 0;
                  $payoutArr['amt_pin']= $amt_pin;
                  $payoutArr['left_bv']= $left_bv;
                  $payoutArr['right_bv']= $right_bv;
                  $payoutArr['match_bv']= $match_bv;
                  $payoutArr['laps_bv']= $laps_bv;
                  $payoutArr['laps_status']= 0;
                  // $payoutArr['invoice_id']= substr(number_format(time() * rand(), 0, '', ''), 0, '9');
                  $payoutArr['laps_amount']= $laps_amount;
                    //$payoutArr['product_id'] = $product_id;
                  $payoutArr['entry_time']= $dateTime;
                  $payoutArr['left_bv_before']= $before_l_bv;
                  $payoutArr['right_bv_before']= $before_r_bv;
                  $payoutArr['left_bv_carry']= $carry_l_bv;
                  $payoutArr['right_bv_carry']= $carry_r_bv;        	       
                  $payoutArr['capping_amount']=$capping_amount;
                  $payoutArr['remark']="Id is not active";
                  $payoutArr['percentage']=$binary_per;
                  $payoutArr['pin'] = mt_rand(1000000000, 9999999999);
                  $payoutArr['entry_time'] = \Carbon\Carbon::now()->toDateTimeString();
                  // $payoutArr['last_roi_entry_time'] = \Carbon\Carbon::now()->toDateTimeString();

                  $payoutArr['payout_for_special_power']=$bindaydeductiontransaction;
                  $payoutArr['company_recover_amount'] = $company_recover_amount;

                  array_push($insert_payout_arr,$payoutArr);


                    
                  
                }
             
              
            }//end foreach
          // bulk operation
        
          // carry bv insert
            $count = 1;
            $array = array_chunk($insert_carrybv_arr,1000);
           // dd($array);
            while($count <= count($array))
            {
              $key = $count-1;
              Carrybv::insert($array[$key]);
              echo $count." insert carry bv array ".count($array[$key])."\n";
              $count ++;
            }

            // payout insert
            $count1 = 1;
            $array1 = array_chunk($insert_payout_arr,1000);
          // dd($array1);
            while($count1 <= count($array1))
            {
              $key1 = $count1-1;
              PayoutHistory::insert($array1[$key1]);
              echo $count1." insert payout array ".count($array1[$key1])."\n";
              $count1 ++;
            }

            $count2 = 1;
            $array2 = array_chunk($update_currbv_arr,1000);
  
            while($count2 <= count($array2))
            {
              $key2 = $count2-1;
              $arrProcess = $array2[$key2];
              $ids = implode(',', array_column($arrProcess, 'id'));
              $rbv_qry = 'curr_r_bv = (CASE id';
              $lbv_qry = 'curr_l_bv = (CASE id';
              foreach ($arrProcess as $key => $val) {
                $rbv_qry = $rbv_qry . " WHEN ".$val['id']." THEN ".$val['curr_r_bv'];
                $lbv_qry = $lbv_qry . " WHEN ".$val['id']." THEN ".$val['curr_l_bv'];
              }
              $rbv_qry = $rbv_qry . " END)";
              $lbv_qry = $lbv_qry . " END)";
              $updt_qry = "UPDATE tbl_users SET ".$rbv_qry." , ".$lbv_qry." WHERE id IN (".$ids.")";
              
              $updt_user = DB::statement($updt_qry);
              
              echo $count2." update user array ".count($arrProcess)."\n";
              $count2 ++;
            }

            $count3 = 1; 
            $array3 = array_chunk($update_dash_arr,1000);
            while($count3 <= count($array3))
            {
              $key3 = $count3-1;
              $arrProcess = $array3[$key3];
              $ids = implode(',', array_column($arrProcess, 'id'));
              $binary_income_qry = 'binary_income = (CASE id';
              $working_wallet_qry = 'working_wallet = (CASE id';
              $binary_income_tokens_qry = 'binary_income_tokens = (CASE id';
              foreach ($arrProcess as $key => $val) {
                $binary_income_qry = $binary_income_qry . " WHEN ".$val['id']." THEN ".$val['binary_income'];
                $working_wallet_qry = $working_wallet_qry . " WHEN ".$val['id']." THEN ".$val['working_wallet'];
                $binary_income_tokens_qry = $binary_income_tokens_qry . " WHEN ".$val['id']." THEN ".$val['binary_income_tokens'];
              }
              $binary_income_qry = $binary_income_qry . " END)";
              $working_wallet_qry = $working_wallet_qry . " END)";
              $binary_income_tokens_qry = $binary_income_tokens_qry . " END)";
              $updt_qry = "UPDATE tbl_dashboard SET ".$binary_income_qry.", ".$binary_income_tokens_qry." WHERE id IN (".$ids.")";
              $updt_user = DB::statement($updt_qry);
              
              echo $count3." update dash array ".count($arrProcess)."\n";
              $count3 ++;
            }
       
        }//if
        echo "end ".now()."\n";
        echo "\n Cron run successfully \n" ;

        $current_time = \Carbon\Carbon::now()->toDateTimeString();
        $msg = "Binary Cron end at ".$current_time."\nTotal binary ids : ".$binary_count."\n";
        //sendSMS($mobile,$msg);
        echo $msg;

        echo "\n";
        list($usec, $sec) = explode(" ", microtime());
        $time_end1 = ((float)$usec + (float)$sec);
        $time = $time_end1 - $time_start1;
        echo "Total cron time " . $time . "\n";

    }//handle function end
}
