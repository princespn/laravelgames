<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\QualifiedUserList;
use App\Models\User;
use Carbon\Carbon;

class OptimizedBinaryQualify extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:optimized_binary_qualify';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Optimized binary qualify cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $current_time = Carbon::now()->toDateTimeString();
        $this->info("Qualify Cron started at ".$current_time);

        $this->info("start ".now());

        $users = User::select('id')
            ->where('type','=','')
            ->where('binary_qualified_status', 0)
            ->where(function ($query) {
                $query->where('power_l_bv', '>', 0)->Where('power_r_bv', '>', 0);
            })
            ->get();

        $qualified_count = 0;

        if ($users->isNotEmpty()) {
            $insert_qualified_arr = [];
            $user_id_arr = [];

            foreach ($users as $user) {
                $qualifiedData = [
                    'user_id' => $user->id,
                ];
                $insert_qualified_arr[] = $qualifiedData;
                $user_id_arr[] = $user->id;
                $qualified_count++;

                $this->info("User ID --> ".$user->id);
            }

            $insertChunks = array_chunk($insert_qualified_arr, 1000);
            foreach ($insertChunks as $chunk) {
                QualifiedUserList::insert($chunk);
                $this->info("Insert count array ".count($chunk));
            }

            $updateUserData = [
                'binary_qualified_status' => 1,
            ];
            $updateChunks = array_chunk($user_id_arr, 1000);
            foreach ($updateChunks as $chunk) {
                User::whereIn('id', $chunk)->update($updateUserData);
                $this->info("Update user array ".count($chunk));
            }
        }

        $this->info("end ".now());
        $this->info("Cron run successfully");
        $this->info("Total qualified ids: ".$qualified_count);

        $current_time = Carbon::now()->toDateTimeString();
        $this->info("Qualify Cron end at ".$current_time);
    }
}
