<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Topup;
use App\Models\RankList;
use App\Models\AssignRank;
use App\Models\TodayDetails;
use DB;
use Response;
use Carbon\Carbon;

class RankIncome extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:rank_income';
    protected $hidden = true;


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Rank Income for users';

    /**
     * Create a new command instance.
     *
     * @return void
     */

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $users = User::select("id", "user_id","l_c_count","r_c_count")
            ->where('binary_qualified_status', '=', '1')
            ->where('topup_status', '1')
            ->where('amount', '>', 0)
            ->where('status','=','Active')
            ->get();

        if(!empty($users)){
            foreach($users as $user){ 
                $l_c_count = $user->l_c_count;
                $r_c_count = $user->r_c_count;
                $userDownId = min($l_c_count,$r_c_count);

                if($userDownId > 0){
                  
                    $userLeftDownline = TodayDetails::join('tbl_topup as tlu', 'tlu.id', '=', 'tbl_today_details.from_user_id')
                        ->where([['tbl_today_details.to_user_id', $user->id], ['tbl_today_details.position', 1]])
                        ->distinct('tbl_today_details.from_user_id')
                        ->count('tbl_today_details.from_user_id');

                    $userRightDownline = TodayDetails::join('tbl_topup as tru', 'tru.id', '=', 'tbl_today_details.from_user_id')
                        ->where([['tbl_today_details.to_user_id', $user->id], ['tbl_today_details.position', 2]])
                        ->distinct('tbl_today_details.from_user_id')
                        ->count('tbl_today_details.from_user_id');

                    $userDownlineTotal = min($userLeftDownline, $userRightDownline);


                    // dd($userDownlineTotal);
                    
                    $sum = AssignRank::where('user_id', $user->id)->sum('match_downline');

                    if (empty($sum)) {
                        $sum = 0;
                    }

                    $assign_rank = RankList::select('id', 'rank', 'weekly_amount', 'downline_req')
                        ->whereRaw('downline_req + '.$sum.' <= ?', [$userDownlineTotal])
                        ->orderBy('id', 'desc')
                        ->get();                    

                    if ($assign_rank->isNotEmpty()) {

                        foreach ($assign_rank as $data) {
 
                            $count = AssignRank::where('user_id', $user->id)
                            ->where('rank_id', '>=', $data->id)
                            ->count();

                            if ($count <= 0) {

                                $invoice_id = substr(number_format(time() * rand(), 0, '', ''), 0, '9');

                                $insertdata = new AssignRank;
                                $insertdata->user_id = $user->id;
                                $insertdata->rank_id = $data->id;
                                $insertdata->rank = $data->rank;
                                $insertdata->amount = $data->weekly_amount;
                                $insertdata->match_downline = $data->downline_req;
                                $insertdata->pin = $invoice_id;
                                $insertdata->rank_income_status = 0;
                                $insertdata->total_rank_income_count = 0;
                                $insertdata->entry_time = Carbon::now()->toDateTimeString();
                                $insertdata->last_rank_income_date = Carbon::now()->toDateTimeString();
                                $insertdata->save();                            

                                $updateUser = array();
                                $updateUser['rank'] = $data->rank;
                                User::where('id', $user->id)
                                  ->update($updateUser);

                                $this->info("User --> " . $user->id . " got Rank Income successfully");
                            }
                        }
                    }
                }
            }  
        }
        $this->info("Rank Income Cron run successfully");
    }
}
