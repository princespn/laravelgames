<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\TodayDetails;
use App\Models\PowerBV;
use App\Models\PayoutHistory;

//use App\Http\Controllers\userapi\AwardRewardController;


class RevertBinaryLapsIncomeCrom extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:revert_binary_laps_income_cron';
    protected $hidden = true;


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'revert_binary_laps_income_cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    // public function __construct(AwardRewardController $assignaward)
    public function __construct()
    {
        parent::__construct();
       // $this->assignaward = $assignaward; 
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
      
        $getUserDetails = PayoutHistory::select('id', 'user_id', 'amount', 'status', 'laps_amount', 'left_bv', 'right_bv', 'percentage', 'rank', 'entry_time', 'remark','designation','pin', 'token')
                ->where('remark', "Lapse due to no 2 direct active")
                ->orWhere('remark', "Id is not active")->get();

                if ($getUserDetails->isNotEmpty()) {
                    foreach ($getUserDetails as $user) {

                        $matching = min($user->right_bv,$user->left_bv);
                        $updateData = array();
                        $updateData["curr_l_bv"] = DB::raw("curr_l_bv + ".$matching);
                        $updateData["curr_r_bv"] = DB::raw("curr_r_bv + ".$matching);
                        DB::table('tbl_users')->where('id', $user->user_id)->update($updateData);

                    }
                }


    }
}


                           