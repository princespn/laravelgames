<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Topup;
use App\Models\Awards;
use App\Models\AwardWinner;
use App\Models\TodayDetails;
use DB;
use Response;

class RoyaltyBonusCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:royaly_bonus';
    protected $hidden = true;


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Royalty Bonus for users';

    /**
     * Create a new command instance.
     *
     * @return void
     */

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $users = User::select("id", "user_id","l_c_count","r_c_count")
                        ->where('binary_qualified_status', '=', 1)
                        ->where('topup_status', '1')
                        // ->where('user_id',103)
                        ->where('status','=','Active')
                        ->get();

        if(!empty($users)){
            foreach($users as $user){           
                $l_c_count = $user->l_c_count;
                $r_c_count = $user->r_c_count;
                $userDownId = min($l_c_count,$r_c_count);

                if($userDownId > 0){
                  
                    $userLeftDownline = TodayDetails::join('tbl_topup', 'tbl_topup.id', '=', 'tbl_today_details.from_user_id')
                            ->where([['tbl_today_details.to_user_id', $user->id], ['tbl_today_details.position', 1]])
                            ->distinct('tbl_today_details.from_user_id')
                            ->count('tbl_today_details.from_user_id');

                    $userRightDownline=TodayDetails::join('tbl_topup as ttp','ttp.id','tbl_today_details.from_user_id')
                            ->where([['tbl_today_details.to_user_id', $user->id], ['tbl_today_details.position', 2]])
                            ->distinct('tbl_today_details.from_user_id')
                            ->count('tbl_today_details.from_user_id');

                    $userDownlineTotal = min($userLeftDownline,$userRightDownline);

                    // dd($userDownlineTotal);
                    
                    $assign_award = Awards::select('award_id','award','weekly_income','downline_needed','business_required')->where([['business_required','<=',$userDownlineTotal]])->get();

                    if(count($assign_award)>0){

                        foreach ($assign_award as $data) {
 
                            $count = AwardWinner::where('user_id',$user->id)->where('award_id',$data->award_id)->count('award_id');

                            if($count<=0){   // if no award exist

                                $invoice_id = substr(number_format(time() * rand(), 0, '', ''), 0, '9');

                                $insertdata = new AwardWinner;
                                $insertdata->user_id = $user->id;
                                $insertdata->award_id = $data->award_id;
                                $insertdata->amount = $data->award;
                                $insertdata->weekly_amount = $data->weekly_income;
                                $insertdata->total_downId = $data->downline_needed;
                                $insertdata->pin = $invoice_id;
                                $insertdata->topup_date = $topupDate->entry_time;
                                $insertdata->save();                            
                            }
                        }
                    }
                }
            }  
        }
        echo "Royalty Bonus Cron run successfully"."\n";
    }
}
