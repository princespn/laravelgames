<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use DB;
use Response;
use App\User;
//use App\Http\Controllers\userapi\AwardRewardController;


class SignUpMail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:sign_up_mail';
    protected $hidden = true;


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'sign_up_mail';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    // public function __construct(AwardRewardController $assignaward)
    public function __construct()
    {
        parent::__construct();
       // $this->assignaward = $assignaward; 
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $usersList = User::select('email', 'id', 'user_id','fullname', 'mobile', 'temp_pass')->where('reg_mail_status', '=', 0)->get();

        $this->info('New Registered User => ' . count($usersList));
        foreach ($usersList as $user) {
            $subject = "Welcome to Mthmazic! Your Registration is Complete";
            $pagename = "emails.registration";
            $data = array('pagename' => $pagename, 'email' => $user->email, 'username' => $user->user_id, 'password' => $user->temp_pass,'name' =>$user->fullname,);
            $email = $user->email;

            // Check if the sendMail function exists and is callable
            if (function_exists('sendMail') && is_callable('sendMail')) {
                try {
                    $mail = sendMail($data, $email, $subject);

                    $arr = array('temp_pass' => 1, 'reg_mail_status' => 1);
                    if (!empty($mail)) {
                        // Log email sent success
                        $this->info('Email sent successfully to UserID => ' . $user->id);

                        User::where('id', '=', $user->id)->update($arr);
                    } else {
                        // Log email sending failure
                        $this->error('Email sending failed for UserID => ' . $user->id);
                    }
                } catch (Exception $e) {
                    // Log the error or handle it gracefully
                    $this->error('Error sending email to UserID => ' . $user->id . ': ' . $e->getMessage());
                }
            } else {
                $this->error('sendMail function not found or not callable');
            }
        }
    }
}


                           