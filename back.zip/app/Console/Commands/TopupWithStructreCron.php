<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\Models\StrucutreSetup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use App\config\constants; 
use App\Http\Controllers\user\UserTopUpController;


class TopupWithStructreCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:topup_with_structure';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Topup With Structure';
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(UserTopUpController $topup) {
        parent::__construct();
        $this->topup = $topup;
    }
     /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // dd('This cron is not running');
        
        $users = StrucutreSetup::where('execution_status', '0')
        ->select('strucutre_setup_cron.*', 'tbl_users.user_id as useridd')
        ->join('tbl_users', 'tbl_users.id', '=', 'strucutre_setup_cron.from_user_id')
        ->orderBy('strucutre_setup_cron.sr_no', 'asc')
        ->get(); 

        foreach ($users as $user){

            $request = new Request();
            $request['user_id'] = $user->useridd;
            $request['amount'] = 50;
            $request['fullname'] = $user->full_name;
            $request['email'] = $user->email_id;
            $request['password'] = $user->password;
            $request['position'] = $user->position;
            $request['usercount'] = $user->count;
            
            $response = $this->topup->topupWithStructreCron($request);

            $this->info("Structure Created Successfully For User Id => $user->from_user_id"); 

            StrucutreSetup::where('sr_no', $user->sr_no)->update(['execution_status' => 1]);

        }

        $this->info("Cron Run Successfully");         
    }

}