<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\Topup;
use App\Models\HoWallet;
use App\Models\Dashboard;


class WalletAmountCalculationCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:wallet_amount_calculation_cron';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'wallet_amount_calculation_cron';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $users = User::select('tbl_users.*', 'tbl_dashboard.*', 'tbl_users.id')
                        ->join('tbl_dashboard', 'tbl_users.id', '=', 'tbl_dashboard.id')
                        ->whereDate('tbl_users.entry_time', '<=', '2024-01-31')->get();
        $entrydatetime = date('Y-m-d H:i:s', time());

    	foreach ($users as $user)
        {

                if($user->id == 68 || $user->id == 145)
                {
                    $hoWallet = new HoWallet();
                    $hoWallet->user_id = $user->id; // Example user_id
                    $hoWallet->wallet_amount = 0; // Example wallet amount
                    $hoWallet->wallet_withdrawal_amount = 0; // Example withdrawal amount
                    $hoWallet->wallet_remaining_amount = 0; // Example withdrawal amount
                    $hoWallet->entry_time = $entrydatetime; // Assuming you want to set this manually
                    $hoWallet->updated_date = $entrydatetime;
                    $hoWallet->status = 1; // Active status
                    $hoWallet->save();

                    
                    $dashboard = Dashboard::where('id', $user->id)->update([
                        'working_wallet' => '0',
                        'working_wallet_locked_tokens' => '0',
                        'working_wallet_withdraw' => '0',
                        'old_working_wallet' => $user->working_wallet,
                        'old_working_wallet_locked_tokens' => $user->working_wallet_locked_tokens,
                        'old_working_wallet_withdraw' => $user->working_wallet_withdraw
                    ]);
                }
                else{

            $coinpayment = DB::table('tbl_transaction_invoices')
                ->where('id', $user->id)
                ->where('in_status', 1)
                ->sum('price_in_usd');


            $totalTopUp = DB::table('tbl_topup')
                ->where('id', $user->id)
                ->sum('amount');

            $SpecialtotalTopUp = DB::table('tbl_special_buying')
                ->where('to_user_id', $user->id)
                ->sum('amount');   
                
            $SpecialtotalTopUp1 = DB::table('tbl_special_power_bv')
                ->where('from_user_id', $user->id)
                ->where('current_user_id', $user->id)
                ->sum('power_bv');   

            $totalWithdrawalPending = DB::table('tbl_withdrwal_pending')
                ->where('id', $user->id)
                ->where('status', 1)
                ->where('verify', 1)
                ->whereIn('withdraw_type', [2, 9])
                ->sum('withdrawl_amount');

            if($coinpayment == $totalTopUp)
            {
                $totalTopUp = $coinpayment;
                $t1 = $totalTopUp - ($SpecialtotalTopUp + $SpecialtotalTopUp1);
                if($t1 < 0)
                {
                    $t1 = 0;
                }
                $wallet_remaining_amount = 0;

                if($totalWithdrawalPending > $t1)
                {
                    $totalWithdrawalPending = $t1;
                }

                $t1 = $t1 - $totalWithdrawalPending;

                // Creating a new wallet record
                $hoWallet = new HoWallet();
                $hoWallet->user_id = $user->id; // Example user_id
                $hoWallet->wallet_amount = ($t1) * 2; // Example wallet amount
                $hoWallet->wallet_withdrawal_amount = $totalWithdrawalPending; // Example withdrawal amount
                $hoWallet->wallet_remaining_amount = $wallet_remaining_amount; // Example withdrawal amount
                $hoWallet->entry_time = $entrydatetime; // Assuming you want to set this manually
                $hoWallet->updated_date = $entrydatetime;
                $hoWallet->status = 1; // Active status
                $hoWallet->save();

                $dashboard = Dashboard::where('id', $user->id)->update([
                    'working_wallet' => '0',
                    'working_wallet_locked_tokens' => '0',
                    'working_wallet_withdraw' => '0',
                    'old_working_wallet' => $user->working_wallet,
                    'old_working_wallet_locked_tokens' => $user->working_wallet_locked_tokens,
                    'old_working_wallet_withdraw' => $user->working_wallet_withdraw
                ]);
            }
            else{
                

                if($coinpayment < $totalTopUp)
                {
                $addfundpayment = DB::table('tbl_fund_request')
                                        ->where('user_id', $user->id)
                                        ->where('fund_status', 0)
                                        ->sum('amount');
                
                    $wallet_remaining_amount = $totalTopUp - $coinpayment;
                    $totalTopUp = $coinpayment;
                    $t1 = $totalTopUp - ($SpecialtotalTopUp + $SpecialtotalTopUp1);
                    if($t1 < 0)
                    {
                        $t1 = 0;
                    }
                    
                }
                else{
                    $totalTopUp = $totalTopUp - $addfundpayment;
                    $t1 = $totalTopUp - ($SpecialtotalTopUp + $SpecialtotalTopUp1);
                    $wallet_remaining_amount = 0;
                }

                if($totalWithdrawalPending > $t1)
                {
                    $totalWithdrawalPending = $t1;
                }

                                // Creating a new wallet record
                                $hoWallet = new HoWallet();
                                $hoWallet->user_id = $user->id; // Example user_id
                                $hoWallet->wallet_amount = ($t1) * 2; // Example wallet amount
                                $hoWallet->wallet_withdrawal_amount = $totalWithdrawalPending; // Example withdrawal amount
                                $hoWallet->wallet_remaining_amount = $wallet_remaining_amount; // Example withdrawal amount
                                $hoWallet->entry_time = $entrydatetime; // Assuming you want to set this manually
                                $hoWallet->updated_date = $entrydatetime;
                                $hoWallet->status = 1; // Active status
                                $hoWallet->save();
                
                                $dashboard = Dashboard::where('id', $user->id)->update([
                                    'working_wallet' => '0',
                                    'working_wallet_locked_tokens' => '0',
                                    'working_wallet_withdraw' => '0',
                                    'old_working_wallet' => $user->working_wallet,
                                    'old_working_wallet_locked_tokens' => $user->working_wallet_locked_tokens,
                                    'old_working_wallet_withdraw' => $user->working_wallet_withdraw
                                ]);

            }

            }
                

    	}
                              
    }
}


                           