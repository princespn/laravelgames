<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use DB;
use Response;
use App\User;
use App\Models\Topup;
use App\Models\HoWallet;
use App\Models\Dashboard;


class WalletAmountNewTopupChecking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:wallet_amount_new_topup_checking';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'wallet_amount_new_topup_checking';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $users = User::select('tbl_users.*', 'tbl_dashboard.*', 'tbl_users.id')
                        ->join('tbl_dashboard', 'tbl_users.id', '=', 'tbl_dashboard.id')
                        ->whereDate('tbl_users.entry_time', '<=', '2024-01-31')->get();
        $entrydatetime = date('Y-m-d H:i:s', time());

    	foreach ($users as $user)
        {

                if($user->id == 68 || $user->id == 145)
                {
                   
                }
                else{

            $totalTopUp = DB::table('tbl_topup')
                ->where('id', $user->id)
                ->sum('amount');

            $SpecialtotalTopUp = DB::table('tbl_special_buying')
                ->where('to_user_id', $user->id)
                ->sum('amount');   
                
            $SpecialtotalTopUp1 = DB::table('tbl_special_power_bv')
                ->where('from_user_id', $user->id)
                ->where('current_user_id', $user->id)
                ->sum('power_bv'); 
                
            $HoDetails = HoWallet::select('*')->where('user_id', $user->id)->first();; 

            $walletamountnew = (2 * $totalTopUp) - $HoDetails->wallet_remaining_amount;
            
                $dashboard = HoWallet::where('user_id', $user->id)->update([
                    'topup_amount' => $totalTopUp,
                    'special_power' => $SpecialtotalTopUp,
                    'special_buying' => $SpecialtotalTopUp1,
                    'wallet_amount' => $walletamountnew
                ]);
            }
            

            }
                

    	}
                              
    }



                           