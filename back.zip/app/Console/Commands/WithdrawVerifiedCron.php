<?php

namespace App\Console\Commands;
use App\Models\WithdrawPending;
use App\Models\Template;
use App\Models\ProjectSetting;
use DB;

use Illuminate\Console\Command;

class WithdrawVerifiedCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:withdrawal_verified_mail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Withdraw Verified Mail';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $get_all_withdrawal = WithdrawPending::join('tbl_users as tu', 'tu.id', '=', 'tbl_withdrwal_pending.id')
        ->select('tu.user_id','tu.email','tbl_withdrwal_pending.to_address','tbl_withdrwal_pending.sr_no')
        ->where('tbl_withdrwal_pending.verify','=',0)
        ->where('tbl_withdrwal_pending.status','=',0)
        ->get();
		// dd($get_all_withdrawal);

        
		foreach($get_all_withdrawal as $user)
		{
			
			$updateData = array();
			$updateData['mail_status'] =1; 
            $updateData['verify'] =1; 
			$updateOtpSta = WithdrawPending::where('sr_no', $user['sr_no'])->update($updateData);
					 
		}
		 
		echo "Conform Withdrawal";
		echo "\n";
    }
}
