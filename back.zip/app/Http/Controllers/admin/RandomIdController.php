<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Activitynotification;
use App\Models\PushNotification;
use App\Models\Country;
use App\Models\Currency;
use App\Models\Currencyrate;
use App\Models\Navigation;
use App\Models\Packages;
use App\Models\ProjectSettings;
use App\User;
use DB;
use Config;
use Mail;
use Storage;
use App\Traits\Users;
use App\Models\TodayDetails;
use App\Models\PowerBV;
use App\Models\ManualBvAdd;


class RandomIdController extends Controller
{
    /**
     * define property variable
     *
     * @return
     */
    use Users;
    public $statuscode;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->statuscode = Config::get('constants.statuscode');
        $this->emptyArray = (object) array();
        $date = \Carbon\Carbon::now();
        $this->today = $date->toDateTimeString();

        $this->settings = Config::get('constants.settings');
        $this->proSettings = ProjectSettings::where('status', '1')->first();
    }

    /**
     * get all user list with conditional parameter
     * @param $arrOptionalData has array of conditional parameter
     * @return \Illuminate\Http\Response
     */
    public function index() {

        $data['title'] = 'Add Middle Users';
        return view('admin.middleids', compact('data'));

    }


    public function addUsersInBetween(Request $request)
    {
             $no_of_ids = $request->Input('no_of_ids');
             $sponsor_id = $request->Input('ref_user_id');
             $position = $request->Input('position');

             $getSponsorDetails = User::select('*')->where('user_id', $sponsor_id)->first();
        
            
             $toleft = 0;
             $toright = 0;

             if($position == 1)
             {
                $getidbyposition = User::select('*')->where('position', $position)->where('virtual_parent_id', $getSponsorDetails['id'])->first();
                $toleft = 1;
                
                if(empty($getidbyposition))
                {

                    for($i = 0; $i < $no_of_ids; $i++)
                    { 
                        $user_id = "HO" . rand(9000000, 1000000);
                        $request['user_id'] = $user_id;
                        $this->binaryPlan($request);
                        $lastid = $user_id;
                    }

                    return "success";

                }
                else{
                    $updatedIdLeft = $getidbyposition['id'];
                    DB::table('tbl_users')
                    ->where('position', $position)
                    ->where('virtual_parent_id', $getSponsorDetails['id'])
                    ->update(['virtual_parent_id' => null]);

                    DB::table('tbl_today_details')
                    ->where('from_user_id', $getidbyposition['id'])
                    ->delete();
                }

             }
             else if($position == 2)
             {
                $getidbyposition = User::select('*')->where('position', $position)->where('virtual_parent_id', $getSponsorDetails['id'])->first();
                if(empty($getidbyposition))
                {

                    for($i = 0; $i < $no_of_ids; $i++)
                    { 
                        $user_id = "HO" . rand(9000000, 1000000);
                        $request['user_id'] = $user_id;
                        $this->binaryPlan($request);
                        $lastid = $user_id;
                    }

                    return "success";

                }
                else{
                $toright = 1;
                $updatedIdRight = $getidbyposition['id'];
                $getidbyposition->update(['virtual_parent_id' => '']);
                DB::table('tbl_users')
                ->where('position', $position)
                ->where('virtual_parent_id', $getSponsorDetails['id'])
                ->update(['virtual_parent_id' => null]);

                DB::table('tbl_today_details')
                ->where('from_user_id', $getidbyposition['id'])
                ->delete();
                 }
             }
             else{
                $getidbypositionLeft = User::select('*')->where('position', "1")->where('virtual_parent_id', $getSponsorDetails['id'])->first();
                $toleft = 1;
                $updatedIdLeft = $getidbypositionLeft['id'];
                $getidbypositionLeft->update(['virtual_parent_id' => '']);

                DB::table('tbl_users')
                ->where('position', '1')
                ->where('virtual_parent_id', $getSponsorDetails['id'])
                ->update(['virtual_parent_id' => null]);

                DB::table('tbl_today_details')
                ->where('from_user_id', $getidbypositionLeft['id'])
                ->delete();


                $getidbypositionRight = User::select('*')->where('position', "2")->where('virtual_parent_id', $getSponsorDetails['id'])->first();
                $toright = 1;
                $updatedIdRight = $getidbypositionRight['id'];
                $getidbypositionRight->update(['virtual_parent_id' => '']);

                DB::table('tbl_users')
                ->where('position', '2')
                ->where('virtual_parent_id', $getSponsorDetails['id'])
                ->update(['virtual_parent_id' => null]);

                DB::table('tbl_today_details')
                ->where('from_user_id', $getidbypositionLeft['id'])
                ->delete();
             }


             $getidbyposition_count = User::select('*')->where('id', $getidbyposition['id'])->first();
             $current_l_c_count = $getidbyposition_count['l_c_count'];
             $current_r_c_count = $getidbyposition_count['r_c_count'];

             if($getidbyposition_count['special_power_status'] == 1 || $getidbyposition_count['special_buying_id'] == 1)
             {
                $selftopuppassing = 0;
             }
             else{
                $selftopuppassing = $getidbyposition_count['amount'];
             }
             

             $current_l_bv = $getidbyposition_count['l_bv'];
             $current_r_bv = $getidbyposition_count['r_bv'];
             $current_curr_l_bv = $getidbyposition_count['curr_l_bv'];
             $current_curr_r_bv = $getidbyposition_count['curr_r_bv'];

           
            $dash1 = PowerBV::where('user_id', $getidbyposition['id'])->where('position', 1)->sum('power_bv');
            $dash2 = PowerBV::where('user_id', $getidbyposition['id'])->where('position', 2)->sum('power_bv');
            $dash3 = ManualBvAdd::where('user_id', $getidbyposition['id'])->where('position', 1)->sum('power_bv');
            $dash4 = ManualBvAdd::where('user_id', $getidbyposition['id'])->where('position', 2)->sum('power_bv');
            
            if($dash1 != 0 || $dash3 != 0)
            {
                $current_l_bv =  $current_l_bv - $dash1;
                $current_l_bv =  $current_l_bv - $dash3;
                if($current_curr_l_bv > $current_l_bv)
                {
                    $current_curr_l_bv = $current_l_bv;
                }
            }
            
            if($dash2 != 0 || $dash4 != 0){
                $current_r_bv =  $current_r_bv - $dash2;
                $current_r_bv =  $current_r_bv - $dash4;
                if($current_curr_r_bv > $current_r_bv)
                {
                    $current_curr_r_bv = $current_r_bv;
                }
            }

            if($position == 1)
            {
                $current_l_bv12 = ($current_l_bv + $current_r_bv + $selftopuppassing);
                $current_r_bv12 = 0;
                $current_curr_l_bv12 = ($current_curr_l_bv + $current_curr_r_bv + $selftopuppassing);
                $current_curr_r_bv12 = 0;
            }
            else{
                $current_l_bv12 = 0;   
                $current_r_bv12 = ($current_r_bv + $current_l_bv + $selftopuppassing);
                $current_curr_l_bv12 = 0;
                $current_curr_r_bv12 = ($current_curr_r_bv + $current_curr_l_bv + $selftopuppassing);
            }
             
             $lastid = '';

             $allidslist = array();

             for($i = 0; $i < $no_of_ids; $i++)
             {
                $user_id = "HO" . rand(9000000, 1000000);
                $request['user_id'] = $user_id;
                $this->binaryPlan($request);
                $lastid = $user_id;

                $current_l_c_count1 = 0;
                $current_r_c_count1 = 0;

                if($position == 1)
                {
                    $current_l_c_count1 = ($current_l_c_count + $current_r_c_count) + ($no_of_ids - $i);
                    
                }
                else{
                    $current_r_c_count1 = ($current_r_c_count + $current_l_c_count) + ($no_of_ids - $i); 
                    
                }

                $arridc = ['l_c_count' => $current_l_c_count1, 'r_c_count' => $current_r_c_count1, "user_id" => $user_id];
                array_push($allidslist, $arridc);


                    
                $query = DB::table('tbl_users')
                ->where('user_id', $user_id)
                ->update(['l_c_count' => $current_l_c_count1, 'r_c_count' => $current_r_c_count1, 'l_bv' => $current_l_bv12, 'r_bv' => $current_r_bv12, 'curr_l_bv' => $current_curr_l_bv12, 'curr_r_bv' => $current_curr_r_bv12]);

                

             }
             if($toleft == 1)
             {
                $updatedId = $updatedIdLeft;
             }
             else if($toright == 1){
                $updatedId = $updatedIdRight;
             }
             $getLastIdDetails = User::select('*')->where('user_id', $lastid)->first();
             DB::table('tbl_users')
             ->where('id', $updatedId)
             ->update(['virtual_parent_id' => $getLastIdDetails['id']]);

             $arrAllBelowIds = TodayDetails::select('*')->where('to_user_id', $updatedId)->get();
             

             $last = $updatedId;
             $virtual_parent_id1 = $last;
             $from_user_id_for_today_count = $virtual_parent_id1;
             $i = 0;
            //-------update user binary count-------
            $loopOn1 = true;
            $todaydetails_data = array();
            $left_users = array();
            $right_users = array();
            if ($virtual_parent_id1 > 0) {
             do {
                $posDetails = User::select('id', 'position', 'virtual_parent_id')->where([['id', '=', $virtual_parent_id1]])->get();
                if (count($posDetails) <= 0) {

                    $loopOn1 = false;
                } else {

                    foreach ($posDetails as $k => $v) {

                        $virtual_parent_id1 = $posDetails[$k]->virtual_parent_id;
                        if ($virtual_parent_id1 > 0) {
                            $position = $posDetails[$k]->position;
                            if ($last != $virtual_parent_id1) {
                                if ($position == 1) {

                                    array_push($left_users, $virtual_parent_id1);

                                    // $updateOtpSta1 = User::where('id', $virtual_parent_id1)->update(array('l_c_count' => DB::raw('l_c_count + 1')));
                                }
                                if ($position == 2) {
                                    array_push($right_users, $virtual_parent_id1);

                                    // $updateOtpSta1 = User::where('id', $virtual_parent_id1)->update(array('r_c_count' => DB::raw('r_c_count + 1')));
                                }

                                $Todaydata = array(); // new TodayDetails;
                                $Todaydata['to_user_id'] = $virtual_parent_id1;
                                $Todaydata['from_user_id'] = $from_user_id_for_today_count;
                                $Todaydata['entry_time'] = date("Y-m-d H:i:s");
                                $Todaydata['position'] = $position;
                                $Todaydata['level'] = $i + 1;
                                array_push($todaydetails_data, $Todaydata);
                                $i++;
                                /*$Todaydata = new TodayDetails;
                                $Todaydata->to_user_id = $virtual_parent_id1;
                                $Todaydata->from_user_id = $from_user_id_for_today_count;
                                $Todaydata->entry_time = date("Y-m-d H:i:s");
                                $Todaydata->position = $position;
                                $Todaydata->level = $i + 1;
                                $Todaydata->entry_time = $this->today;
                                $Todaydata->save();
                                $DataInsert = $Todaydata->id;
                                $i++;*/
                            }
                        } else {
                            $loopOn1 = false;
                        }
                    }
                }
            } while ($loopOn1 == true);


            $count = 1;
                            $array = array_chunk($todaydetails_data, 1000);
                            //dd($array);
                            while ($count <= count($array)) {
                                $key = $count - 1;
                                TodayDetails::insert($array[$key]);
                                // echo $count." count array ".count($array[$key])."\n";
                                $count++;
                            }              
        }


        foreach ($arrAllBelowIds as $detail) {
            
            DB::table('tbl_today_details')
                ->where('from_user_id', $detail->from_user_id)
                ->delete();
           
            $last = $detail->from_user_id;
            $virtual_parent_id1 = $last;
            $from_user_id_for_today_count = $virtual_parent_id1;
                           $i = 0;
                           //-------update user binary count-------
                           $loopOn1 = true;
                           $todaydetails_data = array();
                           $left_users = array();
                           $right_users = array();
                           if ($virtual_parent_id1 > 0) {
            do {
               $posDetails = User::select('id', 'position', 'virtual_parent_id')->where([['id', '=', $virtual_parent_id1]])->get();
               if (count($posDetails) <= 0) {

                   $loopOn1 = false;
               } else {

                   foreach ($posDetails as $k => $v) {

                       $virtual_parent_id1 = $posDetails[$k]->virtual_parent_id;
                       if ($virtual_parent_id1 > 0) {
                           $position = $posDetails[$k]->position;
                           if ($last != $virtual_parent_id1) {
                               if ($position == 1) {

                                   array_push($left_users, $virtual_parent_id1);

                                   // $updateOtpSta1 = User::where('id', $virtual_parent_id1)->update(array('l_c_count' => DB::raw('l_c_count + 1')));
                               }
                               if ($position == 2) {
                                   array_push($right_users, $virtual_parent_id1);

                                   // $updateOtpSta1 = User::where('id', $virtual_parent_id1)->update(array('r_c_count' => DB::raw('r_c_count + 1')));
                               }

                               $Todaydata = array(); // new TodayDetails;
                               $Todaydata['to_user_id'] = $virtual_parent_id1;
                               $Todaydata['from_user_id'] = $from_user_id_for_today_count;
                               $Todaydata['entry_time'] = date("Y-m-d H:i:s");
                               $Todaydata['position'] = $position;
                               $Todaydata['level'] = $i + 1;
                               array_push($todaydetails_data, $Todaydata);
                               $i++;
                               /*$Todaydata = new TodayDetails;
                               $Todaydata->to_user_id = $virtual_parent_id1;
                               $Todaydata->from_user_id = $from_user_id_for_today_count;
                               $Todaydata->entry_time = date("Y-m-d H:i:s");
                               $Todaydata->position = $position;
                               $Todaydata->level = $i + 1;
                               $Todaydata->entry_time = $this->today;
                               $Todaydata->save();
                               $DataInsert = $Todaydata->id;
                               $i++;*/
                           }
                       } else {
                           $loopOn1 = false;
                       }
                   }
               }
           } while ($loopOn1 == true);


           $count = 1;
                           $array = array_chunk($todaydetails_data, 1000);
                           //dd($array);
                           while ($count <= count($array)) {
                               $key = $count - 1;
                               TodayDetails::insert($array[$key]);
                               // echo $count." count array ".count($array[$key])."\n";
                               $count++;
                           }              
       }
        }


        for($i = 0; $i < count($allidslist); $i++)
        {
            $userid = $allidslist[$i]['user_id'];
            $r_c_count = $allidslist[$i]['r_c_count'];
            $l_c_count = $allidslist[$i]['l_c_count'];

            $updateOtpSta1 = User::where('user_id', $userid)->update(array('l_c_count' => $l_c_count, 'r_c_count' => $r_c_count));
        }

        
        
    }
}
