<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Http\Response as Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Validator;

class UserDetailsController extends Controller
{
    public function index(){

        return view('admin.UserDetails.index');

    }

}
