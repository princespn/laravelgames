<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Controllers\adminapi\CommonController;
use App\Models\ZoomMeetings;
use App\Models\ZoomMeetingsInterests;
use App\Models\verifyAdminOtpStatus;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Input;
use App\User;
use App\config\constants; 
use Hash;
use DB;
use Validator;
use Exception;
use Aws\S3\S3Client;
use Illuminate\Support\Facades\Config;
use File;
use Illuminate\Routing\Redirector;

class ZoomMeetingsController extends Controller
{
    /**
     * define property variable
     *
     * @return
     */
    public $statuscode, $commonController;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(CommonController $commonController)
    {
        $date             = \Carbon\Carbon::now();
        $this->today      = $date->toDateTimeString();
        $this->statuscode =    Config::get('constants.statuscode');
        $this->commonController = $commonController;
    }

    public function index(Request $request){
        $data['title'] = 'Downline Withdrawal Stop';
        return view('admin.downlinewithdrawlstop', compact('data'));
    }


   

    


}