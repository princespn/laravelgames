<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

use App\Services\Payments\TronService;
use App\Services\Payments\DogeService;
use App\Services\Payments\SolanaService;

use App\Models\Packages;
use App\Models\TransactionInfo;
use App\Models\TransactionInvoice;



class  PaymentsController extends Controller
{
    public function purchasePackage(Request $request)
    {
        $rules = [
            'currency_code' => 'required|string',
            'product_id'    => 'required|integer',
            'hash_unit'     => 'required|numeric|min:1',
        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'msg'    => $validator->errors()->first(),
            ], 422);
        }

        $user         = Auth::user();
        $currencyCode = strtoupper($request->currency_code);
        $amountUSD    = $request->hash_unit;

        try {
            if ($currencyCode === 'TRX' || $currencyCode === 'TRON') {
                //  Call NOWPayments
                $resp = $this->createNowPaymentsInvoice($amountUSD, $currencyCode, $user->email);
            } else {
                //  Call CoinPayments
                $resp = $this->createCoinPaymentsTransaction($amountUSD, $currencyCode, $user->email);
            }

            if ($resp['msg'] === 'success') {
                return response()->json([
                    'status' => 'success',
                    'data'   => [
                        'address'      => $resp['address'],
                        'qrcode_url'   => $resp['qrcode_url'],
                        'checkout_url' => $resp['checkout_url'],
                        'status_url'   => $resp['status_url'] ?? '',
                        'amount'       => $resp['amount'],
                        'timeout'      => $resp['timeout'] ?? 10800,
                        'currenttimeinsec' => 0,
                    ]
                ]);
            }

            return response()->json([
                'status' => 'error',
                'msg'    => $resp['error'] ?? 'Payment failed',
            ], 400);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'msg'    => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * NOWPayments: TRX/Tron handler
     */
    private function createNowPaymentsInvoice($amountUSD, $currency, $email)
    {
        $apiKey = config('services.nowpayments.api_key');
        $url    = "https://api.nowpayments.io/v1/invoice";

        $payload = [
            "price_amount"   => $amountUSD,
            "price_currency" => "usd",
            "pay_currency"   => "trx",
            "order_id"       => uniqid("order_"),
            "order_description" => "Deposit for {$email}"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "x-api-key: {$apiKey}",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($result, true);

        if (!empty($data['invoice_url'])) {
            return [
                'msg'         => 'success',
                'address'     => $data['pay_address'] ?? '',
                'qrcode_url'  => $data['qr_code'] ?? '',
                'checkout_url'=> $data['invoice_url'],
                'status_url'  => $data['invoice_url'],
                'amount'      => $data['pay_amount'] ?? $amountUSD,
                'timeout'     => 10800,
            ];
        }

        return ['msg' => 'failed', 'error' => $data['message'] ?? 'NOWPayments error'];
    }

    /**
     * CoinPayments: All other coins
     */
    private function createCoinPaymentsTransaction($amountUSD, $currency, $email)
    {
        // 🔹 Replace this with your existing coinpayments_api_call_allsystem()
        $req = [
            'amount'      => $amountUSD,
            'currency1'   => 'USD',
            'currency2'   => $currency,
            'buyer_email' => $email,
        ];

        $resp = coinpayments_api_call_allsystem('create_transaction', $req);

        if ($resp['msg'] === 'success') {
            return [
                'msg'         => 'success',
                'address'     => $resp['address'],
                'qrcode_url'  => $resp['data']['qrcode_url'] ?? '',
                'checkout_url'=> $resp['data']['checkout_url'] ?? '',
                'status_url'  => $resp['data']['status_url'] ?? '',
                'amount'      => $resp['data']['amount'] ?? $amountUSD,
                'timeout'     => 10800,
            ];
        }

        return $resp;
    }
}
