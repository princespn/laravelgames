<?php
namespace App\Http\Controllers\user;
use App\Http\Controllers\Controller;
use App\User;
use Auth;

use App\Models\RankReward;
use App\Models\RankRewardHistory;
use App\Models\Dashboard;


class RewardController extends Controller {
    public function __construct() {
    }

    public function rewardPage()
    {
        $data['title'] = 'Edit Marketing tools | HSCC';

        $userid = Auth::user()->id;

        $data['allranks'] = RankReward::select('*')->get();

        $dashboarddata = Dashboard::select('binary_income')->where('id', $userid)->first();

        $ct = 0;

        for($i = 0; $i < sizeof($data['allranks']); $i++)
        {
            $wherearr = array("user_id" => $userid, "achived_rank_id" => $data['allranks'][$i]->sr_no);
            $data['allranks'][$i]->myrankstatus = RankRewardHistory::select('*')->where($wherearr)->get();

            if(sizeof($data['allranks'][$i]->myrankstatus) == 0 && $ct == 0)
            {
                $ct = $ct + 1;
                $data['currentrank'] = $data['allranks'][$i]->rank_name;
                $data['currentrank_binary_income_required'] = $data['allranks'][$i]->binary_income_required;
                $data['currentrank_target_remain'] = $data['allranks'][$i]->binary_income_required - $dashboarddata->binary_income;
                
            }
        }
        
        return view('user.reward', compact('data'));
    }
}