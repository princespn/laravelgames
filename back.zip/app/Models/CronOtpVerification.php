<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CronOtpVerification extends Model
{
    protected $table = 'cron_otp_verifications';
    protected $fillable = ['user_id', 'command', 'otp', 'is_verified'];
}
