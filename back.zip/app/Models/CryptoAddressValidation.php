<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CryptoAddressValidation extends Model
{
    protected $table = 'tbl_crypto_currency_validation';
}
