<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SellFreezeByAdminModel extends Model
{
	/**
	 * [$table description]
	 * @var string
	 */
    protected $table = "sell_freeze_token";

    /**
     * [$guarded description]
     * @var array
     */
    protected $guarded = [];

    /**
     * [$hidden description]
     * @var array
     */
    protected $hidden = [];

}
