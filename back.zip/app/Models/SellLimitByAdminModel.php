<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SellLimitByAdminModel extends Model
{
	/**
	 * [$table description]
	 * @var string
	 */
    protected $table = "sell_limit_by_admin";

    /**
     * [$guarded description]
     * @var array
     */
    protected $guarded = [];

    /**
     * [$hidden description]
     * @var array
     */
    protected $hidden = [];

}
