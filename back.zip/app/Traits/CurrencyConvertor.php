<?php

namespace App\Traits;
use Exception;
use Illuminate\Http\Response as Response;
use App\User;
use Illuminate\Http\Request;
use DB;


trait CurrencyConvertor {
      
      

   

}
